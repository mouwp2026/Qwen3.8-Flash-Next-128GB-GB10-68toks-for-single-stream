#!/usr/bin/env python3
"""patch_draft_vocab.py -- build-time patcher: reduced-vocabulary MTP draft head.

Appends an env-gated `get_top_tokens` to the Qwen3.8-Flash-Next MTP draft
model so the draft step computes argmax over token ids [0, N) only, where
N = int(VLLM_QWEN_DRAFT_VOCAB). The lm_head GEMM is sliced to the first N
rows (contiguous prefix; the head is BF16 [248320, 2560], tied). The target
still verifies over the FULL vocabulary, so greedy outputs stay bit-exact;
only the draft acceptance rate can change (tokens with id >= N are proposed
as the best sub-N candidate and get corrected by the target).

Strictly a no-op when VLLM_QWEN_DRAFT_VOCAB is unset/0: the method is not
even installed, so the base proposer keeps its compute_logits fallback.
Requires speculative-config "use_local_argmax_reduction": true to take
effect (serve.sh wires both from DRAFT_VOCAB>0). TP1 only; TP>1 logs a
warning and falls back to the full-vocab argmax.

Idea: README-2 `single-spark-vllm-tp1/patch/` reduced-vocab draft
(FR-Spec lineage). This is an independent implementation for the blazux
qwen3.8-Flash-DGX image, Apache-2.0 compatible.

Usage:  python3 patch_draft_vocab.py <site-packages>
Idempotent: refuses to double-apply. Validates with ast.parse.
"""
import ast
import sys
from pathlib import Path

SP = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/local/lib/python3.12/dist-packages")
TARGET = SP / "vllm" / "models" / "qwen3_8_flash_next" / "nvidia" / "mtp.py"

MARKER = "# --- reduced-vocabulary MTP draft ---"

BLOCK = '''

# --- reduced-vocabulary MTP draft ---------------------------------
# Draft-step argmax over ids [0, N), N = VLLM_QWEN_DRAFT_VOCAB. No-op unless
# set AND speculative-config use_local_argmax_reduction=true. Target verifies
# over the full vocab: greedy outputs stay bit-exact at any N.
_DV_RAW = __import__("os").environ.get("VLLM_QWEN_DRAFT_VOCAB", "0")
_DV_N = int(_DV_RAW) if _DV_RAW.strip().isdigit() else 0


def _dv_get_top_tokens(self, hidden_states):
    w = self.lm_head.weight
    ok = getattr(self, "_dv_ok", None)
    if ok is None:
        try:
            from vllm.distributed import get_tensor_model_parallel_world_size
            _tp = get_tensor_model_parallel_world_size()
        except Exception:
            _tp = 1
        ok = (_DV_N > 0) and _tp == 1 and 0 < _DV_N < w.shape[0]
        if (_DV_N > 0) and not ok:
            __import__("vllm.logger", fromlist=["init_logger"]).init_logger(
                __name__).warning(
                "draft_vocab=%d not sliceable (tp=%d, head rows=%d); "
                "using full-vocab draft argmax", _DV_N, _tp, w.shape[0])
        self._dv_ok = ok
    if ok:
        return (hidden_states @ w[:_DV_N].t()).argmax(dim=-1)
    return self.logits_processor(self.lm_head, hidden_states).argmax(dim=-1)


if _DV_N > 0:
    Qwen3_8FlashNextMTP.get_top_tokens = _dv_get_top_tokens
# --- end reduced-vocabulary MTP draft ---
'''


def main() -> int:
    if not TARGET.exists():
        print(f"FAIL: {TARGET} not found", file=sys.stderr)
        return 1
    src = TARGET.read_text()
    if MARKER in src:
        print("draft-vocab patch already applied -- nothing to do")
        return 0
    if "class Qwen3_8FlashNextMTP" not in src:
        print("FAIL: anchor class Qwen3_8FlashNextMTP missing", file=sys.stderr)
        return 1
    if '__all__ = ["Qwen3_8FlashNextMTP"' not in src:
        print("WARN: __all__ anchor missing; appending anyway")
    TARGET.write_text(src.rstrip("\n") + "\n" + BLOCK)
    ast.parse(TARGET.read_text())
    print("draft-vocab patch applied + syntax OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
