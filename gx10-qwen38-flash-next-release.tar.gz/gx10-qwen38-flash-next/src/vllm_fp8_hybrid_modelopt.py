"""vllm_fp8_hybrid_modelopt — NVFP4 experts (ModelOpt) + blockwise-fp8 side layers.

The RadixArk checkpoint quantizes only the routed experts (NVFP4, ModelOpt) and
leaves the dense side layers (GDN in/out proj, QSA q/k/v/o, shared experts,
~15 GiB) in bf16. Those layers are read in full on every decoded token, so they
dominate decode bandwidth. This shim lets us store them as blockwise FP8-e4m3
(DeepSeek layout: fp8 ``weight`` + fp32 ``weight_scale_inv``, 128x128 blocks —
produced by the fork's ``tools/fp8_convert.py``) while keeping the NVFP4 MoE
path untouched.

Enabled by VLLM_FP8_HYBRID=1 (no-op otherwise). It patches
``ModelOptNvFp4Config``:
  * ``apply_vllm_mapper`` (called once with the model's hf->vllm name mapper):
    scans the checkpoint's safetensors metadata for F8_E4M3 ``.weight`` tensors
    that have a ``.weight_scale_inv`` sibling, and records their vLLM-side names;
  * ``get_quant_method``: for a LinearBase whose (possibly fused) sub-layers are
    all in that set, returns vLLM's generic blockwise ``Fp8Config`` method
    instead of the excluded/unquantized bf16 path.

Direct port of @Saren-Arterius's ``vllm_fp8_hybrid.py`` (AutoGPTQConfig) to the
ModelOpt NVFP4 config class.
"""
import logging
import os
import time

logger = logging.getLogger("vllm.fp8_hybrid_modelopt")
_SENTINEL = "_fp8_hybrid_patched"


def _enabled() -> bool:
    return os.environ.get("VLLM_FP8_HYBRID", "0").lower() in ("1", "true", "yes")


def apply() -> None:
    # --- 10. optional runtime fp8/nvfp4 lm_head (VLLM_LMHEAD_FP8 / _4BIT) ---
    if _LH_ON or _LH4_ON:
        try:
            install_lm_head_hook()
        except Exception as exc:  # pragma: no cover
            logger.warning("lmhead-fp8: hook install failed: %r", exc)
        try:
            _install_eager_build_hook()
        except Exception as exc:  # pragma: no cover
            logger.warning("lmhead-eager: hook install failed: %r", exc)
    if not _enabled():
        return
    from vllm.model_executor.layers.quantization import modelopt as m

    cfg_cls = m.ModelOptNvFp4Config
    if getattr(cfg_cls, _SENTINEL, False):
        return

    from vllm.model_executor.layers.linear import LinearBase
    from vllm.model_executor.layers.quantization.fp8 import Fp8Config
    from vllm.transformers_utils.config import get_safetensors_params_metadata

    orig_mapper = cfg_cls.apply_vllm_mapper
    orig_gqm = cfg_cls.get_quant_method

    def _scan_fp8_layers(self) -> set:
        try:
            from vllm.config import get_current_vllm_config
            model = get_current_vllm_config().model_config.model
            md = get_safetensors_params_metadata(model)
        except Exception as exc:  # pragma: no cover
            logger.warning("fp8 hybrid: cannot read safetensors metadata: %s", exc)
            return set()
        layers = {
            name[: -len(".weight")]
            for name, info in md.items()
            if name.endswith(".weight")
            and info.get("dtype") == "F8_E4M3"
            and name[: -len(".weight")] + ".weight_scale_inv" in md
        }
        return layers

    def apply_vllm_mapper(self, hf_to_vllm_mapper):
        orig_mapper(self, hf_to_vllm_mapper)
        hf_layers = _scan_fp8_layers(self)
        self.fp8_layers = set(hf_to_vllm_mapper.apply_list(list(hf_layers))) if hf_layers else set()
        if self.fp8_layers:
            logger.info("fp8 hybrid (modelopt): %d blockwise-fp8 layers detected", len(self.fp8_layers))

    def _norm(name: str) -> str:
        """Compare on the part after 'layers.' so 'model.layers.3.x' == 'language_model.model.layers.3.x'."""
        i = name.find("layers.")
        return name[i:] if i >= 0 else name

    def _is_fp8_layer(self, prefix: str) -> bool:
        fp8_layers = getattr(self, "fp8_layers", None)
        if fp8_layers is None:
            fp8_layers = _scan_fp8_layers(self)
            self.fp8_layers = fp8_layers
        if not fp8_layers:
            return False
        norm_set = getattr(self, "_fp8_norm", None)
        if norm_set is None:
            norm_set = {_norm(l) for l in fp8_layers}
            self._fp8_norm = norm_set
        head, _, proj = prefix.rpartition(".")
        fused = (self.packed_modules_mapping or {}).get(proj)
        names = [f"{head}.{p}" for p in fused] if fused and head else [prefix]
        hit = all(_norm(n) in norm_set for n in names)
        if any(k in prefix for k in ("qkv_proj", "in_proj", "o_proj", "out_proj", "shared_expert")):
            stats = self.__dict__.setdefault("_fp8_stats", {"fp8": 0, "other": 0})
            stats["fp8" if hit else "other"] += 1
            if not hit and "layers.0." in prefix:
                logger.info("fp8 hybrid: NOT fp8: %s (checked %s)", prefix, [_norm(n) for n in names])
        return hit

    def get_quant_method(self, layer, prefix):
        if isinstance(layer, LinearBase) and self._is_fp8_layer(prefix):
            fp8_cfg = getattr(self, "_fp8_cfg", None)
            if fp8_cfg is None:
                fp8_cfg = Fp8Config(
                    is_checkpoint_fp8_serialized=True,
                    activation_scheme="dynamic",
                    weight_block_size=[128, 128],
                )
                fp8_cfg.packed_modules_mapping = self.packed_modules_mapping
                self._fp8_cfg = fp8_cfg
            st = self.__dict__.get("_fp8_stats")
            if st and st["fp8"] in (1, 50, 100, 150, 192, 200):
                logger.info("fp8 hybrid: %d fused modules dispatched to Fp8LinearMethod so far (e.g. %s)", st["fp8"], prefix)
            return fp8_cfg.get_quant_method(layer, prefix)
        return orig_gqm(self, layer, prefix)

    cfg_cls.apply_vllm_mapper = apply_vllm_mapper
    cfg_cls._is_fp8_layer = _is_fp8_layer
    cfg_cls.get_quant_method = get_quant_method
    setattr(cfg_cls, _SENTINEL, True)
    logger.info("fp8 hybrid patch applied to ModelOptNvFp4Config")


# ---------------------------------------------------------------------------
# QSA qkv_proj: qsa.py builds it with ``model.without_modelopt_fp4(quant_config)``,
# which returns None for ModelOpt-FP4 checkpoints (bf16 path, shim never consulted).
# Dockerfile.hybrid redirects that call here: we hand the layer a thin proxy that
# dispatches to blockwise fp8 when the checkpoint has fp8 q/k/v for that prefix,
# and to the plain bf16 method otherwise (identical to the original behaviour).
# ---------------------------------------------------------------------------
def excluded_quant_config(quant_config):
    if quant_config is None:
        return None
    if quant_config.get_name() != "modelopt_fp4":
        return quant_config
    if not _enabled() or not hasattr(quant_config, "_is_fp8_layer"):
        return None  # original without_modelopt_fp4 semantics
    return _ExcludedFp8Proxy(quant_config)


def _make_proxy_class():
    from vllm.model_executor.layers.linear import LinearBase, UnquantizedLinearMethod
    from vllm.model_executor.layers.quantization.base_config import QuantizationConfig

    class ExcludedFp8Proxy(QuantizationConfig):
        """QuantizationConfig standing in for ``None`` on ModelOpt-excluded layers."""

        def __init__(self, inner):
            super().__init__()
            self._inner = inner
            self.packed_modules_mapping = inner.packed_modules_mapping

        def get_name(self):
            return "fp8"

        def get_supported_act_dtypes(self):
            return self._inner.get_supported_act_dtypes()

        @classmethod
        def get_min_capability(cls):
            return 80

        @staticmethod
        def get_config_filenames():
            return []

        @classmethod
        def from_config(cls, config):
            raise NotImplementedError

        def get_quant_method(self, layer, prefix):
            if isinstance(layer, LinearBase) and self._inner._is_fp8_layer(prefix):
                logger.info("fp8 hybrid: excluded-path layer %s -> Fp8LinearMethod", prefix)
                return self._inner.get_quant_method(layer, prefix)
            return UnquantizedLinearMethod()

    return ExcludedFp8Proxy


class _LazyProxy:
    _cls = None

    def __new__(cls, inner):
        if _LazyProxy._cls is None:
            _LazyProxy._cls = _make_proxy_class()
        return _LazyProxy._cls(inner)


_ExcludedFp8Proxy = _LazyProxy


# ---------------------------------------------------------------------------
# 10. lm_head: runtime fp8 head + bf16 top-K rerank   (VLLM_LMHEAD_FP8=1) ----
#     10b. ... or an NVFP4 search stage                  (VLLM_LMHEAD_4BIT=1) --
#
# The lm_head is the largest *dense* read of a decode step (bf16 [248320,2560]
# = 1.271 GB) and ModelOpt's `ignore` list excludes it from quantization, so it
# has been read at bf16 on every step while everything around it went fp8/nvfp4.
#
# This block deliberately does NOT touch checkpoint loading or the quantization
# pipeline. That is not a style choice: the MTP draft head loads the *same*
# `lm_head.weight` tensor name at bf16 into its own unquantized ParallelLMHead
# (see mtp.py `_remap_mtp_weight_name` -> "lm_head.", and the ParallelLMHead()
# call there which passes no quant_config). Re-quantizing the checkpoint, or
# making the target head fp8 at load time, would hand the draft head fp8
# magnitudes reinterpreted as bf16 -- plausibly without any error, silently
# destroying draft acceptance. Instead we leave loading 100% identical and
# build a per-tensor fp8 copy of the *target* head once, after loading.
#
# The fp8 copy only does the *search*; the top-K candidate rows are then
# re-scored exactly from the bf16 weight, so greedy output stays bit-exact.
# Same idea as the MTP draft-head patch, applied to the full 248320-row head.
#
# Measured on the real weight (64 random hidden probes at 4 scales):
#   * per-tensor fp8 == blockwise-128 quality here (global |w|max is only 0.412,
#     so a single scale barely loses anything): relL2 2.65% vs 2.64%
#   * bare fp8 flips 3-4 of 64 top-1 picks -> the rerank is required, not optional
#   * the true top-1 lands inside the fp8 top-8 in 64/64 probes -> K=64 keeps 8x
#     margin; reranked greedy is 64/64 identical to bf16 at K>=16
#   * read per decode step: 1.271 GB -> 0.636 GB + K*H*2 B (K=64: 320 KB)
#       = 636 MB/step @273 GB/s = 2.33 ms  -> 3.1% of a 75 ms k=4 step
#
# K defaults to 64 rather than 32 on purpose.  Exactness here rests *entirely*
# on recall@K: on real hidden states this head's bare low-precision top-1
# agreement is 0%, i.e. the ranking is systematically perturbed and only the
# candidate set stays sound.  Doubling K costs 160 KB of extra read per step
# (~0.2% of a step) and buys 2x the safety margin, which is the cheapest
# insurance available against a distribution we cannot fully probe.
#
# Env: VLLM_LMHEAD_FP8=1 (default off)
#      VLLM_LMHEAD_FP8_K=64        rerank width
#      VLLM_LMHEAD_FP8_TCHUNK=64   rows per _scaled_mm call
#      VLLM_LMHEAD_FP8_VCHUNK=8192 rows per quantize chunk (peak temp)
# ---------------------------------------------------------------------------
_LH_ON = os.environ.get("VLLM_LMHEAD_FP8", "0").strip().lower() in (
    "1", "true", "yes", "on")
_LH_K = int(os.environ.get("VLLM_LMHEAD_FP8_K", "64") or "64")
_LH_TCHUNK = int(os.environ.get("VLLM_LMHEAD_FP8_TCHUNK", "64") or "64")
_LH_VCHUNK = int(os.environ.get("VLLM_LMHEAD_FP8_VCHUNK", "8192") or "8192")
_LH_FP8_MAX = 448.0
_LH_MARK = "_lmhead_fp8_marked"
# mtp.py sets this on its *own* lm_head object.  The two heads share the same
# bf16 checkpoint tensor (mtp.py remaps "lm_head.weight" straight into the draft
# model), so type alone does not tell them apart.
_LH_SKIP = "_lmhead_fp8_skip"

# --- 10b. target lm_head: NVFP4 search stage (VLLM_LMHEAD_4BIT=1) ------------
# Supersedes the fp8 search with a 4-bit one on the same 248320-row head.
# Halves the search read one more time: 1212 MiB bf16 -> 606 MiB fp8 ->
# 303 MiB packed fp4 + 38 MiB swizzled block scales (0.5 B/param + 1 B per 16).
# When this stage verifies, the fp8 copy is *never built*, so the head's total
# residency drops from +606 MiB to +341 MiB of extra pool instead of growing.
#
# Same two-stage contract as everything else here: fp4 only proposes, the top-K
# candidate rows are re-scored exactly from bf16, so greedy output is unchanged
# as long as the true top-1 survives the candidate set.  Measured on the sibling
# draft head (tools/mtp_head_nvfp4_probe.py): bare fp4 flips ~20% of the top-1
# picks vs ~5% for fp8, yet both keep recall@K == 1 from K=8 -> K=32 leaves 4x
# margin.  Run with VLLM_LMHEAD_4BIT=probe to build/measure without switching.
# Env: VLLM_LMHEAD_4BIT=1|probe, _K=64, _MB=1
_LH4_MODE = os.environ.get("VLLM_LMHEAD_4BIT", "0").strip().lower()
_LH4_ON = _LH4_MODE in ("1", "true", "yes", "on", "probe")
_LH4_PROBE = _LH4_MODE == "probe"
# Same reasoning as _LH_K: fp4's raw ranking is even noisier than fp8's, so the
# rerank net is the only thing standing between us and a wrong token.
_LH4_K = int(os.environ.get("VLLM_LMHEAD_4BIT_K", "64") or "64")
_LH4_MB = os.environ.get("VLLM_LMHEAD_4BIT_MB", "1").strip().lower() in (
    "1", "true", "yes", "on")
_LH4_E2M1_MAX = 6.0
_LH4_E4M3_MAX = 448.0
# Adoption bar, expressed against the bf16 GEMV (the one reference that exists on
# every run).  fp8's own ratio is measured in this process whenever fp8 is the
# active stage -- 2.35x at T=1 and 1.67x at T=5 on this head, 2026-09-15 -- so a
# bar above both means fp4 has to be genuinely faster than fp8, not merely fast.
_LH4_BAR = float(os.environ.get("VLLM_LMHEAD_4BIT_BAR", "2.5") or "2.5")
_LH4_FP8_REF = {1: 2.35, 5: 1.67}      # measurement + reporting only, not a gate


def _lh_is_target_lm_head(layer, prefix=None) -> bool:
    """True only for the target model's lm_head.

    Two things had to change from the first version, both discovered by running
    it (hook installed, but no 'ON:' line ever appeared):

      * the prefix check is no longer required.  lm_head is on the checkpoint's
        quantization ignore list, so it is built with quant_config=None and
        ModelOptNvFp4Config.get_quant_method is *never* called for it -- the
        marking pass could never fire.  Dropping to a type check is safe because
        only the target model reaches LogitsProcessor._apply_head; the MTP
        drafter goes through get_top_tokens instead.

      * the draft head is excluded by an explicit flag rather than by inference
        (see _LH_SKIP), so a future vLLM that routes the drafter through
        _apply_head cannot silently re-quantise it.
    """
    from vllm.model_executor.layers.vocab_parallel_embedding import ParallelLMHead

    if not isinstance(layer, ParallelLMHead):
        return False
    if layer.__dict__.get(_LH_SKIP):
        return False
    if prefix is not None and prefix.rsplit(".", 1)[-1] != "lm_head":
        return False
    return True


# ---------------------------------------------------------------------------
# 10c. keep the head's build + microbench OUT of vLLM's profile window --------
#
# vLLM sizes the KV pool from what its profile run costs:
#
#     non_kv_cache = total_consumed + (torch_peak - torch_allocated)
#
# where torch_peak is the allocator peak *inside* the window.  Anything we
# allocate and release in there therefore shrinks the pool for the rest of the
# process's life, even though the memory is free again.  The head used to be
# built on the first forward -- which is the profile run itself (measured: build
# and microbench at 09:43:35-36, "Available KV cache memory" at 09:43:38) -- so
# the build's transients and the kernel microbench were charged to the KV pool.
#
# The fix is not to defer the bench but to move the whole build *earlier*: the
# V1 worker calls load_model() and then determine_available_memory(), so hooking
# the latter gives us "weights loaded, profile window not yet open".  The
# decision is still made before any token is served, and the self-verification
# keeps its hard-gate semantics.  initialize_from_config then tells us exactly
# when the KV pool exists, which is what the parked-bench fallback keys off.
_LH_KV_READY = False            # set by the initialize_from_config hook
_LH_MB_EAGER = False            # True only while the pre-profile build runs
_LH_STEADY_MIN = 4 << 30        # fallback heuristic: 4 GiB of KV must exist


def _lh_steady(lm_head) -> bool:
    """True once the KV pool has been allocated, i.e. the profile window is shut.

    Used to (a) decide whether a microbench can run without being charged to the
    KV pool and (b) make the "PROD check (first real step)" log line truthful --
    it used to fire on the profile dummy run, which is not a real step.
    """
    if _LH_KV_READY:
        return True
    st = lm_head.__dict__
    mark = st.get("_lh_alloc_mark")
    if mark is None:
        return False
    try:
        import torch
        return (torch.cuda.memory_allocated() - mark) >= _LH_STEADY_MIN
    except Exception:
        return False


def _lh_mb_gate(layer, run):
    """Run the performance gate now, or park it until the KV pool exists.

    Returns (passed, deferred).  A parked gate reports "passed" so the stage is
    adopted -- the alternative (refuse to adopt until a measurement that cannot
    be taken yet) would mean serving the slow path forever.
    """
    import torch

    if _LH_MB_EAGER or _lh_steady(layer):
        return bool(run(layer)), False
    layer.__dict__["_lh_mb_pending"] = True
    logger.info(
        "[lmhead-mb] microbench parked: running it here (inside vLLM's "
        "memory-profile window) would shrink the KV pool permanently")
    return True, True


def _lh_run_parked_bench(lm_head, tag) -> None:
    """Execute a parked microbench now that it costs the KV pool nothing."""
    st = lm_head.__dict__
    st.pop("_lh_mb_pending", None)
    try:
        if st.get("_lh4_use"):
            if not _lh4_microbench(lm_head):
                logger.warning(
                    "[lmhead-mb] microbench (%s) MISSED the bar: nvfp4 is not the "
                    "win it was expected to be at the live shape, but the fp8 copy "
                    "was never built -- building it now would take %.0f MiB out of "
                    "the KV pool.  Set VLLM_LMHEAD_4BIT=0 and restart to fall back "
                    "to the plain bf16 head.", tag, lm_head.weight.numel() / 1048576)
        elif st.get("_lh_w8") is not None:
            _lh_microbench(lm_head)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-mb] parked microbench failed (%s): %r", tag, exc)


def _find_target_heads(model):
    """(name, module) of every lm_head under `model`, the target head first."""
    found = []
    try:
        for name, mod in model.named_modules():
            if name == "lm_head" or name.endswith(".lm_head"):
                found.append((name, mod))
    except Exception:
        return []
    found.sort(key=lambda p: (p[0] != "lm_head", len(p[0])))
    return found


def _eager_build_heads(worker) -> None:
    """Build, selfcheck and bench the target head before the profile window."""
    global _LH_MB_EAGER
    import torch

    model = getattr(getattr(worker, "model_runner", None), "model", None)
    if model is None:
        return
    for name, mod in _find_target_heads(model):
        if not _lh_is_target_lm_head(mod):
            continue
        st = mod.__dict__
        if st.get("_lh_ready") or st.get("_lh_disabled"):
            return
        w = getattr(mod, "weight", None)
        if w is None or getattr(w, "dim", lambda: 0)() != 2:
            return
        logger.info(
            "[lmhead-eager] building '%s' shape=%s %s before the profile window "
            "-- KV sizing will not see our temporaries",
            name, tuple(w.shape), w.dtype)
        t0 = time.time()
        _LH_MB_EAGER = True
        try:
            ok = _lh_build(mod)
        finally:
            _LH_MB_EAGER = False
        if ok:
            st["_lh_ready"] = True
        else:
            st["_lh_disabled"] = True
        st["_lh_alloc_mark"] = torch.cuda.memory_allocated()
        logger.info("[lmhead-eager] '%s' ready=%s in %.1fs", name, ok, time.time() - t0)
        return


def _install_eager_build_hook() -> bool:
    """Hook the V1 worker so the head is built in the pre-profile gap."""
    try:
        from vllm.v1.worker.gpu_worker import Worker as _V1Worker
    except Exception as exc:
        logger.warning(
            "[lmhead-eager] V1 worker not importable (%r); the head will be built "
            "on the first forward and its microbench parked until the KV pool "
            "exists", exc)
        return False
    if getattr(_V1Worker, "_lmhead_eager_patched", False):
        return True

    _orig_dam = _V1Worker.determine_available_memory
    _orig_ifc = _V1Worker.initialize_from_config

    def determine_available_memory(self, *args, **kwargs):
        try:
            _eager_build_heads(self)
        except Exception as exc:      # pragma: no cover - defensive
            logger.warning("[lmhead-eager] pre-profile build skipped: %r", exc)
        return _orig_dam(self, *args, **kwargs)

    def initialize_from_config(self, *args, **kwargs):
        global _LH_KV_READY
        out = _orig_ifc(self, *args, **kwargs)      # the KV pool is allocated here
        _LH_KV_READY = True
        try:
            model = getattr(getattr(self, "model_runner", None), "model", None)
            for name, mod in _find_target_heads(model):
                if mod.__dict__.get("_lh_mb_pending"):
                    _lh_run_parked_bench(mod, "post-KV")
        except Exception as exc:      # pragma: no cover - defensive
            logger.warning("[lmhead-mb] parked bench skipped: %r", exc)
        return out

    _V1Worker.determine_available_memory = determine_available_memory
    _V1Worker.initialize_from_config = initialize_from_config
    _V1Worker._lmhead_eager_patched = True
    logger.info(
        "[lmhead-eager] hooked Worker.determine_available_memory / "
        "initialize_from_config: head build + microbench run outside the "
        "memory-profile window")
    return True


def _lh_build(layer) -> bool:
    """Prepare the target head once: bf16 kept for re-scoring, plus one search copy.

    The search copy is fp4 when that stage verifies, else fp8.  The two are
    mutually exclusive on purpose -- keeping both would add 606 + 341 MiB to a
    pool whose whole point is to stay small.
    """
    import torch

    st = layer.__dict__
    if st.get("_lh_building"):      # re-entry guard: the inner benches are re-entrant
        return False
    st["_lh_building"] = True
    try:
        return _lh_build_inner(layer)
    finally:
        st["_lh_building"] = False


def _lh_build_inner(layer) -> bool:
    import torch

    st = layer.__dict__
    w = layer.weight
    if w.dim() != 2 or w.dtype not in (torch.bfloat16, torch.float16):
        logger.warning(
            "[lmhead-fp8] head unusable (dtype=%s shape=%s); disabled",
            w.dtype, tuple(w.shape))
        st["_lh_disabled"] = True
        return False
    st["_lh_wbf"] = w          # bf16 kept for the exact re-score
    st["_lh_calls"] = 0
    st["_lh4_use"] = False

    if _LH4_ON and not torch.cuda.is_current_stream_capturing():
        try:
            if _lh4_build(layer):
                logger.info(
                    "[lmhead-4bit] fp8 search copy NOT built -- saves %.0f MiB "
                    "of the pool", w.numel() / 1048576)
                _lh4_selfcheck_prod_hook(layer)
                return True
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("[lmhead-4bit] stage failed: %r; falling back to fp8", exc)
        if st.get("_lh4_use"):
            return True
    return _lh_build_fp8(layer)


def _lh_build_fp8(layer) -> bool:
    """Quantize the target head to per-tensor fp8 once, in bounded chunks."""
    import torch

    st = layer.__dict__
    w = layer.weight
    if w.dim() != 2 or w.dtype not in (torch.bfloat16, torch.float16):
        st["_lh_disabled"] = True
        return False
    amax = w.abs().amax().clamp_min(1e-8)
    sb = (amax / _LH_FP8_MAX).to(torch.float32)
    rows, cols = w.shape
    w8 = torch.empty((cols, rows), dtype=torch.float8_e4m3fn, device=w.device)
    for off in range(0, rows, _LH_VCHUNK):
        blk = w[off:off + _LH_VCHUNK].float()
        w8[:, off:off + blk.shape[0]] = (blk / sb).clamp(
            -_LH_FP8_MAX, _LH_FP8_MAX).to(torch.float8_e4m3fn).t()
        del blk
    st["_lh_wbf"] = w          # bf16 kept for the exact re-score
    st["_lh_w8"] = w8          # [H, V] fp8, search only
    st["_lh_sb"] = sb.reshape(1)
    st.setdefault("_lh_calls", 0)
    torch.cuda.empty_cache()
    logger.info(
        "[lmhead-fp8] ON: rows=%d K=%d | read %.0f MiB bf16 -> %.0f MiB fp8 "
        "(+%.0f KB rerank) | head amax=%.5f",
        rows, _LH_K, w.numel() * 2 / 1048576, w8.numel() / 1048576,
        _LH_K * cols * 2 / 1024, float(sb) * _LH_FP8_MAX)
    _lh_selfcheck(layer)
    _lh_mb_gate(layer, _lh_microbench)
    return True


def _lh4_build(layer) -> bool:
    """Quantise the target head to NVFP4 (e2m1 + e4m3 block scales, block=16).

    Idempotent, never runs inside graph capture, and leaves ``_lh4_use`` False on
    any doubt so the caller can fall back to the fp8 copy.  As with the draft
    head, the fp4 kernel's actual speed at the live shape is measured rather than
    assumed -- a cutlass fp4 GEMV on sm_121 could in principle lose to fp8, and
    the answer decides whether the search switches.
    """
    import torch

    st = layer.__dict__
    st["_lh4_use"] = False
    wbf = st.get("_lh_wbf")
    if wbf is None or wbf.dim() != 2:
        logger.warning("[lmhead-4bit] no bf16 head yet; fp8 kept")
        return False
    rows, cols = wbf.shape
    if cols % 16 != 0:
        logger.warning("[lmhead-4bit] K=%d not a multiple of 16; fp8 kept", cols)
        return False
    try:
        from vllm._custom_ops import scaled_fp4_quant
        from vllm.model_executor.layers.quantization.utils.nvfp4_utils import (
            swizzle_blockscale)

        wbf = wbf.contiguous()
        amax = wbf.abs().amax().clamp_min(1e-8).to(torch.float32)
        gs_w = (_LH4_E2M1_MAX * _LH4_E4M3_MAX) / amax
        wq, wbs = scaled_fp4_quant(
            wbf, gs_w.reshape(1), is_sf_swizzled_layout=False)
        st["_lh4_wq"] = wq
        st["_lh4_ws"] = swizzle_blockscale(wbs)
        st["_lh4_gsw"] = gs_w
        logger.info(
            "[lmhead-4bit] built: rows=%d K=%d | packed fp4 %.0f MiB + swizzled "
            "scale %.0f MiB (fp8 %.0f MiB, bf16 %.0f MiB) | amax=%.5f gs=%.4e",
            rows, cols, wq.numel() / 1048576, st["_lh4_ws"].numel() / 1048576,
            rows * cols / 1048576, wbf.numel() * 2 / 1048576,
            float(amax), float(gs_w))

        ok = _lh4_selfcheck(layer)
        fast = _lh_mb_gate(layer, _lh4_microbench)[0] if _LH4_MB else True
        st["_lh4_use"] = bool(ok and fast and not _LH4_PROBE)
        logger.info(
            "[lmhead-4bit] selfcheck=%s microbench=%s -> target head search = %s%s",
            ok, fast, "nvfp4" if st["_lh4_use"] else "fp8",
            " (probe-only, behaviour unchanged)" if _LH4_PROBE else "")
        if not st["_lh4_use"]:
            for key in ("_lh4_wq", "_lh4_ws", "_lh4_gsw"):
                st.pop(key, None)
        torch.cuda.empty_cache()
        return st["_lh4_use"]
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-4bit] build failed: %r; fp8 kept", exc)
        for key in ("_lh4_wq", "_lh4_ws", "_lh4_gsw"):
            st.pop(key, None)
        return False


def _lh4_mm(lm_head, x):
    """fp4 logits over the full vocab: [T, H] -> [T, V] bf16. Search only."""
    import torch

    from vllm._custom_ops import cutlass_scaled_fp4_mm, scaled_fp4_quant

    st = lm_head.__dict__
    h = x.reshape(-1, x.shape[-1])
    if h.dtype is not torch.bfloat16:
        h = h.to(torch.bfloat16)
    amax = h.abs().amax().clamp_min(1e-8).to(torch.float32)
    gs_x = (_LH4_E2M1_MAX * _LH4_E4M3_MAX) / amax
    hq, hs = scaled_fp4_quant(
        h, gs_x.reshape(1), is_sf_swizzled_layout=True, backend="cutlass")
    alpha = (1.0 / (gs_x * st["_lh4_gsw"])).reshape(1).to(torch.float32)
    return cutlass_scaled_fp4_mm(
        hq, st["_lh4_wq"], hs, st["_lh4_ws"], alpha, torch.bfloat16)


def _lh4_selfcheck(lm_head) -> bool:
    """On the real weights, verify the rerank restores the bf16 argmax."""
    import torch

    st = lm_head.__dict__
    try:
        with torch.no_grad():
            wbf = st["_lh_wbf"]
            hs = torch.randn(64, wbf.shape[1], dtype=torch.bfloat16,
                             device=wbf.device)
            ref = (hs @ wbf.t()).argmax(-1)                 # true bf16 greedy
            lg4 = _lh4_mm(lm_head, hs)
            raw = lg4.argmax(-1)                            # bare fp4
            two = _lh4_forward(lm_head, hs, None).argmax(-1)  # fp4 + bf16 rerank
            r = (raw == ref).float().mean().item() * 100
            t = (two == ref).float().mean().item() * 100
            logger.info(
                "[lmhead-4bit] selfcheck (64 synthetic hidden): raw-fp4 top1="
                "%.1f%%, two-stage top1=%.1f%%", r, t)
            del hs, ref, lg4, raw, two
            return t >= 100.0
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-4bit] selfcheck failed: %r", exc)
        return False


def _lh4_microbench(lm_head) -> bool:
    """fp4+rerank vs the plain bf16 GEMV it replaces, at the live shapes.

    Deliberately does NOT time the fp8 stage, even though fp8 is the thing being
    replaced.  The two precision copies are mutually exclusive by design (_lh_build
    builds one or the other), so on the run where fp4 is a candidate the fp8 tensor
    simply does not exist -- the first version of this function called
    ``_lh_forward_fp8`` anyway and died with ``KeyError('_lh_w8')``, which the
    self-verification then read as "fp4 is not worth adopting" and silently kept fp8.
    Building an fp8 copy purely to time it would cost ~0.6 GiB of the KV pool for a
    number we already have.

    bf16 is the right common reference instead: it is timed here *and* by the fp8
    stage's own bench, on identical weights and shapes, and it reproduces to 0.1%
    across runs (7328 us at T=1 / 5584 us at T=5 on 2026-09-15, same in both runs)
    -- unlike fp8/fp4 timings, which depend on which copy happens to exist.

    T=1 is a plain decode step, T=5 is the MTP verify step (k=4 drafts + 1), i.e.
    the shapes the head actually sees.  Both numbers include the full-vocab logits
    write and the bf16 top-K re-score, so this compares the stages as used, not the
    raw GEMMs.  The bar is expressed against bf16 but set to clear fp8's own
    measured ratios, so passing it implies beating fp8.
    """
    import torch

    wbf = lm_head.__dict__["_lh_wbf"]
    try:
        def _t(fn, iters=40, warm=10):
            for _ in range(warm):
                fn()
            torch.cuda.synchronize()
            a = torch.cuda.Event(True)
            b = torch.cuda.Event(True)
            a.record()
            for _ in range(iters):
                fn()
            b.record()
            torch.cuda.synchronize()
            return a.elapsed_time(b) / iters * 1000.0       # microseconds

        gb_bf = wbf.numel() * 2 / 1e9
        gb_4 = wbf.numel() * 0.5625 / 1e9
        wins = []
        for t in (1, 5):
            hs = torch.randn(t, wbf.shape[1], dtype=torch.bfloat16,
                             device=wbf.device)
            tb = _t(lambda: hs @ wbf.t())
            t4 = _t(lambda: _lh4_forward(lm_head, hs, None))
            r4 = tb / t4
            ref = _LH4_FP8_REF.get(t, _LH4_FP8_REF[1])
            implied8 = tb / ref
            logger.info(
                "[lmhead-4bit] microbench T=%d: bf16 %.1f us (%.0f GB/s eff) | "
                "fp4+rerank %.1f us (%.0f GB/s eff) | fp4 vs bf16 %.2fx "
                "(bar %.2fx) | fp8 measured %.2fx -> implied fp8 %.1f us, fp4 "
                "%+.0f%% vs it",
                t, tb, gb_bf / (tb / 1e6),
                t4, gb_4 / (t4 / 1e6), r4, _LH4_BAR, ref, implied8,
                (implied8 - t4) / implied8 * 100.0)
            wins.append(r4 >= _LH4_BAR)
            del hs
        del wbf
        return all(wins)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-4bit] microbench failed: %r", exc)
        return False


def _lh4_forward(lm_head, hidden_states, embedding_bias=None):
    """fp4 search over the full vocab + exact bf16 re-score of the top-K rows."""
    import torch

    st = lm_head.__dict__
    wbf = st["_lh_wbf"]
    h = hidden_states
    if h.dtype is not torch.bfloat16:
        h = h.to(torch.bfloat16)
    rows = h.shape[0]
    vocab = st["_lh4_wq"].shape[0]
    k = min(_LH4_K, vocab)
    out = torch.empty((rows, vocab), dtype=torch.bfloat16, device=h.device)
    for i in range(0, rows, _LH_TCHUNK):
        x = h[i:i + _LH_TCHUNK]
        m = x.shape[0]
        lg = _lh4_mm(lm_head, x)[:m].contiguous()
        idx = torch.topk(lg, k, dim=-1).indices
        sel = wbf[idx.reshape(-1)].view(m, k, wbf.shape[1])
        exact = (x.float().unsqueeze(1) * sel.float()).sum(-1)
        lg.scatter_(1, idx, exact.to(lg.dtype))
        out[i:i + m] = lg
        del x, lg, idx, sel, exact
    if embedding_bias is not None:
        out = out + embedding_bias.to(out.dtype)
    n = st.get("_lh_calls", 0) + 1
    st["_lh_calls"] = n
    if n in (1, 200, 5000):
        logger.info("[lmhead-4bit] %d calls, T=%d", n, rows)
    return out


def _lh4_selfcheck_prod_hook(lm_head) -> None:
    """Once, on the first real draft/verify step, re-check against bf16 truth."""
    st = lm_head.__dict__

    def _check(hidden_states):
        if st.get("_lh4_checked"):
            return
        st["_lh4_checked"] = True
        import torch

        try:
            with torch.no_grad():
                h = hidden_states
                if h.dtype is not torch.bfloat16:
                    h = h.to(torch.bfloat16)
                wbf = st["_lh_wbf"]
                lg4 = _lh4_mm(lm_head, h)
                ref = (h @ wbf.t()).argmax(-1)
                two = _lh4_forward(lm_head, h, None).argmax(-1)
                logger.info(
                    "[lmhead-4bit] PROD check (first real step, T=%d): raw-fp4 "
                    "top1=%.1f%%, two-stage top1=%.1f%% (bf16 truth)",
                    h.shape[0],
                    (lg4.argmax(-1) == ref).float().mean().item() * 100,
                    (two == ref).float().mean().item() * 100)
                del lg4, ref, two, h
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("[lmhead-4bit] PROD check skipped: %r", exc)
        torch.cuda.empty_cache()

    st["_lh4_prod_check"] = _check


def _lh_microbench(lm_head) -> None:
    """fp8 search + bf16 rerank vs the plain bf16 GEMV it replaces.

    Neither number can be measured offline on this box -- the running server owns
    the whole unified pool, so a second CUDA context cannot be created.  The win
    is therefore logged from inside the engine, at build time, instead of being
    assumed.  T is the decode batch: 1 for a plain stream, k+1 for the MTP verify
    step that re-scores the drafts.
    """
    import torch

    wbf = lm_head.__dict__["_lh_wbf"]
    dev = wbf.device

    def _t(fn, iters=40, warm=10):
        for _ in range(warm):
            fn()
        torch.cuda.synchronize()
        a = torch.cuda.Event(True)
        b = torch.cuda.Event(True)
        a.record()
        for _ in range(iters):
            fn()
        b.record()
        torch.cuda.synchronize()
        return a.elapsed_time(b) / iters * 1000.0          # microseconds

    try:
        for t in (1, 5):
            hs = torch.randn(t, wbf.shape[1], dtype=torch.bfloat16, device=dev)
            tb = _t(lambda: hs @ wbf.t())
            t8 = _t(lambda: _lh_forward_fp8(lm_head, hs, None))
            gb_bf = wbf.numel() * 2 / 1e9
            gb_8 = wbf.numel() / 1e9
            logger.info(
                "[lmhead-fp8] microbench T=%d: bf16 %.1f us (%.0f GB/s eff) | "
                "fp8+rerank %.1f us (%.0f GB/s eff) | %.2fx",
                t, tb, gb_bf / (tb / 1e6), t8, gb_8 / (t8 / 1e6), tb / t8)
            del hs
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-fp8] microbench skipped: %r", exc)
    torch.cuda.empty_cache()
    return True                    # purely informational: it never gates adoption


def _lh_selfcheck(lm_head) -> None:
    """On the real weights, verify the rerank restores the bf16 argmax.

    The fp8 search is lossy by construction (bare fp8 flips a few percent of the
    top-1 picks on this head); what must hold is that the true argmax survives
    inside the fp8 top-K so the exact bf16 re-score can recover it.  That was
    measured on CPU across 64 probes at 4 hidden scales (64/64 from K=8, so K=32
    keeps a wide margin); this repeats it on the live tensor after loading.
    """
    import torch

    try:
        with torch.no_grad():
            wbf = lm_head.__dict__["_lh_wbf"]
            hs = torch.randn(64, wbf.shape[1], dtype=torch.bfloat16,
                             device=wbf.device)
            ref = (hs @ wbf.t()).argmax(-1)              # true bf16 greedy
            out = _lh_forward_fp8(lm_head, hs, None)
            if out is None:
                logger.warning("[lmhead-fp8] selfcheck: forward returned None")
                return
            two = out.argmax(-1)
            raw = None
            try:
                w8 = lm_head.__dict__["_lh_w8"]
                sb = lm_head.__dict__["_lh_sb"]
                sa = (hs.abs().amax().clamp_min(1e-8) / _LH_FP8_MAX).to(
                    torch.float32).reshape(1)
                h8 = (hs / sa).to(torch.float8_e4m3fn)
                raw = torch._scaled_mm(h8, w8, sa, sb,
                                       out_dtype=torch.bfloat16).argmax(-1)
            except Exception:
                pass
            msg = ("[lmhead-fp8] selfcheck (64 synthetic hidden): two-stage "
                   "top1=%.1f%%")
            args = [(two == ref).float().mean().item() * 100]
            if raw is not None:
                msg += " (raw fp8 only %.1f%%)"
                args.append((raw == ref).float().mean().item() * 100)
            logger.info(msg, *args)
            del hs, ref, out, two, raw
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("[lmhead-fp8] selfcheck skipped: %r", exc)


def _lh_forward(lm_head, hidden_states, embedding_bias):
    """Dispatch: fp4 search when it verified, else the fp8 search.

    The build/verify step happens once, on the first real call, never inside a
    graph capture.  Any failure at either stage degrades to the previous stage
    rather than raising, because this sits in the middle of the decode loop.
    """
    import torch

    st = lm_head.__dict__
    if st.get("_lh_disabled"):
        return None
    if not st.get("_lh_ready"):
        if torch.cuda.is_current_stream_capturing():
            return None            # never build a 0.6 GB copy inside a graph
        try:
            if not _lh_build(lm_head):
                return None
        except Exception as exc:   # pragma: no cover - defensive
            logger.warning("[lmhead-fp8] build failed: %r; disabled", exc)
            st["_lh_disabled"] = True
            return None
        st["_lh_ready"] = True
        st.setdefault("_lh_alloc_mark", torch.cuda.memory_allocated())

    # Parked microbench: the worker hooks run it right after the KV pool appears;
    # this is the net for the case where those hooks could not be installed.
    if (st.get("_lh_mb_pending") and _lh_steady(lm_head)
            and not torch.cuda.is_current_stream_capturing()):
        _lh_run_parked_bench(lm_head, "post-KV (lazy)")

    check = st.get("_lh4_prod_check")
    if (check is not None and _lh_steady(lm_head)
            and not torch.cuda.is_current_stream_capturing()):
        st.pop("_lh4_prod_check", None)
        check(hidden_states)

    if st.get("_lh4_use"):
        try:
            return _lh4_forward(lm_head, hidden_states, embedding_bias)
        except Exception as exc:
            st["_lh4_use"] = False
            logger.warning(
                "[lmhead-4bit] runtime error: %r; falling back to fp8", exc)
            torch.cuda.empty_cache()
            if st.get("_lh_w8") is None:
                try:
                    _lh_build_fp8(lm_head)
                except Exception as exc2:  # pragma: no cover - defensive
                    logger.warning("[lmhead-fp8] fallback build failed: %r", exc2)
                    st["_lh_disabled"] = True
                    return None
    if st.get("_lh_w8") is None:
        return None
    return _lh_forward_fp8(lm_head, hidden_states, embedding_bias)


def _lh_forward_fp8(lm_head, hidden_states, embedding_bias):
    """fp8 search over the full vocab + exact bf16 re-score of the top-K rows."""
    import torch

    st = lm_head.__dict__
    w8 = st["_lh_w8"]
    wbf = st["_lh_wbf"]
    sb = st["_lh_sb"]
    h = hidden_states
    if h.dtype != torch.bfloat16:
        h = h.to(torch.bfloat16)
    rows = h.shape[0]
    vocab = w8.shape[1]
    k = min(_LH_K, vocab)
    out = torch.empty((rows, vocab), dtype=torch.bfloat16, device=h.device)
    for i in range(0, rows, _LH_TCHUNK):
        x = h[i:i + _LH_TCHUNK]
        m = x.shape[0]
        pad = (-m) % 4
        xp = torch.cat([x, x[-1:].expand(pad, -1)], 0) if pad else x
        sa = (xp.abs().amax().clamp_min(1e-8) / _LH_FP8_MAX).to(
            torch.float32).reshape(1)
        x8 = (xp / sa).to(torch.float8_e4m3fn)
        lg = torch._scaled_mm(x8, w8, sa, sb, out_dtype=torch.bfloat16)
        lg = lg[:m].contiguous()
        idx = torch.topk(lg, k, dim=-1).indices
        sel = wbf[idx.reshape(-1)].view(m, k, wbf.shape[1])
        exact = (x.float().unsqueeze(1) * sel.float()).sum(-1)
        lg.scatter_(1, idx, exact.to(lg.dtype))
        out[i:i + m] = lg
        del x, xp, x8, lg, idx, sel, exact
    if embedding_bias is not None:
        out = out + embedding_bias.to(out.dtype)
    n = st.get("_lh_calls", 0) + 1
    st["_lh_calls"] = n
    if n in (1, 200, 5000):
        logger.info("[lmhead-fp8] %d calls, T=%d", n, rows)
    return out


def install_lm_head_hook() -> None:
    """Opt-in runtime low-precision lm_head for the target model only (no load-path change)."""
    if not (_LH_ON or _LH4_ON):
        return
    from vllm.model_executor.layers.quantization import modelopt as _mo

    if getattr(_mo.ModelOptNvFp4Config, "_lmhead_fp8_patched", False):
        return
    _cur_gqm = _mo.ModelOptNvFp4Config.get_quant_method

    def get_quant_method(self, layer, prefix):
        method = _cur_gqm(self, layer, prefix)
        try:
            if _lh_is_target_lm_head(layer, prefix):
                layer.__dict__[_LH_MARK] = True
                logger.info("[lmhead-fp8] marked target head (prefix=%s)", prefix)
        except Exception:
            pass
        return method

    _mo.ModelOptNvFp4Config.get_quant_method = get_quant_method

    from vllm.model_executor.layers.logits_processor import LogitsProcessor

    _orig_apply_head = LogitsProcessor._apply_head

    def _apply_head(self, lm_head, hidden_states, embedding_bias=None):
        if (
            _lh_is_target_lm_head(lm_head)
            and (self.head_dtype is None
                 or self.head_dtype == hidden_states.dtype)
        ):
            st = lm_head.__dict__
            if not st.get("_lh_first_seen"):
                st["_lh_first_seen"] = True
                logger.info(
                    "[lmhead-fp8] target head reached: %s weight=%s T=%d dtype=%s "
                    "head_dtype=%s",
                    type(lm_head).__name__, tuple(lm_head.weight.shape),
                    hidden_states.shape[0], hidden_states.dtype, self.head_dtype)
            res = _lh_forward(lm_head, hidden_states, embedding_bias)
            if res is not None:
                return res
        return _orig_apply_head(self, lm_head, hidden_states, embedding_bias)

    LogitsProcessor._apply_head = _apply_head
    _mo.ModelOptNvFp4Config._lmhead_fp8_patched = True
    logger.info("[lmhead-fp8] hook installed (K=%d, tchunk=%d, vchunk=%d)",
                _LH_K, _LH_TCHUNK, _LH_VCHUNK)
