# HashK compressed PLE table

The model's 51B-parameter n-gram (PLE) table is ~51 GB on disk as FP8 shards.
HashK replaces it at runtime with a 12.8 GB compressed row source that fits
comfortably in the page cache of a 121 GiB unified-memory box (GB10 / DGX
Spark / GX10).

## What it is

* `k=2` splitmix64-hashed sub-tables **A/B**, each 80,000,369 rows of 160
  FP8 columns (80000369 is prime). Each n-gram hashes into both sub-tables;
  the two rows are combined per head.
* FP8 storage uses **collision-mean buckets** (R=4): cells accumulate the
  mean of all rows that collided into them.
* Per-head 160x160 **bf16 ridge projection** W reconstructs the emitted row
  from the two hashed rows.

This makes the table **lossy by design**: the expected cosine similarity of a
reconstructed row against the true row is ~`1/sqrt(R)` (0.50 for R=4). It is
meant to be consumed as *draft-quality* features for the MTP speculative
path — the target model still verifies every token, so a lower acceptance
rate costs speed, never correctness. Measured on a GX10: acceptance rate
0.725 with HashK vs 0.576 with the stock mmap table (the compressed rows
actually *help* the draft head here).

## Getting the table

The artifact is not redistributed here. Build it from
[azampatti/GB10-3.8-Flash-Next](https://github.com/azampatti/GB10-3.8-Flash-Next)
(`tools/build_hashk_ple.py`, ~7 minutes against the local checkpoint):

```bash
git clone https://github.com/azampatti/GB10-3.8-Flash-Next
cd GB10-3.8-Flash-Next
python3 tools/build_hashk_ple.py --out ple_hashk_R4.pt   # R=4 default, 12.8 GB
```

Place it somewhere the serve container can mount, e.g.
`~/.cache/huggingface/hashk/ple_hashk_R4.pt` (the scripts mount
`$HF_CACHE` at `/hf`, so the in-container path is `/hf/hashk/ple_hashk_R4.pt`).

## Using it

```bash
PLE_HASHK=/hf/hashk/ple_hashk_R4.pt PREWARM=1 DRAFT_VOCAB=147456 MODE=hybrid scripts/serve.sh
```

* `PLE_HASHK` empty (default) = stock full-table mmap — a one-line rollback.
* `PREWARM=1` streams the whole 12.8 GB table once at boot (~2 s); pages then
  stay in the page cache and degrade gracefully to NVMe reads under memory
  pressure (mmap page faults, no engine involvement).
* The per-tensor `weight_scale` from the checkpoint is folded into the table
  at load time; `gather()` refuses to run before that fold (fail-fast guard)
  so an unscaled table can never silently produce garbage.

## Verifying a table

```bash
docker run --rm -v ~/.cache/huggingface:/hf:ro --entrypoint python3 \
  qwen38-flash-next-gx10-mtp-hashk:v1.0.0 \
  /usr/local/lib/python3.12/dist-packages/../../src/test_hashk.py \
  --module /usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py \
  --artifact /hf/hashk/ple_hashk_R4.pt \
  --model-path /hf/hub/models--RadixArk--Qwen3.8-Flash-Next-NVFP4/snapshots/<snap>
```

Checks: bit-exact hashing vs the reference runtime (200k tokens), quality
band (mean cos ≈ 0.50 for R=4), gather performance. See `tests/test_hashk.py`.
