#!/usr/bin/env python3
"""Build a product-quantized (PQ) PLE table for Qwen3.8-Flash-Next on GB10.

Why PQ instead of the existing HashK compression
------------------------------------------------
HashK folds the ~320M-row n-gram table onto hashed slots (R=4 -> ~80M slots),
so 4 rows share a slot and the reconstruction is their mean. It is trainless
and cheap, but mean-pooling saturates at the 1/sqrt(R) information limit:
cos ~0.50 at R=4, and upstream confirmed via three ablations (XOR hashing,
signed accumulation, norm-weighted pooling) that nothing inside that framework
beats it. Enlarging R only trades quality away linearly.

PQ discards no rows at all. Each 160-dim row is split into M sub-vectors and
each sub-vector is replaced by an 8-bit index into a per-head, per-segment
codebook trained with k-means. Cost is rows*M bytes of codewords plus
heads*M*K*seg_dim*2 bytes of codebooks.

Measured on a 131,072-row sample (pq_probe.py, same hashing/ridge port that
reproduced HashK's cos to 4 decimals):

    HashK R=4    11.92 GiB   cos 0.504
    PQ  M=5       1.49 GiB   cos 0.562
    PQ  M=8       2.38 GiB   cos 0.657

Encoding uses the BLAS-friendly expansion

    ||x - c||^2 = ||x||^2 - 2 x.c + ||c||^2

so the encode pass is ~N*K*DIM*2 FLOPs (26 TFLOPs at K=256) on the GEMM path
instead of the memory-bound broadcast form, which runs ~10x slower.

Reads the checkpoint twice (sampling pass, then encode pass); ~102 GB of NVMe
traffic total. Run with the server STOPPED: it streams the whole 51 GB table
through the page cache.

Env knobs: PQ_M, PQ_K, PQ_ITERS, PQ_PER_HEAD_SAMPLE, PQ_ENCODE_BATCH, PQ_OUT,
PQ_SEED.
"""
import json
import os
import shutil
import sys
import time

import numpy as np
import torch
import sympy
from safetensors import safe_open

M = int(os.environ.get("PQ_M", "5"))
K = int(os.environ.get("PQ_K", "256"))
ITERS = int(os.environ.get("PQ_ITERS", "25"))
PER_HEAD_SAMPLE = int(os.environ.get("PQ_PER_HEAD_SAMPLE", "32768"))
ENCODE_BATCH = int(os.environ.get("PQ_ENCODE_BATCH", "262144"))
ASSIGN_BATCH = int(os.environ.get("PQ_ASSIGN_BATCH", "16384"))
SEED = int(os.environ.get("PQ_SEED", "20260912"))
OUT = os.environ.get("PQ_OUT", f"/hf/hashk/ple_pq_M{M}.pt")
MODEL_ID = os.environ.get("PQ_MODEL_ID", "RadixArk/Qwen3.8-Flash-Next-NVFP4")
SNAPSHOT = os.environ.get("PQ_SNAPSHOT", "")
HF_CACHE = os.environ.get("HF_HOME", "/hf")

NGRAM_BASE = 20_000_000
HEADS = 16
DIM = 160
SPLIT_PARTS = 128
# Read only the first PARTS shard files. Used for the pre-flight smoke run:
# it walks the whole pipeline (shard read -> head split -> k-means -> grouped
# encode -> save -> load -> gather) on ~1 GB instead of 51 GB, so the real
# build is not the first time the code runs. Codes for unvisited rows stay 0.
PARTS = int(os.environ.get("PQ_MAX_SHARDS", str(SPLIT_PARTS)))
SMOKE = PARTS < SPLIT_PARTS

DEV = "cuda" if torch.cuda.is_available() else "cpu"


def log(*a):
    print(*a, flush=True)


def head_sizes():
    """Per-head prime vocabularies, identical to build_hashk_ple.py."""
    sizes, offs, total = [], [], 0
    prime = NGRAM_BASE - 1
    for _ in range(HEADS):
        prime = int(sympy.nextprime(prime))
        sizes.append(prime)
        offs.append(total)
        total += prime
    return sizes, offs, total


def _has_index(path):
    return bool(path) and os.path.isfile(
        os.path.join(path, "model.safetensors.index.json")
    )


def resolve_snapshot():
    if SNAPSHOT:
        if not _has_index(SNAPSHOT):
            sys.exit(f"PQ_SNAPSHOT={SNAPSHOT} has no model.safetensors.index.json")
        return SNAPSHOT
    glob_dir = os.path.join(
        HF_CACHE, "hub", "models--" + MODEL_ID.replace("/", "--"), "snapshots"
    )
    if os.path.isdir(glob_dir):
        for name in sorted(os.listdir(glob_dir)):
            cand = os.path.join(glob_dir, name)
            if _has_index(cand):
                return cand
    sys.exit(f"checkpoint not found under {glob_dir}; set PQ_SNAPSHOT=/path/to/snapshot")


def shard_map(snap):
    idx = json.load(open(os.path.join(snap, "model.safetensors.index.json")))
    out = {}
    for name, f in idx["weight_map"].items():
        if ".ngram_embedding.shard_" in name and name.endswith(".weight"):
            n = int(name.rsplit("shard_", 1)[1].split(".")[0])
            out[n] = (name, os.path.join(snap, f))
    assert len(out) == SPLIT_PARTS, f"expected {SPLIT_PARTS} shards, found {len(out)}"
    return out


# --------------------------------------------------------------------------- #
# quantizer
# --------------------------------------------------------------------------- #
def kmeans(X, k, iters, seed, batch=ASSIGN_BATCH):
    """k-means on the GEMM path. X: [n, d] float32 on DEV -> C: [k, d]."""
    n = X.shape[0]
    k = min(k, n)
    g = torch.Generator().manual_seed(seed)
    C = X[torch.randperm(n, generator=g)[:k]].clone().contiguous()
    Cn = (C * C).sum(1)
    for _ in range(iters):
        lab = torch.empty(n, dtype=torch.int64, device=X.device)
        for s in range(0, n, batch):
            e = min(s + batch, n)
            Xb = X[s:e]
            d2 = Xb @ C.T
            d2.mul_(-2).add_((Xb * Xb).sum(1, keepdim=True)).add_(Cn)
            lab[s:e] = d2.argmin(1)
        Cnew = torch.zeros_like(C)
        Cnew.index_add_(0, lab, X)
        cnt = torch.bincount(lab, minlength=C.shape[0]).to(X.dtype)
        nz = cnt > 0
        Cnew[nz] /= cnt[nz, None]
        Cnew[~nz] = C[~nz]
        shift = float((Cnew - C).abs().max())
        C = Cnew
        Cn = (C * C).sum(1)
        if shift < 1e-6:
            break
    return C.contiguous()


def encode_into(X, C, out, batch=ENCODE_BATCH):
    """Fill uint8 out[:n] with nearest-codeword indices, GEMM path."""
    n = X.shape[0]
    Cn = (C * C).sum(1)
    for s in range(0, n, batch):
        e = min(s + batch, n)
        Xb = X[s:e]
        d2 = Xb @ C.T
        d2.mul_(-2).add_((Xb * Xb).sum(1, keepdim=True)).add_(Cn)
        out[s:e] = d2.argmin(1).to(torch.uint8)


def main():
    seg_dim = DIM // M
    if seg_dim * M != DIM:
        sys.exit(f"PQ_M={M} does not divide DIM={DIM}")
    if K > 256:
        sys.exit(f"PQ_K={K} exceeds the uint8 codeword space")

    snap = resolve_snapshot()
    log(f"[pq] checkpoint: {snap}")
    log(f"[pq] device={DEV}  M={M} K={K} seg_dim={seg_dim} iters={ITERS}")

    names = shard_map(snap)
    sizes, offs, total = head_sizes()
    ss = (total + SPLIT_PARTS - 1) // SPLIT_PARTS
    log(f"[pq] total rows={total}  shard rows={ss}  target codes={total*M/1e9:.2f} GB")

    offs_t = torch.tensor(offs + [total], device=DEV)
    offs_np = np.asarray(offs, dtype=np.int64)
    steps = [max(1, sizes[h] // PER_HEAD_SAMPLE) for h in range(HEADS)]

    # ------------------------------------------------------------------ #
    # pass 1: per-head sampling
    # ------------------------------------------------------------------ #
    t0 = time.time()
    samp = [[] for _ in range(HEADS)]
    for n in range(PARTS):
        name, path = names[n]
        with safe_open(path, framework="pt", device="cpu") as f:
            w = f.get_tensor(name).to(torch.float32)
        g0 = n * ss
        rows = min(w.shape[0], max(0, total - g0))
        if rows <= 0:
            continue
        gidx = np.arange(g0, g0 + rows, dtype=np.int64)
        hh = np.searchsorted(offs_np, gidx, side="right") - 1
        for h in range(HEADS):
            sel = hh == h
            if not sel.any():
                continue
            local = gidx[sel] - offs[h]
            pick = (local % steps[h]) == 0
            if pick.any():
                samp[h].append(w[torch.from_numpy(np.nonzero(sel)[0][pick])])
        del w
        if n % 16 == 0:
            log(f"[pq] sample pass shard {n}/{PARTS}  {time.time()-t0:.0f}s")
    counts = [sum(t.shape[0] for t in s) for s in samp]
    log(f"[pq] sampled per head: min={min(counts)} max={max(counts)} "
        f"total={sum(counts)}  ({time.time()-t0:.0f}s)")

    # ------------------------------------------------------------------ #
    # train per-head codebooks
    # ------------------------------------------------------------------ #
    CB = torch.zeros(HEADS, M, K, seg_dim, dtype=torch.float32, device=DEV)
    t1 = time.time()
    for h in range(HEADS):
        if not samp[h]:
            if SMOKE:
                log(f"[pq] WARN head {h}: no samples in the first {PARTS} shards")
                continue
            sys.exit(f"[pq] head {h} produced no samples -- sampling pass is broken")
        Xh = torch.cat(samp[h]).to(DEV)
        samp[h] = None
        if Xh.shape[0] < K:
            if SMOKE:
                log(f"[pq] WARN head {h}: only {Xh.shape[0]} samples (< K={K})")
                continue
            sys.exit(
                f"[pq] head {h} has {Xh.shape[0]} samples but K={K}; raise "
                "PQ_PER_HEAD_SAMPLE"
            )
        hat = torch.empty_like(Xh)
        for m in range(M):
            a, b = m * seg_dim, (m + 1) * seg_dim
            Cm = kmeans(Xh[:, a:b], K, ITERS, SEED + h * 131 + m * 7)
            CB[h, m] = Cm
            idx_m = torch.empty(Xh.shape[0], dtype=torch.uint8, device=DEV)
            encode_into(Xh[:, a:b], Cm, idx_m)
            hat[:, a:b] = Cm[idx_m.long()]
        cos = torch.nn.functional.cosine_similarity(hat, Xh, dim=1).mean().item()
        log(f"[pq] head {h:2d}: n={Xh.shape[0]} cos={cos:.4f}")
        del Xh, hat
    del samp
    torch.cuda.empty_cache()
    log(f"[pq] codebooks trained in {time.time()-t1:.0f}s  "
        f"({CB.numel()*2/1e6:.2f} MB as bf16)")

    # ------------------------------------------------------------------ #
    # pass 2: full-table encode
    # ------------------------------------------------------------------ #
    codes = np.zeros((total, M), dtype=np.uint8)
    t2 = time.time()
    for n in range(PARTS):
        name, path = names[n]
        with safe_open(path, framework="pt", device="cpu") as f:
            w = f.get_tensor(name).to(torch.float32)
        g0 = n * ss
        rows = min(w.shape[0], max(0, total - g0))
        if rows <= 0:
            continue
        gidx = np.arange(g0, g0 + rows, dtype=np.int64)
        hh = np.searchsorted(offs_np, gidx, side="right") - 1
        for h in range(HEADS):
            sel = hh == h
            if not sel.any():
                continue
            pos = np.nonzero(sel)[0]
            X = w[torch.from_numpy(pos)].to(DEV)
            for m in range(M):
                a, b = m * seg_dim, (m + 1) * seg_dim
                col = torch.empty(X.shape[0], dtype=torch.uint8, device=DEV)
                encode_into(X[:, a:b], CB[h, m], col)
                codes[gidx[pos], m] = col.cpu().numpy()
            del X
        del w
        torch.cuda.empty_cache()
        if n % 8 == 0:
            log(f"[pq] encode pass shard {n}/{PARTS}  {time.time()-t2:.0f}s")
    log(f"[pq] encode pass done in {time.time()-t2:.0f}s")

    art = {
        "format": "pq",
        "heads": HEADS,
        "dim": DIM,
        "M": M,
        "K": K,
        "seg_dim": seg_dim,
        "sizes": sizes,
        "offs": offs,
        "codebooks": CB.to(torch.bfloat16).cpu(),
        "codes": torch.from_numpy(codes),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    torch.save(art, OUT)
    log(f"[pq] saved {OUT} ({os.path.getsize(OUT)/1e9:.2f} GB) "
        f"total {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
