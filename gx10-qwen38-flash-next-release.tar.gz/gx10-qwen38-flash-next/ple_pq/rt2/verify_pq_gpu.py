"""Offline validation for the PQ PLE runtime (v2, GPU gatherer path).

Run inside the serving image with --gpus all. No service, no downtime.

What it proves, in order:
  T1  synthetic artifact loads; format self-detection picks the PQ branch
  T2  CPU decode == an independently written per-row numpy oracle (bit-exact)
  T3  GPU gatherer (Triton + cudaHostRegister UVA) == CPU oracle (bit-exact)
  T4  the full module forward is CAPTURABLE inside a CUDA graph  <-- the one
      that v1 never tested, and the one that cost us the crash loop
  T5  negative control: with VLLM_PLE_GPU=0 the capture fails with our pointed
      error instead of an opaque torch copy error
  T6  same T3/T4 repeated on the real 1.5 GiB ple_pq_M5.pt artifact
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np
import torch

import vllm_ple_mmap as rt

FAILURES = []


def check(name, ok, detail=""):
    tag = "PASS" if ok else "FAIL"
    print(f"[{tag}] {name}" + (f"  {detail}" if detail else ""), flush=True)
    if not ok:
        FAILURES.append(name)


def banner(t):
    print("\n" + "=" * 74 + f"\n{t}\n" + "=" * 74, flush=True)


# ---------------------------------------------------------------- synthetic ---
def build_synthetic(path, seed=0):
    """Real kernel constants (16 heads / M=5 / K=256 / seg=32 / dim=160), few rows."""
    H, M, K, SEG = 16, 5, 256, 32
    per_head = 256
    sizes = np.full(H, per_head, dtype=np.int64)
    offs = np.arange(H, dtype=np.int64) * per_head
    total = H * per_head
    g = np.random.default_rng(seed)
    codebooks = (g.standard_normal((H, M, K, SEG)) * 0.02).astype(np.float32)
    codes = g.integers(0, K, size=(total, M), dtype=np.int64).astype(np.uint8)
    torch.save(
        {
            "codebooks": torch.from_numpy(codebooks),
            "codes": torch.from_numpy(codes),
            "sizes": torch.from_numpy(sizes),
            "offs": torch.from_numpy(offs),
            "M": M, "K": K, "seg": SEG, "heads": H,
        },
        path,
    )
    return codebooks, codes, offs, total


def oracle_bits(codebooks, codes, offs, ids, ws):
    """Independent per-row decode: no torch indexing tricks, just nested loops."""
    H, M, K, SEG = codebooks.shape
    h = np.searchsorted(np.asarray(offs), ids, side="right") - 1
    out = np.empty((len(ids), M * SEG), dtype=np.float32)
    for i in range(len(ids)):
        for m in range(M):
            c = int(codes[int(ids[i]), m])
            out[i, m * SEG:(m + 1) * SEG] = codebooks[int(h[i]), m, c]
    t = torch.from_numpy(out) * ws
    return t.to(torch.bfloat16).view(torch.uint16).numpy()


def bits_of(uint8_rows):
    return np.ascontiguousarray(uint8_rows).view(np.uint16)


WS = 0.000199318
ART = "/tmp/pq_synth.pt"


def load_table(art):
    art_obj = torch.load(art, map_location="cpu", mmap=True, weights_only=True)
    tab = rt.HashKPleTable(art)
    assert tab.format == "pq", f"format self-detection failed: {tab.format!r}"
    tab.fold_weight_scale(WS)
    return tab


# =================================================================== T1 / T2 ===
banner("T1/T2  synthetic artifact: load, self-detect, CPU oracle parity")
cb, codes, offs, total = build_synthetic(ART)
tab = load_table(ART)
check("format self-detected as pq", tab.format == "pq")
check("derived geometry", (tab.heads, tab.M, tab.K, tab.seg, tab.dim, tab.total)
      == (16, 5, 256, 32, 160, total),
      f"{tab.heads}/{tab.M}/{tab.K}/{tab.seg}/{tab.dim}/{tab.total}")
check("row_bytes == dim*2 (bf16 carrier)", tab.row_bytes == 320)

rng = np.random.default_rng(1)
ids = rng.integers(0, total, size=4096, dtype=np.int64)
got = tab._gather_pq(ids)
want = oracle_bits(cb, codes, offs, ids, WS)
nbits = int((bits_of(got) != want).sum())
check("CPU decode == numpy oracle (bit-exact)", nbits == 0, f"{nbits} mismatched bits")
check("gather() dispatch routes to PQ", tab.gather(ids).shape == (4096, 320))

# ======================================================================= T3 ===
banner("T3  GPU gatherer (Triton + UVA) parity vs the CPU oracle")
tab._ensure_gpu_gatherer()
gg = tab.gpu_gatherer
check("gpu_gatherer built", gg is not None,
      "reason above if None" if gg is None else f"route=host heads={gg.heads} M={gg.M}")
if gg is not None:
    ids_c = torch.from_numpy(ids.astype(np.int64)).cuda()
    got_g = gg.gather(ids_c).view(torch.uint16).cpu().numpy()
    nbits = int((got_g.reshape(len(ids), -1) != want).sum())
    check("GPU gather == numpy oracle (bit-exact)", nbits == 0,
          f"{nbits} mismatched bits")
    # odd sizes / boundary ids
    edge = np.array([0, 1, total - 1, offs[1] - 1, offs[1], offs[8], total // 3],
                    dtype=np.int64)
    e_g = gg.gather(torch.from_numpy(edge).cuda()).view(torch.uint16).cpu().numpy()
    e_w = oracle_bits(cb, codes, offs, edge, WS)
    check("GPU gather boundary ids", int((e_g.reshape(len(edge), -1) != e_w).sum()) == 0)

# ======================================================================= T4 ===
banner("T4  CAPTURE TEST -- module forward inside a CUDA graph")
emb = rt._MmapNgramEmbedding(total, 160)
emb.table = tab
emb = emb.cuda()
ids2d = torch.from_numpy(rng.integers(0, total, size=(8, 64), dtype=np.int64)).cuda()

eager = emb(ids2d)
check("eager forward shape", tuple(eager.shape) == (8, 64, 160), str(tuple(eager.shape)))

s = torch.cuda.Stream()
s.wait_stream(torch.cuda.current_stream())
with torch.cuda.stream(s):          # warm the kernel + allocator off-capture
    for _ in range(3):
        emb(ids2d)
torch.cuda.current_stream().wait_stream(s)
torch.cuda.synchronize()

captured_ok = False
try:
    g = torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        out = emb(ids2d)
    torch.cuda.synchronize()
    captured_ok = True
    check("forward captured into a CUDA graph", True)
    g.replay()
    torch.cuda.synchronize()
    nbits = int((out.view(torch.uint16) != eager.view(torch.uint16)).sum())
    check("graph replay == eager (bit-exact)", nbits == 0, f"{nbits} mismatched bits")
except Exception as exc:  # noqa: BLE001
    check("forward captured into a CUDA graph", False, f"{type(exc).__name__}: {exc}")

# ======================================================================= T5 ===
# NOTE: the negative control deliberately aborts a capture, which can leave the
# capture state unusable for the rest of the process. Set PQ_SKIP_T5=1 to run
# the real-artifact capture test (T6) in a clean process.
if os.environ.get("PQ_SKIP_T5") == "1":
    banner("T5  skipped (PQ_SKIP_T5=1)")
else:
  banner("T5  negative control: VLLM_PLE_GPU=0 must fail loudly, not opaquely")
  try:
    os.environ["VLLM_PLE_GPU"] = "0"
    tab2 = load_table(ART)
    emb2 = rt._MmapNgramEmbedding(total, 160).cuda()
    emb2.table = tab2
    emb2(ids2d)                                   # eager CPU path: legal
    s2 = torch.cuda.Stream()
    s2.wait_stream(torch.cuda.current_stream())
    with torch.cuda.stream(s2):
        emb2(ids2d)
    torch.cuda.current_stream().wait_stream(s2)
    torch.cuda.synchronize()
    try:
        g2 = torch.cuda.CUDAGraph()
        with torch.cuda.graph(g2):
            emb2(ids2d)
        check("capture without a GPU gatherer is refused", False,
              "it silently succeeded -- guard did not fire")
    except Exception as exc:  # noqa: BLE001
        msg = str(exc)
        ok = "CPU gather reached inside CUDA graph capture" in msg
        check("capture without a GPU gatherer is refused with our message", ok,
              msg.splitlines()[0][:120])
  finally:
    os.environ.pop("VLLM_PLE_GPU", None)

# ======================================================================= T6 ===
REAL = os.environ.get("PQ_REAL_ART", "")
if REAL and os.path.isfile(REAL):
    banner(f"T6  real artifact: {REAL}")
    t3 = load_table(REAL)
    check("real artifact geometry", (t3.heads, t3.M, t3.K, t3.seg, t3.dim)
          == (16, 5, 256, 32, 160),
          f"{t3.heads} heads M={t3.M} K={t3.K} seg={t3.seg} dim={t3.dim}")
    check("codes rows == total", int(t3.codes.shape[0]) == t3.total,
          f"{int(t3.codes.shape[0])} vs {t3.total}")
    rid = rng.integers(0, t3.total, size=8192, dtype=np.int64)
    t3._ensure_gpu_gatherer()
    check("real GPU gatherer built", t3.gpu_gatherer is not None)
    if t3.gpu_gatherer is not None:
        r_cpu = t3._gather_pq(rid)
        r_gpu = t3.gpu_gatherer.gather(
            torch.from_numpy(rid).cuda()).view(torch.uint16).cpu().numpy()
        nbits = int((r_gpu.reshape(len(rid), -1) != bits_of(r_cpu)).sum())
        check("real GPU gather == real CPU decode (bit-exact)", nbits == 0,
              f"{nbits} mismatched bits")
        emb3 = rt._MmapNgramEmbedding(t3.total, 160).cuda()
        emb3.table = t3
        i3 = torch.from_numpy(rng.integers(0, t3.total, size=(8, 64),
                                           dtype=np.int64)).cuda()
        e3 = emb3(i3)
        s3 = torch.cuda.Stream()
        s3.wait_stream(torch.cuda.current_stream())
        with torch.cuda.stream(s3):
            for _ in range(3):
                emb3(i3)
        torch.cuda.current_stream().wait_stream(s3)
        torch.cuda.synchronize()
        try:
            g3 = torch.cuda.CUDAGraph()
            with torch.cuda.graph(g3):
                o3 = emb3(i3)
            torch.cuda.synchronize()
            g3.replay()          # capture only RECORDS; replay does the work
            torch.cuda.synchronize()
            nbits = int((o3.view(torch.uint16) != e3.view(torch.uint16)).sum())
            check("REAL artifact: capture + replay == eager (bit-exact)", nbits == 0,
                  f"{nbits} mismatched bits")
        except Exception as exc:  # noqa: BLE001
            check("REAL artifact: capture", False, f"{type(exc).__name__}: {exc}")
else:
    print(f"\n(T6 skipped: PQ_REAL_ART={REAL!r})")

# ===================================================================== report ===
banner("RESULT")
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("ALL CHECKS PASSED")
