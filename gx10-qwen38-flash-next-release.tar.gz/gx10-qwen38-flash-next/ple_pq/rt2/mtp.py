# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Inference-only Qwen3.8-Flash-Next MTP (Multi-Token Predictor) model.

The MTP draft model reuses the Qwen3.8-Flash-Next backbone (PLE/HC/MoE) but:
  - drops all multi-modal handling (text-only),
  - forces PLE off while keeping the main model's HC stream count,
  - fuses the backbone hidden and the new-token embedding via
    ``residual_linear_shared`` (fc_embedding + shared fc_hidden) instead of
    the ``Linear(2H, H)`` + repeat used by other MTP variants,
  - emits TWO hidden streams per step (scheme A): a single stream [T, H]
    (final-mixer collapsed, fed to the LM head) and a pre-final-mixer
    multi stream [T, hc_count*H] (fed to the next draft step).
"""

from collections.abc import Iterable

import regex as re
import torch
from torch import nn

from vllm.compilation.decorators import support_torch_compile
from vllm.config import VllmConfig, replace, set_current_vllm_config
from vllm.distributed import get_pp_group
from vllm.model_executor.layers.layernorm import GemmaRMSNorm
from vllm.model_executor.layers.linear import ColumnParallelLinear
from vllm.model_executor.layers.logits_processor import LogitsProcessor
from vllm.model_executor.layers.vocab_parallel_embedding import (
    ParallelLMHead,
    VocabParallelEmbedding,
)
from vllm.model_executor.model_loader.utils import configure_quant_config
from vllm.model_executor.models.interfaces import SupportsPP
from vllm.model_executor.models.qwen3_5 import Qwen3_5Model
from vllm.model_executor.models.utils import (
    AutoWeightsLoader,
    PPMissingLayer,
    get_draft_quant_config,
    make_empty_intermediate_tensors_factory,
    maybe_fuse_shared_experts,
    maybe_prefix,
)
from vllm.sequence import IntermediateTensors
from vllm.transformers_utils.configs.qwen3_8_flash_next import (
    Qwen3_8FlashNextTextConfig,
)

from .hyperconnection import GatedResidual, HyperConnectionConfig
from .low_latency_gemm import enable_qwen38next_low_latency_gemm
from .model import (
    _HC_WEIGHTS_MAPPER,
    _QWEN38_FLASH_NEXT_IGNORED_MISSING_SUFFIXES,
    Qwen3_8FlashNextDecoderLayer,
    Qwen3_8FlashNextMixtureOfExperts,
)


def _remap_ignored_layers(
    ignored_layers: list[str],
    mtp_start_layer_idx: int,
) -> list[str]:
    remapped: list[str] = []
    for name in ignored_layers:
        if name.startswith("mtp."):
            new_name = re.sub(
                r"(?<=\.layers\.)\d+",
                lambda m: str(mtp_start_layer_idx + int(m.group(0))),
                name,
            )
            remapped.append(new_name)
        else:
            remapped.append(name)
    return remapped


def _remap_mtp_weight_name(name: str) -> str | None:
    """Map Qwen3.8-Flash-Next checkpoint paths into the standalone draft model."""

    for checkpoint_prefix in (
        "model.language_model.",
        "language_model.",
    ):
        if name.startswith(checkpoint_prefix):
            name = name.removeprefix(checkpoint_prefix)
            break

    if name.startswith("embed_tokens."):
        name = f"model.{name}"
    if name.startswith("model.mtp."):
        name = name.removeprefix("model.")
    if name.startswith("mtp.shared_head.head."):
        return name.replace("mtp.shared_head.head.", "lm_head.", 1)
    if name.startswith("model.shared_head.head."):
        return name.replace("model.shared_head.head.", "lm_head.", 1)
    if name.startswith("shared_head.head."):
        return name.replace("shared_head.head.", "lm_head.", 1)
    if name.startswith("model.lm_head."):
        return name.removeprefix("model.")
    if name.startswith("mtp."):
        return name.replace("mtp.", "model.", 1)
    if name.startswith("model.embed_tokens.") or name.startswith("lm_head."):
        return name
    return None


def _make_draft_vllm_config(
    vllm_config: VllmConfig,
    mtp_start_layer_idx: int,
) -> VllmConfig:
    """Ensure that the draft model config is set in the vLLM config."""
    speculative_config = vllm_config.speculative_config
    if speculative_config is None or speculative_config.draft_model_config is None:
        raise ValueError("speculative_config.draft_model_config must be set")

    draft_quant_config = get_draft_quant_config(vllm_config)

    # inject packed and ignored modules to the quantization config of draft model
    if draft_quant_config is not None:
        configure_quant_config(draft_quant_config, Qwen3_8FlashNextMTP)
        ignored_layers = getattr(draft_quant_config, "ignored_layers", None)
        if ignored_layers:
            setattr(  # noqa: B010
                draft_quant_config,
                "ignored_layers",
                _remap_ignored_layers(ignored_layers, mtp_start_layer_idx),
            )
        exclude_modules = getattr(draft_quant_config, "exclude_modules", None)
        if exclude_modules:
            setattr(  # noqa: B010
                draft_quant_config,
                "exclude_modules",
                _remap_ignored_layers(exclude_modules, mtp_start_layer_idx),
            )

    draft_vllm_config = replace(
        vllm_config,
        model_config=speculative_config.draft_model_config,
    )
    # VllmConfig post-init derives the target quant config, so restore the
    # independently resolved draft quant config after replacement.
    draft_vllm_config.quant_config = draft_quant_config
    return draft_vllm_config


@support_torch_compile(
    dynamic_arg_dims={
        "input_ids": 0,
        "positions": -1,
        "intermediate_tensors": 0,
        "inputs_embeds": 0,
        "hidden_states": 0,
    }
)
class Qwen3_8FlashNextMultiTokenPredictor(nn.Module):
    hf_to_vllm_mapper = Qwen3_5Model.hf_to_vllm_mapper | _HC_WEIGHTS_MAPPER

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = "") -> None:
        super().__init__()

        model_config = vllm_config.model_config
        config: Qwen3_8FlashNextTextConfig = model_config.hf_text_config

        self.config = config
        self.vocab_size = config.vocab_size

        self.mtp_start_layer_idx = config.num_hidden_layers
        self.num_mtp_layers = getattr(config, "mtp_num_hidden_layers", 1)

        self.hidden_size = config.hidden_size
        self.hc_count = config.hc_count

        self.embed_tokens = VocabParallelEmbedding(self.vocab_size, self.hidden_size)
        draft_vllm_config = _make_draft_vllm_config(
            vllm_config,
            self.mtp_start_layer_idx,
        )
        with set_current_vllm_config(draft_vllm_config, prefix=prefix):
            # residual_linear_shared fusion: fc_embedding projects the token
            # embedding, fc_hidden (shared across HC branches) projects the
            # backbone hidden; the embedding is added as a residual to every
            # branch (see mtp_residual_linear_shared.md).
            self.fc_embedding = ColumnParallelLinear(
                self.hidden_size,
                self.hidden_size,
                gather_output=True,
                bias=False,
                return_bias=False,
                quant_config=draft_vllm_config.quant_config,
                prefix=f"{prefix}.fc_embedding",
            )
            self.fc_hidden = ColumnParallelLinear(
                self.hidden_size,
                self.hidden_size,
                gather_output=True,
                bias=False,
                return_bias=False,
                quant_config=draft_vllm_config.quant_config,
                prefix=f"{prefix}.fc_hidden",
            )
            self.layers = nn.ModuleList(
                Qwen3_8FlashNextDecoderLayer(
                    draft_vllm_config,
                    layer_type="full_attention",
                    prefix=f"{prefix}.layers.{self.mtp_start_layer_idx + idx}",
                )
                for idx in range(self.num_mtp_layers)
            )

        self.pre_fc_norm_embedding = GemmaRMSNorm(
            self.hidden_size, eps=config.rms_norm_eps
        )
        self.pre_fc_norm_hidden = GemmaRMSNorm(
            self.hidden_size * self.hc_count, eps=config.rms_norm_eps
        )
        # HC final mixer collapses the multi stream into [T, H] for the LM head.
        hc_config = HyperConnectionConfig(
            hc_count=config.hc_count,
            hidden_size=config.hidden_size,
            params_dtype=torch.bfloat16,
            hc_lowrank=config.hc_lowrank,
            rms_norm_eps=config.rms_norm_eps,
            hc_per_branch_norm=True,
        )
        self.hyper_connection_mixer = GatedResidual(
            hc_config,
            use_combine=False,
            prefix=maybe_prefix(prefix, "hyper_connection_mixer"),
        )
        self.make_empty_intermediate_tensors = make_empty_intermediate_tensors_factory(
            ["hidden_states"], self.hidden_size * self.hc_count
        )

    def _iter_qsa_attentions(self):
        """Yield MTP attention modules that own a QSA indexer."""

        for layer in self.layers:
            attention = getattr(layer, "self_attn", None)
            if (
                attention is not None
                and getattr(attention, "indexer", None) is not None
            ):
                yield attention

    def set_skip_topk(self, skip: bool) -> None:
        """Select on MTP step 0 and reuse its QSA indices on later steps."""

        for attention in self._iter_qsa_attentions():
            attention.indexer.skip_topk = skip

    def compact_topk_indices(self, row_indices: torch.Tensor) -> None:
        """Keep each request's target-aligned step-0 sparse-index row."""

        num_rows = row_indices.numel()
        for attention in self._iter_qsa_attentions():
            buffer = attention.topk_indices_buffer
            selected = buffer.index_select(0, row_indices)
            buffer[:num_rows].copy_(selected)

    def embed_input_ids(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.embed_tokens(input_ids)

    def forward(
        self,
        input_ids: torch.Tensor | None,
        positions: torch.Tensor,
        hidden_states: torch.Tensor | None = None,
        intermediate_tensors: IntermediateTensors | None = None,
        inputs_embeds: torch.Tensor | None = None,
        spec_step_idx: int = 0,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor] | IntermediateTensors:
        hc_count = self.hc_count
        hidden_size = self.hidden_size

        if get_pp_group().is_first_rank:
            assert hidden_states is not None
            if inputs_embeds is None:
                assert input_ids is not None
                inputs_embeds = self.embed_input_ids(input_ids)
            # Embedding branch: pre-norm -> fc_embedding -> [T, H].
            inputs_embeds = self.pre_fc_norm_embedding(inputs_embeds)
            inputs_embeds = self.fc_embedding(inputs_embeds)

            # Backbone hidden is multi-stream [T, hc_count*H] (scheme A:
            # the main model truly emits the pre-final-mixer multi stream
            # on the first step; subsequent steps reuse the prior draft
            # step's multi stream).
            num_tokens = hidden_states.shape[0]
            hidden_states = hidden_states.view(num_tokens, hc_count, hidden_size)
            hidden_states = self.pre_fc_norm_hidden(hidden_states.flatten(-2)).view(
                num_tokens, hc_count, hidden_size
            )
            hidden_states = self.fc_hidden(hidden_states)
            # Add the embedding residual to every branch, then fold back
            # to [T, hc_count*H] (HC outer, HS inner) for the HC decoder.
            hidden_states = inputs_embeds.unsqueeze(-2) + hidden_states
            hidden_states = hidden_states.flatten(-2)
        else:
            assert intermediate_tensors is not None
            hidden_states = intermediate_tensors["hidden_states"]

        current_step_idx = spec_step_idx % self.num_mtp_layers
        layer = self.layers[current_step_idx]
        hidden_states, block_output, injection = layer(
            hidden_states=hidden_states,
            prev_block_output=None,
            prev_injection=None,
            positions=positions,
            input_ids=None,
            query_start_loc=None,
            ngram_context=None,
        )
        if not get_pp_group().is_last_rank:
            # As in the target model, PP carries a materialized tensor rather
            # than the delayed hidden/output/injection tuple.
            hidden_states = layer.mlp_hyper_connection.combine(
                hidden_states, block_output, injection
            )
            return IntermediateTensors({"hidden_states": hidden_states})

        # Last PP rank finalize. Keep both:
        #   (A) sample_hidden_states [T, H]  -> single stream for the LM head
        #   (B) multi_hidden [T, hc_count*H] -> pre-final-mixer multi stream
        #       for the next draft step (zero extra compute, just kept).
        multi_hidden, sample_hidden_states, _ = (
            self.hyper_connection_mixer.combine_and_mix(
                hidden_states, block_output, injection
            )
        )
        return sample_hidden_states, multi_hidden

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        weights = maybe_fuse_shared_experts(
            weights,
            n_routed_experts=getattr(self.config, "num_experts", 0) or 0,
            n_shared_experts=1,
            ckpt_prefix="mlp.shared_expert",
        )
        loader = AutoWeightsLoader(
            self,
            skip_substrs=["hyper_connection_mixer.block_inject_weight"],
            ignore_unexpected_suffixes=_QWEN38_FLASH_NEXT_IGNORED_MISSING_SUFFIXES.copy(),
        )
        return loader.load_weights(weights, mapper=self.hf_to_vllm_mapper)


@support_torch_compile(
    dynamic_arg_dims={
        "input_ids": 0,
        "positions": -1,
        "intermediate_tensors": 0,
        "inputs_embeds": 0,
        "hidden_states": 0,
    }
)
class Qwen3_8FlashNextMTP(nn.Module, SupportsPP, Qwen3_8FlashNextMixtureOfExperts):
    packed_modules_mapping = {
        "qkv_proj": ["q_proj", "k_proj", "v_proj"],
        "gate_up_proj": ["gate_proj", "up_proj"],
        "in_proj_qkvz": ["in_proj_qkv", "in_proj_z"],
        "in_proj_ba": ["in_proj_b", "in_proj_a"],
        "input_mix_weight_down_block_inject": [
            "input_mix_weight_down",
            "block_inject_weight",
            "_input_mix_padding",
        ],
    }

    def __init__(self, *, vllm_config: VllmConfig, prefix: str = "") -> None:
        config: Qwen3_8FlashNextTextConfig = vllm_config.model_config.hf_text_config
        self.vllm_config = vllm_config
        cache_config = vllm_config.cache_config
        if cache_config.mamba_cache_mode == "all":
            raise NotImplementedError(
                "Qwen3_8FlashNextMTP currently does not support 'all' prefix caching, "
                "please use '--mamba-cache-mode=align' instead"
            )

        self.quant_config = vllm_config.quant_config

        super().__init__()
        self.config = config
        self.model = Qwen3_8FlashNextMultiTokenPredictor(
            vllm_config=vllm_config,
            prefix=maybe_prefix(prefix, "mtp"),
        )

        if get_pp_group().is_last_rank:
            if config.tie_word_embeddings:
                self.lm_head = self.model.embed_tokens
            else:
                self.lm_head = ParallelLMHead(
                    config.vocab_size,
                    config.hidden_size,
                    prefix=maybe_prefix(prefix, "lm_head"),
                )
        else:
            self.lm_head = PPMissingLayer()

        self.logits_processor = LogitsProcessor(config.vocab_size)
        self.make_empty_intermediate_tensors = (
            self.model.make_empty_intermediate_tensors
        )
        self.set_moe_parameters(self.model.layers)
        enable_qwen38next_low_latency_gemm(self, vllm_config.model_config.dtype)

    def embed_input_ids(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.model.embed_input_ids(input_ids)

    def forward(
        self,
        input_ids: torch.Tensor | None,
        positions: torch.Tensor,
        hidden_states: torch.Tensor | None = None,
        intermediate_tensors: IntermediateTensors | None = None,
        inputs_embeds: torch.Tensor | None = None,
        spec_step_idx: int = 0,
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor] | IntermediateTensors:
        return self.model(
            input_ids,
            positions,
            hidden_states,
            intermediate_tensors,
            inputs_embeds,
            spec_step_idx=spec_step_idx,
        )

    def compute_logits(
        self, hidden_states: torch.Tensor, spec_step_idx: int = 0
    ) -> torch.Tensor | None:
        return self.logits_processor(self.lm_head, hidden_states)

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        def remap_weight_names():
            for name, weight in weights:
                remapped_name = _remap_mtp_weight_name(name)
                if remapped_name is not None:
                    yield remapped_name, weight

        loader = AutoWeightsLoader(
            self,
            skip_substrs=["hyper_connection_mixer.block_inject_weight"],
            ignore_unexpected_suffixes=_QWEN38_FLASH_NEXT_IGNORED_MISSING_SUFFIXES.copy(),
        )
        return loader.load_weights(remap_weight_names())


__all__ = ["Qwen3_8FlashNextMTP", "Qwen3_8FlashNextMultiTokenPredictor"]


# --- reduced-vocabulary MTP draft ---------------------------------
# Draft-step argmax over ids [0, N), N = VLLM_QWEN_DRAFT_VOCAB. No-op unless
# set AND speculative-config use_local_argmax_reduction=true. Target verifies
# over the full vocab: greedy outputs stay bit-exact at any N.
_DV_RAW = __import__("os").environ.get("VLLM_QWEN_DRAFT_VOCAB", "0")
_DV_N = int(_DV_RAW) if _DV_RAW.strip().isdigit() else 0


def _dv_get_top_tokens(self, hidden_states):
    w = self.lm_head.weight
    ok = getattr(self, "_dv_ok", None)
    if ok is None:
        try:
            from vllm.distributed import get_tensor_model_parallel_world_size
            _tp = get_tensor_model_parallel_world_size()
        except Exception:
            _tp = 1
        ok = (_DV_N > 0) and _tp == 1 and 0 < _DV_N < w.shape[0]
        if (_DV_N > 0) and not ok:
            __import__("vllm.logger", fromlist=["init_logger"]).init_logger(
                __name__).warning(
                "draft_vocab=%d not sliceable (tp=%d, head rows=%d); "
                "using full-vocab draft argmax", _DV_N, _tp, w.shape[0])
        self._dv_ok = ok
    if ok:
        return (hidden_states @ w[:_DV_N].t()).argmax(dim=-1)
    return self.logits_processor(self.lm_head, hidden_states).argmax(dim=-1)


if _DV_N > 0:
    Qwen3_8FlashNextMTP.get_top_tokens = _dv_get_top_tokens
# --- end reduced-vocabulary MTP draft ---


# --- MTP draft head: FP8 two-stage proposal (env VLLM_MTP_HEAD_FP8=1) ------------
# The draft head only *proposes*; the target verifies. Reading the [N, H] head in
# fp8 halves the single dominant per-step read of the draft (720 -> 360 MiB at
# N=147456) and this function runs once per draft step (4x per decode step at
# MTP=4). Bare fp8 flips ~10% of the top-1 picks, which would cost acceptance,
# so fp8 only does the *search*: the top-K candidate rows are then re-scored
# exactly (fp32 accumulate) from the bf16 weight, recovering the bf16 argmax.
# Measured recall@K on the real weight: 100% at K=8 for every hidden scale, so
# K=32 leaves a wide margin for ~160 KB of extra read.
# Env: VLLM_MTP_HEAD_FP8=1 (default off), VLLM_MTP_HEAD_FP8_K=64.
_MH_ON = __import__("os").environ.get("VLLM_MTP_HEAD_FP8", "0").strip().lower() in (
    "1", "true", "yes", "on")
_MH_K = int(__import__("os").environ.get("VLLM_MTP_HEAD_FP8_K", "64") or "64")

if _MH_ON and _DV_N <= 0:
    __import__("vllm.logger", fromlist=["init_logger"]).init_logger(__name__).warning(
        "VLLM_MTP_HEAD_FP8=1 needs VLLM_QWEN_DRAFT_VOCAB>0 (sliced draft head); not enabled")
    _MH_ON = False

if _MH_ON:
    import torch as _mh_torch
    from vllm.logger import init_logger as _mh_init_logger

    _mh_log = _mh_init_logger("vllm.mtp_head_fp8")
    _mh_prev_get_top_tokens = Qwen3_8FlashNextMTP.get_top_tokens

    def _mh_mm(h2, self):
        """fp8 logits over the draft vocab slice: [T, H] x [H, N] -> [T, N] bf16."""
        sa = (h2.abs().amax().clamp_min(1e-8) / 448.0).to(_mh_torch.float32).reshape(1)
        h8 = (h2 / sa).to(_mh_torch.float8_e4m3fn)
        return _mh_torch._scaled_mm(
            h8, self._mh_w8, sa, self._mh_sb, out_dtype=_mh_torch.bfloat16)

    def _mh_rerank(lg8, h2, self):
        k = min(_MH_K, lg8.shape[-1])
        idx = _mh_torch.topk(lg8, k, dim=-1).indices                     # [T, k]
        wbf = self._mh_wbf
        sel = wbf[idx.reshape(-1)].view(idx.shape[0], k, wbf.shape[1])   # bf16 gather
        exact = _mh_torch.einsum(
            "tkh,tkh->tk",
            h2.float().unsqueeze(1).expand(-1, k, -1),
            sel.float())
        return idx.gather(1, exact.argmax(-1, keepdim=True)).squeeze(1)

    def _mh_build(self):
        """Quantise the draft head slice. Idempotent; never runs during capture."""
        if getattr(self, "_mh_ready", None) is not None:
            return
        if _mh_torch.cuda.is_current_stream_capturing():
            return
        w = self.lm_head.weight
        if w.dim() != 2 or w.shape[0] < _DV_N:
            _mh_log.warning("[mtp-head-fp8] head %s unusable (need >= %d rows); disabled",
                            tuple(w.shape), _DV_N)
            self._mh_ready = False
            return
        try:
            wbf = w[:_DV_N]
            s = (wbf.abs().amax().clamp_min(1e-8) / 448.0).to(_mh_torch.float32)
            self._mh_wbf = wbf
            _mh_t8 = (wbf / s).to(_mh_torch.float8_e4m3fn)      # [N, H] fp8 temp
            self._mh_w8 = _mh_t8.t().contiguous()               # [H, N] fp8
            del _mh_t8
            self._mh_sb = s.reshape(1)
            self._mh_ready = True
            _mh_torch.cuda.empty_cache()   # drop build temps before profiling
            _mh_log.info(
                "[mtp-head-fp8] ON: rows=%d K=%d | read %.0f MiB bf16 -> %.0f MiB fp8 "
                "(+%.0f KB rerank) | head amax=%.5f",
                _DV_N, _MH_K, wbf.numel() * 2 / 1048576, self._mh_w8.numel() / 1048576,
                _MH_K * wbf.shape[1] * 2 / 1024, float(s) * 448.0)
            _mh_selfcheck(self)
        except Exception as exc:  # pragma: no cover - defensive
            n = getattr(self, "_mh_fails", 0) + 1
            self._mh_fails = n
            if n >= 3:
                self._mh_ready = False
                _mh_log.warning(
                    "[mtp-head-fp8] build failed %d times (%r); giving up, bf16 path",
                    n, exc)
            else:
                _mh_log.warning(
                    "[mtp-head-fp8] build attempt %d failed: %r (will retry)", n, exc)

    def _mh_selfcheck(self):
        try:
            with _mh_torch.no_grad():
                hd = self._mh_wbf.shape[1]
                hs = _mh_torch.randn(64, hd, dtype=_mh_torch.bfloat16,
                                     device=self._mh_wbf.device)
                ref = (hs @ self._mh_wbf.t()).argmax(-1)
                lg8 = _mh_mm(hs, self)
                raw = lg8.argmax(-1)
                two = _mh_rerank(lg8, hs, self)
                _mh_log.info(
                    "[mtp-head-fp8] selfcheck (64 synthetic hidden): raw-fp8 top1=%.1f%%, "
                    "two-stage top1=%.1f%%",
                    (raw == ref).float().mean().item() * 100,
                    (two == ref).float().mean().item() * 100)
                del hs, ref, lg8, raw, two
        except Exception as exc:  # pragma: no cover - defensive
            _mh_log.warning("[mtp-head-fp8] selfcheck skipped: %r", exc)

    def _mh_get_top_tokens(self, hidden_states):
        if getattr(self, "_mh_ready", None) is None:
            _mh_build(self)
        if getattr(self, "_mh_ready", None) is True:
            h2 = hidden_states.reshape(-1, hidden_states.shape[-1])
            lg8 = _mh_mm(h2, self)
            out = _mh_rerank(lg8, h2, self)
            if not getattr(self, "_mh_checked", False):
                self._mh_checked = True
                try:
                    ref = (h2 @ self._mh_wbf.t()).argmax(-1)   # true bf16
                    _mh_log.info(
                        "[mtp-head-fp8] PROD check (first real draft step, T=%d): "
                        "raw-fp8 top1=%.1f%%, two-stage top1=%.1f%% (bf16 truth)",
                        h2.shape[0],
                        (lg8.argmax(-1) == ref).float().mean().item() * 100,
                        (out == ref).float().mean().item() * 100)
                    del ref
                except Exception as exc:
                    _mh_log.warning("[mtp-head-fp8] PROD check skipped: %r", exc)
                _mh_torch.cuda.empty_cache()
            return out
        return _mh_prev_get_top_tokens(self, hidden_states)

    _mh_prev_load_weights = Qwen3_8FlashNextMTP.load_weights

    def _mh_load_weights(self, weights):
        out = _mh_prev_load_weights(self, weights)
        # Flag this lm_head as the *draft* head: the fp8-hybrid shim must
        # never fp8-ise it.  Both heads are ParallelLMHead over the same
        # remapped bf16 checkpoint tensor, so type alone cannot tell them
        # apart (lm_head is on the quant ignore list, so ModelOpt's
        # get_quant_method never runs for it either).
        try:
            self.lm_head.__dict__["_lmhead_fp8_skip"] = True
        except Exception:
            pass
        _mh_build(self)
        return out

    Qwen3_8FlashNextMTP.get_top_tokens = _mh_get_top_tokens
    Qwen3_8FlashNextMTP.load_weights = _mh_load_weights
    _mh_log.info("[mtp-head-fp8] patched get_top_tokens (N=%d, K=%d, fallback=%s)",
                 _DV_N, _MH_K, getattr(_mh_prev_get_top_tokens, "__name__", "?"))
# --- end MTP draft head fp8 two-stage -------------------------------------------


# --- MTP draft head: NVFP4 search stage (env VLLM_MTP_HEAD_4BIT=1) ----------------
# Halves the draft head's search read one more time on top of the fp8 path above.
# The sliced head is [147456, 2560]: 755 MiB bf16 -> 377 MiB fp8 -> 212 MiB nvfp4
# (0.5 byte/param + an e4m3 block scale per 16).  At MTP=4 that is
# 3.02 -> 1.51 -> 0.85 GB *per decode step*, and the draft head is the single
# largest read of a decode step -- bigger than the target lm_head (1.271 GB).
#
# Same contract as the fp8 path: fp4 only *proposes*, then the top-K candidate
# rows are re-scored exactly in bf16, so greedy output is unchanged as long as
# the true top-1 survives inside the candidate set.  Measured on the real weight
# slice (tools/mtp_head_nvfp4_probe.py, 64 hidden probes across 4 scales):
#     fp8   per-tensor : bare top1  3/64,  recall@K 64/64 already at K=8
#     nvfp4 e2m1 blk16 : bare top1 13/64,  recall@K 64/64 already at K=8
# fp4 is visibly lossier in the raw search (20% vs 5% top-1 flips) yet its errors
# still land outside the top-K, so the rerank restores the bf16 argmax exactly
# (64/64 at K>=16).  K=32 therefore keeps a 4x margin.
#
# Two things are deliberately verified at *runtime* before this is trusted,
# because neither can be checked offline on this box -- the running vLLM has the
# whole 128 GB unified pool, so a second CUDA context cannot even be created:
#   1. a numerical selfcheck against the bf16 head right after the build
#   2. a microbenchmark of fp8 vs fp4 GEMV at the *live* shape (M = draft batch,
#      N = 147456).  fp4 wins on bytes by construction, but a cutlass fp4 kernel
#      at M=1 on sm_121 could still lose to fp8; that is measured, not assumed.
# If either check fails the search stays on fp8 and behaviour is unchanged.
#
# Env: VLLM_MTP_HEAD_4BIT=1       enable (requires VLLM_MTP_HEAD_FP8=1)
#      VLLM_MTP_HEAD_4BIT=probe   build + selfcheck + microbench, log only, keep
#                                 the fp8 search (zero-risk measurement run)
#      VLLM_MTP_HEAD_4BIT_K=64    rerank width, independent of the fp8 K
#      VLLM_MTP_HEAD_4BIT_MB=1    1 = run the fp8-vs-fp4 microbench at build time
_MH4_MODE = __import__("os").environ.get("VLLM_MTP_HEAD_4BIT", "0").strip().lower()
_MH4_ON = _MH4_MODE in ("1", "true", "yes", "on", "probe")
_MH4_PROBE_ONLY = _MH4_MODE == "probe"
_MH4_K = int(__import__("os").environ.get("VLLM_MTP_HEAD_4BIT_K", "64") or "64")
_MH4_MB = __import__("os").environ.get(
    "VLLM_MTP_HEAD_4BIT_MB", "1").strip().lower() in ("1", "true", "yes", "on")

if _MH4_ON and not _MH_ON:
    __import__("vllm.logger", fromlist=["init_logger"]).init_logger(__name__).warning(
        "VLLM_MTP_HEAD_4BIT needs VLLM_MTP_HEAD_FP8=1 (the fp8 path builds the "
        "bf16 slice and the rerank machinery); not enabled")
    _MH4_ON = False

if _MH4_ON:
    import torch as _mh4_torch

    _mh4_log = _mh_init_logger("vllm.mtp_head_nvfp4")
    _MH4_ST = {"built": False, "fails": 0, "use": False}
    # e2m1 is sign + 3-bit magnitude {0,.5,1,1.5,2,3,4,6}; the two-level NVFP4
    # scale keeps every block scale inside e4m3 range (see modelopt: alpha =
    # input_global_scale * weight_global_scale, global_scale = 6*448/amax).
    _MH4_E2M1_MAX = 6.0
    _MH4_E4M3_MAX = 448.0

    def _mh4_mm(h2, self):
        """fp4 logits over the draft vocab slice: [T, H] -> [T, N] bf16."""
        from vllm._custom_ops import cutlass_scaled_fp4_mm, scaled_fp4_quant

        h = h2.reshape(-1, h2.shape[-1])
        if h.dtype != _mh4_torch.bfloat16:
            h = h.to(_mh4_torch.bfloat16)
        amax = h.abs().amax().clamp_min(1e-8).to(_mh4_torch.float32)
        gs_x = (_MH4_E2M1_MAX * _MH4_E4M3_MAX) / amax
        hq, hs = scaled_fp4_quant(
            h, gs_x.reshape(1), is_sf_swizzled_layout=True, backend="cutlass")
        alpha = (1.0 / (gs_x * self._mh4_gsw)).reshape(1).to(_mh4_torch.float32)
        return cutlass_scaled_fp4_mm(
            hq, self._mh4_wq, hs, self._mh4_ws, alpha, _mh4_torch.bfloat16)

    def _mh4_rerank(lg4, h2, self):
        k = min(_MH4_K, lg4.shape[-1])
        idx = _mh4_torch.topk(lg4, k, dim=-1).indices                     # [T, k]
        wbf = self._mh_wbf
        sel = wbf[idx.reshape(-1)].view(idx.shape[0], k, wbf.shape[1])    # bf16 gather
        exact = _mh4_torch.einsum(
            "tkh,tkh->tk",
            h2.float().unsqueeze(1).expand(-1, k, -1),
            sel.float())
        return idx.gather(1, exact.argmax(-1, keepdim=True)).squeeze(1)

    def _mh4_build(self):
        """Quantise the draft head slice to NVFP4. Idempotent; never during capture."""
        if _MH4_ST["built"] or _MH4_ST["fails"] >= 3:
            return
        if _mh4_torch.cuda.is_current_stream_capturing():
            return
        wbf = getattr(self, "_mh_wbf", None)
        if wbf is None or wbf.dim() != 2:
            _mh4_log.warning(
                "[mtp-head-4bit] no bf16 head slice yet (_mh_wbf missing); fp8 kept")
            _MH4_ST["built"] = True
            return
        try:
            from vllm._custom_ops import scaled_fp4_quant
            from vllm.model_executor.layers.quantization.utils.nvfp4_utils import (
                swizzle_blockscale)

            wbf = wbf.contiguous()
            rows, cols = wbf.shape
            amax = wbf.abs().amax().clamp_min(1e-8).to(_mh4_torch.float32)
            gs_w = (_MH4_E2M1_MAX * _MH4_E4M3_MAX) / amax
            wq, wbs = scaled_fp4_quant(
                wbf, gs_w.reshape(1), is_sf_swizzled_layout=False)
            self._mh4_wq = wq
            self._mh4_ws = swizzle_blockscale(wbs)
            self._mh4_gsw = gs_w
            _mh4_log.info(
                "[mtp-head-4bit] built: rows=%d K=%d | packed fp4 %.0f MiB + swizzled "
                "scale %.0f MiB (fp8 %.0f MiB, bf16 %.0f MiB) | amax=%.5f gs=%.4e",
                rows, cols, wq.numel() / 1048576, self._mh4_ws.numel() / 1048576,
                rows * cols / 1048576, wbf.numel() * 2 / 1048576,
                float(amax), float(gs_w))

            ok = _mh4_selfcheck(self)
            fast = _mh4_microbench(self) if _MH4_MB else True
            _MH4_ST["use"] = bool(ok and fast)
            _MH4_ST["built"] = True
            _mh4_log.info(
                "[mtp-head-4bit] selfcheck=%s microbench=%s -> search back-end = %s"
                "%s", ok, fast, "nvfp4" if _MH4_ST["use"] else "fp8",
                " (probe-only, behaviour unchanged)" if _MH4_PROBE_ONLY else "")
            _mh4_torch.cuda.empty_cache()
        except Exception as exc:  # pragma: no cover - defensive
            _MH4_ST["fails"] += 1
            _mh4_log.warning(
                "[mtp-head-4bit] build failed %d/3: %r; fp8 kept",
                _MH4_ST["fails"], exc)

    def _mh4_selfcheck(self):
        try:
            with _mh4_torch.no_grad():
                hd = self._mh_wbf.shape[1]
                hs = _mh4_torch.randn(64, hd, dtype=_mh4_torch.bfloat16,
                                      device=self._mh_wbf.device)
                ref = (hs @ self._mh_wbf.t()).argmax(-1)
                lg4 = _mh4_mm(hs, self)
                raw = lg4.argmax(-1)
                two = _mh4_rerank(lg4, hs, self)
                r = (raw == ref).float().mean().item() * 100
                t = (two == ref).float().mean().item() * 100
                _mh4_log.info(
                    "[mtp-head-4bit] selfcheck (64 synthetic hidden): raw-fp4 top1="
                    "%.1f%%, two-stage top1=%.1f%%", r, t)
                del hs, ref, lg4, raw, two
                return t >= 98.0
        except Exception as exc:  # pragma: no cover - defensive
            _mh4_log.warning("[mtp-head-4bit] selfcheck failed: %r", exc)
            return False

    def _mh4_microbench(self):
        """fp8 vs fp4 GEMV at the live shape; fp4 must actually be faster."""
        try:
            hd = self._mh_wbf.shape[1]
            hs = _mh4_torch.randn(1, hd, dtype=_mh4_torch.bfloat16,
                                  device=self._mh_wbf.device)

            def _t(fn, iters=50, warm=10):
                for _ in range(warm):
                    fn()
                _mh4_torch.cuda.synchronize()
                a = _mh4_torch.cuda.Event(True)
                b = _mh4_torch.cuda.Event(True)
                a.record()
                for _ in range(iters):
                    fn()
                b.record()
                _mh4_torch.cuda.synchronize()
                return a.elapsed_time(b) / iters * 1000.0          # microseconds

            n_el = self._mh_wbf.numel()
            t8 = _t(lambda: _mh_mm(hs, self))
            t4 = _t(lambda: _mh4_mm(hs, self))
            _mh4_log.info(
                "[mtp-head-4bit] microbench M=1 N=%d: fp8 %.1f us (%.0f GB/s eff) | "
                "fp4 %.1f us (%.0f GB/s eff) | speedup %.2fx",
                self._mh_wbf.shape[0], t8, (n_el / 1e9) / (t8 / 1e6),
                t4, (n_el * 0.5625 / 1e9) / (t4 / 1e6), t8 / t4)
            del hs
            # require a real win, not noise: the extra 0.6 GB of build-time
            # residency and the fp4 quantisation of the activation both have to
            # pay for themselves
            return t4 <= t8 * 0.98
        except Exception as exc:  # pragma: no cover - defensive
            _mh4_log.warning("[mtp-head-4bit] microbench failed: %r", exc)
            return False

    _mh4_prev_get_top_tokens = Qwen3_8FlashNextMTP.get_top_tokens

    def _mh4_get_top_tokens(self, hidden_states):
        if not _MH4_ST["built"] and _MH4_ST["fails"] < 3:
            _mh4_build(self)
        if _MH4_ST["use"] and not _MH4_PROBE_ONLY:
            try:
                h2 = hidden_states.reshape(-1, hidden_states.shape[-1])
                lg4 = _mh4_mm(h2, self)
                out = _mh4_rerank(lg4, h2, self)
                if not getattr(self, "_mh4_checked", False):
                    self._mh4_checked = True
                    try:
                        ref = (h2 @ self._mh_wbf.t()).argmax(-1)     # true bf16
                        _mh4_log.info(
                            "[mtp-head-4bit] PROD check (first real draft step, "
                            "T=%d): raw-fp4 top1=%.1f%%, two-stage top1=%.1f%% "
                            "(bf16 truth)", h2.shape[0],
                            (lg4.argmax(-1) == ref).float().mean().item() * 100,
                            (out == ref).float().mean().item() * 100)
                        del ref
                    except Exception as exc:
                        _mh4_log.warning("[mtp-head-4bit] PROD check skipped: %r", exc)
                    _mh4_torch.cuda.empty_cache()
                return out
            except Exception as exc:
                _MH4_ST["use"] = False
                _mh4_log.warning(
                    "[mtp-head-4bit] runtime error: %r; falling back to fp8", exc)
        return _mh4_prev_get_top_tokens(self, hidden_states)

    _mh4_prev_load_weights = Qwen3_8FlashNextMTP.load_weights

    def _mh4_load_weights(self, weights):
        out = _mh4_prev_load_weights(self, weights)
        # Flag this lm_head as the *draft* head: the fp8-hybrid shim must
        # never fp8-ise it.  Both heads are ParallelLMHead over the same
        # remapped bf16 checkpoint tensor, so type alone cannot tell them
        # apart (lm_head is on the quant ignore list, so ModelOpt's
        # get_quant_method never runs for it either).
        try:
            self.lm_head.__dict__["_lmhead_fp8_skip"] = True
        except Exception:
            pass
        _mh4_build(self)
        return out

    Qwen3_8FlashNextMTP.get_top_tokens = _mh4_get_top_tokens
    Qwen3_8FlashNextMTP.load_weights = _mh4_load_weights
    _mh4_log.info(
        "[mtp-head-4bit] patched get_top_tokens (N=%d, K=%d, mode=%s, microbench=%s)",
        _DV_N, _MH4_K, _MH4_MODE, _MH4_MB)
# --- end MTP draft head NVFP4 search stage ---------------------------------------
