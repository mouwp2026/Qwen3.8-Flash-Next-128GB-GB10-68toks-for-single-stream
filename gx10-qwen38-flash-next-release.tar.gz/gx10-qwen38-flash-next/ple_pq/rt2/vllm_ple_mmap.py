"""vllm_ple_mmap — serve the Qwen3.8-Flash-Next N-gram (PLE) table from NVMe via mmap.

Why: the 51B-parameter n-gram table is 44 GiB in FP8 and vLLM keeps it resident
(GPU, or pinned host RAM with VLLM_PLE_CPU_OFFLOAD). On a DGX Spark / GX10 the
host and the GPU share one 121 GiB pool, so neither fits next to the 78 GiB main
model. But a token only ever touches 16 rows x 160 bytes of that table, so the
table can live on disk and be served through the page cache — exactly what
llama.cpp does with its GGUF mmap.

How: with VLLM_PLE_MMAP=1 this module patches ``Qwen3_8FlashNextNGramEmbedding``:
  * ``__init__`` swaps the 44/95 GiB ``VocabParallelEmbedding`` for a tiny
    placeholder whose ``forward(ids)`` gathers rows from ``np.memmap`` views of the
    checkpoint's ``model-plefp8-*.safetensors`` shards (zero-copy, page-cache backed);
  * ``load_weights`` drops the 128 shard tensors on the floor, keeps the global FP8
    ``weight_scale`` (as ``_offload_weight_scale``, which the untouched
    ``Qwen3_8FlashNextPLELayer._dequantize_embeddings`` already consumes) and opens
    the memmaps.
  * ``forward_impl`` (hashing + lookup) is wrapped in a custom op
    ``vllm::ple_mmap_lookup`` so that (a) torch.compile treats it as opaque — the
    stock version trips an Inductor int64 indexing assert on sm_121 — and (b) it can
    be listed in ``-cc.splitting_ops`` and run OUTSIDE piecewise CUDA graphs: the
    gather is CPU work + a pageable H2D copy, which cannot live inside a capture.
    Use ``-cc.cudagraph_mode=PIECEWISE`` (not FULL*) with the splitting op list in
    serve-flashnext-vllm.sh, or ``--enforce-eager``.
Nothing else in vLLM changes: the n-gram hashing, the short-conv, the dequant path
are the stock ones.

Fast gather hot path (CPU dedup -> persistent pinned staging buffer -> async H2D ->
GPU-side inverse expansion, plus a no-threadpool fast path for decode-sized
batches), bf16/f16 table support, VLLM_PLE_MMAP_DIR and the periodic stats line
were contributed by @Saren-Arterius (github.com/Saren-Arterius/qwen3.8-Flash-DGX-AutoRound).

HashK compressed row source. VLLM_PLE_HASHK=<artifact.pt> swaps
the ~51 GB FP8 shard mmap for a HashK compressed table (12.8 GB, fully page-cache
resident on the 121 GiB UMA box): k=2 splitmix64-hashed sub-tables (A/B, fp8
collision means) + per-head 160x160 bf16 ridge projection W. Row math mirrors
flashnext-one-spark tools/build_hashk_ple.py and the SGLang runtime patch
(patch_hashk.py). gather() returns bf16 bits (row_bytes=320), for which the stock
_dequantize_embeddings is a no-op — the same semantics as the SGLang runtime
(bf16 reconstruction consumed directly, no weight_scale). LOSSY by design
(collision means + linear reconstruction): quality must be gated by NLL /
acceptance-rate checks, NOT by bit-level fingerprints against the full table.

Knobs (env):
  VLLM_PLE_MMAP=1            enable
  VLLM_PLE_MMAP_WORKERS=32   gather threads (page faults overlap across threads)
  VLLM_PLE_MMAP_CHUNK=2048   rows per gather task
  VLLM_PLE_MMAP_PREWARM=0    1 = stream the whole table once at load to fill the
                             page cache with whatever memory is free (harmless,
                             evictable; ~10 s at 4.7 GB/s)

Install: the Dockerfile copies this file next to vllm and appends
``_ple_mmap_apply(Qwen3_8FlashNextNGramEmbedding)`` to the end of
``vllm/models/qwen3_8_flash_next/nvidia/ple_layer.py``. See the repo README.
"""

from __future__ import annotations

import glob
import json
import logging
import math
import os
import re
import struct
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Iterable

import numpy as np
import torch
import torch.nn as nn

logger = logging.getLogger("vllm.ple_mmap")

ENV_ENABLE = "VLLM_PLE_MMAP"
_FP8_DTYPES = {
    "F8_E4M3": torch.float8_e4m3fn,
    "F8_E5M2": torch.float8_e5m2,
}
# 16-bit tables need no weight_scale: the stock _dequantize_embeddings is a
# no-op for non-FP8 rows.
_TABLE_DTYPES = {
    **_FP8_DTYPES,
    "BF16": torch.bfloat16,
    "F16": torch.float16,
}


def enabled() -> bool:
    return os.environ.get(ENV_ENABLE, "0").lower() in ("1", "true", "yes")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


# --------------------------------------------------------------------------- #
# safetensors header parsing (no dependency on the safetensors package: we need
# raw file offsets, which its Python API does not expose)
# --------------------------------------------------------------------------- #
def parse_safetensors_header(path: str) -> tuple[dict, int]:
    """Return (header_dict, data_start_offset) of a safetensors file."""
    with open(path, "rb") as f:
        (header_len,) = struct.unpack("<Q", f.read(8))
        header = json.loads(f.read(header_len))
    header.pop("__metadata__", None)
    return header, 8 + header_len


class MmapPleTable:
    """Row gather over a table split into ``split_ngram_parts`` shard files.

    ``shards``: {shard_index: (path, absolute_byte_offset, rows)}. Shard ``i``
    holds global rows ``[i*shard_size, i*shard_size + rows)`` (vLLM's
    ``copy_ple_embedding_shard_`` layout).
    """

    def __init__(
        self,
        shards: dict[int, tuple[str, int, int]],
        shard_size: int,
        row_bytes: int,
        torch_dtype: torch.dtype,
        workers: int = 32,
        chunk: int = 2048,
    ) -> None:
        if not shards:
            raise ValueError("no PLE shards")
        self.shard_size = int(shard_size)
        self.row_bytes = int(row_bytes)
        self.torch_dtype = torch_dtype
        self.chunk = max(1, int(chunk))
        self.paths: list[str | None] = [None] * (max(shards) + 1)
        self.mm: list[np.memmap | None] = [None] * (max(shards) + 1)
        self.rows_total = 0
        for idx, (path, offset, rows) in shards.items():
            self.paths[idx] = path
            self.mm[idx] = np.memmap(
                path, dtype=np.uint8, mode="r", offset=offset, shape=(rows, row_bytes)
            )
            self.rows_total += rows
        self.pool = ThreadPoolExecutor(max_workers=max(1, int(workers)))
        self.fast_rows = _env_int("VLLM_PLE_MMAP_FAST_ROWS", 512)

    def gather(self, ids: np.ndarray) -> np.ndarray:
        """ids: int64 [N] global row ids -> uint8 [N, row_bytes] (a fresh array)."""
        import time as _time

        t0 = _time.perf_counter()
        try:
            return self._gather(ids)
        finally:
            _STATS["gather_ms"] += (_time.perf_counter() - t0) * 1e3
            _STATS["rows"] += int(np.asarray(ids).size)
            _STATS["bytes"] += int(np.asarray(ids).size) * self.row_bytes

    def _gather(self, ids: np.ndarray) -> np.ndarray:
        ids = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        if ids.size == 0:
            return np.empty((0, self.row_bytes), dtype=np.uint8)
        return self._gather_disk(ids)

    def _gather_disk(self, ids: np.ndarray) -> np.ndarray:
        ids = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        if ids.size == 0:
            return np.empty((0, self.row_bytes), dtype=np.uint8)
        if ids.size <= self.fast_rows:
            # Decode-sized batches: thread-pool dispatch costs more than the
            # reads themselves (~50 tasks for ~65 rows). Gather inline instead.
            if ids.min() < 0 or ids.max() >= self.shard_size * len(self.mm):
                raise IndexError(
                    f"PLE row id out of range: [{ids.min()}, {ids.max()}] "
                    f"for {self.rows_total} rows"
                )
            shard = ids // self.shard_size
            local = ids - shard * self.shard_size
            out = np.empty((ids.size, self.row_bytes), dtype=np.uint8)
            for si in np.unique(shard):
                mask = shard == si
                out[mask] = self.mm[si][local[mask]]
            return out
        # Dedupe + sort: repeated n-grams are common, and sorted rows improve
        # locality inside a shard.
        uniq, inverse = np.unique(ids, return_inverse=True)
        if uniq[0] < 0 or uniq[-1] >= self.shard_size * len(self.mm):
            raise IndexError(
                f"PLE row id out of range: [{uniq[0]}, {uniq[-1]}] "
                f"for {self.rows_total} rows"
            )
        shard = uniq // self.shard_size
        local = uniq - shard * self.shard_size
        out = np.empty((uniq.size, self.row_bytes), dtype=np.uint8)

        bounds = np.flatnonzero(np.diff(shard)) + 1
        starts = np.concatenate(([0], bounds))
        ends = np.concatenate((bounds, [uniq.size]))
        tasks: list[tuple[int, int, int]] = []
        for s, e in zip(starts.tolist(), ends.tolist()):
            si = int(shard[s])
            for c in range(s, e, self.chunk):
                tasks.append((si, c, min(c + self.chunk, e)))

        def run(task: tuple[int, int, int]) -> None:
            si, a, b = task
            mm = self.mm[si]
            if mm is None:
                raise IndexError(f"PLE shard {si} missing")
            # Fancy indexing on a memmap: page faults do the I/O; NumPy releases
            # the GIL for the copy, so tasks overlap across threads.
            out[a:b] = mm[local[a:b]]

        if len(tasks) == 1:
            run(tasks[0])
        else:
            for _ in self.pool.map(run, tasks):
                pass
        return out[inverse]

    def prewarm(self) -> None:
        """Stream every shard once so the page cache holds as much as it can."""
        block = 64 << 20
        for path, mm in zip(self.paths, self.mm):
            if path is None or mm is None:
                continue
            start = mm.offset
            end = start + mm.shape[0] * mm.shape[1]
            with open(path, "rb", buffering=0) as f:
                pos = start
                while pos < end:
                    n = f.readinto(bytearray(min(block, end - pos)))  # noqa: F841
                    if not n:
                        break
                    pos += n


# --------------------------------------------------------------------------- #
# HashK compressed table (k=2 hashed sub-tables + per-head ridge projection)
# --------------------------------------------------------------------------- #
ENV_HASHK = "VLLM_PLE_HASHK"


def _hashk_path() -> str:
    return os.environ.get(ENV_HASHK, "")


class HashKPleTable:
    """Row gather over a HashK compressed PLE artifact (12.8 GB, page-cache
    backed through torch.load(mmap=True)) instead of the ~51 GB FP8 shards.

    Same duck-type as MmapPleTable: ``gather(ids) -> uint8 [N, row_bytes]``,
    ``row_bytes``, ``torch_dtype``, ``prewarm()``. Rows are bf16 bits
    (row_bytes = 320), so the stock PLELayer dequant is a no-op — identical
    consumption semantics to the SGLang HashK runtime (bf16 reconstruction,
    no weight_scale).
    """

    # splitmix64 constants as unsigned 64-bit (two's-complement of the signed
    # values used by the builder, so the wrapping arithmetic is bit-identical).
    _GAMMA = 0x9E3779B97F4A7C15
    _M1 = 0xBF58476D1CE4E5B9
    _M2 = 0x94D049BB133111EB

    def __init__(self, artifact_path: str) -> None:
        art = torch.load(
            artifact_path, map_location="cpu", mmap=True, weights_only=True
        )
        self.artifact_path = artifact_path
        # The SGLang runtime multiplies the reconstruction by the checkpoint's
        # per-layer weight_scale (qwen4_exp_nvfp4.py: embeddings *= weight_scale).
        # vLLM's stock dequant is a no-op for bf16 rows, so the scale MUST be
        # folded in before any row is consumed. 1.0 is only the pre-fold
        # placeholder; gather() refuses to run until fold_weight_scale().
        self.weight_scale = 1.0
        self.scale_folded = False
        # GPU gatherer (VLLM_PLE_GPU=1): built lazily on first forward, after
        # the CUDA context is guaranteed live and weight_scale is folded.
        self.gpu_gatherer = None
        self._gpu_attempted = False
        self._gpu_retry_at = 0.0        # throttle transient register failures
        # Format dispatch. PQ artifacts carry "codebooks"/"codes"; HashK carries
        # "A"/"B"/"W". Same CLASS on purpose: load_weights() does a hardcoded
        # `isinstance(tab, HashKPleTable)` to trigger the late weight_scale fold,
        # so a subclasses-free branch keeps that path working untouched.
        if "codebooks" in art:
            self._init_pq(art)
            return
        self.format = "hashk"
        self.A = art["A"]  # fp8_e4m3 [csize, half] — mmap-backed storage
        self.B = art["B"]  # fp8_e4m3 [csize, half]
        self.W = art["W"].to(torch.float32).contiguous()  # [16, 160, 160] f32
        self.heads = int(art["heads"])
        self.dim = int(art["dim"])
        self.half = int(art["half"])
        sizes = [int(v) for v in art["sizes"]]
        offs = [int(v) for v in art["offs"]]
        self.sizes = np.asarray(sizes, dtype=np.int64)
        self.offs = np.asarray(offs + [offs[-1] + sizes[-1]], dtype=np.int64)
        self.sub_sizes = np.asarray([int(v) for v in art["sub_sizes"]], dtype=np.int64)
        self.sub_offs = np.asarray([int(v) for v in art["sub_offs"]], dtype=np.int64)
        self.total = int(self.offs[-1])
        self.salts = tuple(int(s) for s in art["salts"])
        self.hsalt = int(art["hsalt"])
        self.mulc = int(art["mulc"])
        self.bytes_total = int(self.A.numel()) + int(self.B.numel())
        # Duck-type surface consumed by _MmapNgramEmbedding.forward:
        self.row_bytes = self.dim * 2  # bf16 bits
        self.torch_dtype = torch.bfloat16
        self.rows_total = self.total
        logger.info(
            "PLE HashK: R=%s, %d heads, sub-rows %d x2 fp8 (%.1f GiB mmap) + "
            "W %dx%dx%d, row=%d B bf16 bits, total vocab %d",
            art.get("R"), self.heads, int(self.sub_sizes[0]),
            (self.A.numel() + self.B.numel()) / 2**30,
            self.heads, self.dim, self.dim, self.row_bytes, self.total,
        )

    def _slot(self, local: np.ndarray, h: np.ndarray, sub: int) -> np.ndarray:
        """splitmix64 hash slot — bit-identical to the builder/SGLang math."""
        u64 = np.uint64
        x = (local.astype(np.uint64) + u64(1)) * u64(self.mulc)
        x = x + (
            u64(self.salts[sub] & 0xFFFFFFFFFFFFFFFF) + u64(self.hsalt) * h.astype(np.uint64)
        )
        x = x + u64(self._GAMMA)
        x = (x ^ (x >> u64(30))) * u64(self._M1)
        x = (x ^ (x >> u64(27))) * u64(self._M2)
        x = x ^ (x >> u64(31))
        signed = x.view(np.int64) if x.base is None else np.ascontiguousarray(x).view(np.int64)
        # np.mod follows the divisor's sign (positive), like torch.remainder.
        return np.mod(signed, self.sub_sizes[h])

    def fold_weight_scale(self, ws: float) -> None:
        self.weight_scale = float(ws)
        self.scale_folded = True
        logger.info("PLE HashK: weight_scale folded in (%.6g)", self.weight_scale)

    # ------------------------------------------------------------- PQ path --
    def _init_pq(self, art) -> None:
        """PQ artifact: per-head codebooks + M byte-indices per table row.

        Layout is flat and collision-free (every source row survives), so unlike
        HashK there is no mean-pooling and no ridge projection -- decoding is a
        pure codebook lookup.
        """
        self.format = "pq"
        cb = art["codebooks"].to(torch.float32).contiguous()
        self.codes = art["codes"]            # uint8 [total_rows, M], mmap-backed
        self.codebooks = cb                  # f32 [HEADS, M, K, SEG]
        if cb.dim() != 4:
            raise RuntimeError(f"PLE PQ: codebooks must be 4-D, got {tuple(cb.shape)}")
        self.heads = int(cb.shape[0])
        self.M = int(cb.shape[1])
        self.K = int(cb.shape[2])
        self.seg = int(cb.shape[3])
        self.dim = self.M * self.seg
        sizes = [int(v) for v in art["sizes"]]
        offs = [int(v) for v in art["offs"]]
        self.sizes = np.asarray(sizes, dtype=np.int64)
        self.offs = np.asarray(offs + [offs[-1] + sizes[-1]], dtype=np.int64)
        self.total = int(self.offs[-1])
        if int(self.codes.shape[1]) != self.M:
            raise RuntimeError(
                f"PLE PQ: codes width {int(self.codes.shape[1])} != M {self.M}"
            )
        if int(self.codes.shape[0]) != self.total:
            raise RuntimeError(
                f"PLE PQ: codes has {int(self.codes.shape[0])} rows but the "
                f"head offsets imply {self.total}"
            )
        self._cb_flat = cb.view(-1, self.seg)   # [HEADS*M*K, SEG] view, no copy
        self.row_bytes = self.dim * 2           # bf16 bits
        self.torch_dtype = torch.bfloat16
        self.rows_total = self.total
        self.bytes_total = int(self.codes.numel()) + cb.numel() * 4
        logger.info(
            "PLE PQ: M=%d K=%d seg_dim=%d, %d heads, codes %.2f GiB mmap + "
            "codebooks %dx%dx%dx%d (%.2f MB), row=%d B bf16 bits, total vocab %d",
            self.M, self.K, self.seg, self.heads, self.codes.numel() / 2**30,
            self.heads, self.M, self.K, self.seg, cb.numel() * 4 / 2**20,
            self.row_bytes, self.total,
        )

    def _gather_pq(self, ids: np.ndarray) -> np.ndarray:
        """Reference CPU decode -- also the numeric oracle for the GPU kernel."""
        ids = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        if ids.size == 0:
            return np.empty((0, self.row_bytes), dtype=np.uint8)
        if int(ids.min()) < 0 or int(ids.max()) >= self.total:
            raise IndexError(
                f"PLE PQ row id out of range: [{ids.min()}, {ids.max()}] "
                f"for {self.total} rows"
            )
        h = np.searchsorted(self.offs, ids, side="right") - 1
        code = self.codes[torch.from_numpy(ids)]      # [n, M] uint8
        h_t = torch.from_numpy(np.ascontiguousarray(h, dtype=np.int64))
        out = torch.empty((ids.size, self.dim), dtype=torch.float32)
        for m in range(self.M):
            c = code[:, m].to(torch.int64)
            idx = (h_t * self.M + m) * self.K + c
            out[:, m * self.seg:(m + 1) * self.seg] = self._cb_flat[idx]
        recon = out * self.weight_scale
        bits = recon.to(torch.bfloat16).contiguous().view(torch.uint8).numpy()
        return np.ascontiguousarray(bits.reshape(ids.size, self.row_bytes))

    def _prewarm_pq(self) -> None:
        n = int(self.codes.shape[0])
        step = 1 << 20
        acc = 0
        for i in range(0, n, step):
            acc += int(self.codes[i:i + step].sum())
        logger.info(
            "PLE PQ: prewarmed codes (%d rows, %.2f GiB, chk %d)",
            n, self.codes.numel() / 2**30, acc,
        )

    def _ensure_gpu_gatherer(self) -> None:
        """Lazily build the UVA GPU gatherer (env VLLM_PLE_GPU, default ON).

        Registration is owned here so any partial failure (A pinned, B rc!=0,
        self-check mismatch) rolls back cleanly and the CPU path stays in
        charge. Transient register failures retry at most every 30 s; the
        the engine never blocks on this.
        """
        if self.format == "pq":
            self._ensure_gpu_gatherer_pq()
            return
        if self._gpu_attempted:
            return
        import time as _t
        now = _t.monotonic()
        if now < self._gpu_retry_at:
            return
        if _env_int("VLLM_PLE_GPU", 1) == 0:  # VLLM_PLE_GPU=0 disables
            self._gpu_attempted = True
            return
        if not self.scale_folded:
            self._gpu_retry_at = now + 1.0   # scale may fold a moment later
            return
        import ctypes
        libc = ctypes.CDLL("libcudart.so")
        _lib = None
        try:
            import torch as _torch
            if not _torch.cuda.is_available():
                logger.warning("PLE HashK: GPU gatherer skipped (no CUDA)")
                self._gpu_attempted = True
                return
            Ab = self.A.view(torch.uint8)
            Bb = self.B.view(torch.uint8)
            for t in (Ab, Bb):
                rc = libc.cudaHostRegister(
                    ctypes.c_void_p(t.data_ptr()),
                    ctypes.c_size_t(t.numel() * t.element_size()),
                    ctypes.c_uint(0),
                )
                if rc != 0:
                    raise RuntimeError(f"cudaHostRegister rc={rc}")
            _lib = libc  # both pinned; remember to release on any later fail

            from hashk_gpu import GpuHashKGatherer

            g = GpuHashKGatherer(
                self.A, self.B, self.W,
                [int(v) for v in self.sizes],
                [int(v) for v in self.offs],       # [HEADS+1] sentinel form
                [int(v) for v in self.sub_offs], [int(v) for v in self.sub_sizes],
                self.salts, self.hsalt, self.mulc, self.weight_scale,
                heads=self.heads, dim=self.dim,
                half=getattr(self, "half", self.dim // 2), device="cuda",
                route="host", register=False,
            )
            # One-shot parity self-check: handful of ids vs the CPU gather.
            rng = np.random.default_rng(0)
            ids = rng.integers(0, self.total, size=2048, dtype=np.int64)
            ref = self._gather(ids)
            ref_b = torch.from_numpy(ref).view(self.torch_dtype).cuda()
            got = g.gather(torch.from_numpy(ids).cuda())
            neq = (ref_b.view(torch.uint16) != got.view(torch.uint16))
            ulp = (ref_b.view(torch.uint16).to(torch.int32)
                   - got.view(torch.uint16).to(torch.int32)).abs().max().item()
            nbits = int(neq.sum())
            ok = nbits == 0 or (ulp <= 4 and nbits * 1000 < ref_b.numel())
            if not ok:
                raise RuntimeError(
                    f"self-check FAILED ({nbits} bits, ulp={ulp})")
            self.gpu_gatherer = g
            self._gpu_libc = _lib
            self._gpu_attempted = True   # never re-register the same pages
            logger.info(
                "PLE HashK: GPU gatherer ACTIVE (UVA host route, self-check "
                "0 bits / ulp<=%d)", ulp)
        except Exception as exc:  # noqa: BLE001 - degrade, never raise
            logger.warning("PLE HashK: GPU gatherer disabled: %r", exc)
            self._gpu_attempted = True
            if _lib is not None:
                try:
                    for t in (self.A.view(torch.uint8),
                              self.B.view(torch.uint8)):
                        _lib.cudaHostUnregister(ctypes.c_void_p(t.data_ptr()))
                except Exception:  # noqa: BLE001
                    pass
            # rc!=0 (transient VRAM pressure): allow a 30 s retry window.
            if isinstance(exc, RuntimeError) and str(exc).startswith(
                    "cudaHostRegister rc="):
                self._gpu_attempted = False
                self._gpu_retry_at = now + 30.0

    def _ensure_gpu_gatherer_pq(self) -> None:
        """Build the PQ GPU gatherer (VLLM_PLE_GPU, default ON).

        Same contract as the HashK route: the code table stays host-resident and
        is exposed to the Triton kernel through cudaHostRegister UVA, so the hot
        decode path performs no D2H/H2D at all -- which is what makes it legal
        inside a captured CUDA graph (FULL_DECODE_ONLY). Any failure degrades to
        the CPU path, which is only legal OUTSIDE a graph; forward() raises a
        pointed error in that case rather than letting torch raise an opaque
        copy error.
        """
        if self._gpu_attempted:
            return
        import time as _t
        now = _t.monotonic()
        if now < self._gpu_retry_at:
            return
        if _env_int("VLLM_PLE_GPU", 1) == 0:   # VLLM_PLE_GPU=0 disables
            self._gpu_attempted = True
            return
        if not self.scale_folded:
            self._gpu_retry_at = now + 1.0     # scale may fold a moment later
            return
        import ctypes
        libc = ctypes.CDLL("libcudart.so")
        _lib = None
        try:
            if not torch.cuda.is_available():
                logger.warning("PLE PQ: GPU gatherer skipped (no CUDA)")
                self._gpu_attempted = True
                return
            codeb = self.codes.view(torch.uint8)
            # N1: route is configurable now that PQ shrank the table to ~1.5 GiB.
            # "host" = cudaHostRegister UVA (the 44 GiB-era default),
            # "device" = keep the codes in VRAM (paid for out of the KV pool).
            _route = os.environ.get("VLLM_PLE_PQ_ROUTE", "host").strip().lower()
            if _route == "device":
                _bytes = codeb.numel() * codeb.element_size()
                try:
                    _probe = torch.empty(_bytes, dtype=torch.uint8, device="cuda")
                    del _probe
                    logger.info(
                        "PLE PQ: route=device -- %.2f GiB codes -> VRAM "
                        "(taken from the KV pool)", _bytes / float(1 << 30))
                except Exception as _exc:  # noqa: BLE001
                    logger.warning(
                        "PLE PQ: route=device unavailable (%r); host route kept",
                        _exc)
                    _route = "host"
            if _route != "device":
                rc = libc.cudaHostRegister(
                    ctypes.c_void_p(codeb.data_ptr()),
                    ctypes.c_size_t(codeb.numel() * codeb.element_size()),
                    ctypes.c_uint(0),
                )
                if rc != 0:
                    raise RuntimeError(f"cudaHostRegister rc={rc}")
                _lib = libc  # pinned; remember to release on any later failure
            g = GpuPqGatherer(
                codeb, self.codebooks,
                [int(v) for v in self.offs], self.weight_scale,
                heads=self.heads, M=self.M, K=self.K, seg=self.seg,
                device="cuda", register=False, route=_route,
            )
            # One-shot parity self-check against the CPU oracle. Pure lookup +
            # one multiply on both sides, so this must be bit-identical.
            rng = np.random.default_rng(0)
            ids = rng.integers(0, self.total, size=2048, dtype=np.int64)
            ref = self._gather_pq(ids)
            ref_b = torch.from_numpy(ref).view(self.torch_dtype).cuda()
            got = g.gather(torch.from_numpy(ids).cuda())
            neq = (ref_b.view(torch.uint16) != got.view(torch.uint16))
            nbits = int(neq.sum())
            ulp = int((ref_b.view(torch.uint16).to(torch.int32)
                       - got.view(torch.uint16).to(torch.int32)).abs().max())
            if nbits != 0:
                raise RuntimeError(f"self-check FAILED ({nbits} bits, ulp={ulp})")
            self.gpu_gatherer = g
            self._gpu_libc = _lib
            self._gpu_attempted = True   # never re-register the same pages
            logger.info(
                "PLE PQ: GPU gatherer ACTIVE (%s route, %d/%d rows "
                "bit-identical to the CPU oracle)",
                _route, int(ids.size) - nbits, int(ids.size),
            )
        except Exception as exc:  # noqa: BLE001 - degrade, never raise
            logger.warning("PLE PQ: GPU gatherer disabled: %r", exc)
            self._gpu_attempted = True
            if _lib is not None:
                try:
                    _lib.cudaHostUnregister(ctypes.c_void_p(
                        self.codes.view(torch.uint8).data_ptr()))
                except Exception:  # noqa: BLE001
                    pass
            # rc!=0 (transient VRAM pressure): allow a 30 s retry window.
            if isinstance(exc, RuntimeError) and str(exc).startswith(
                    "cudaHostRegister rc="):
                self._gpu_attempted = False
                self._gpu_retry_at = now + 30.0

    def gather(self, ids: np.ndarray) -> np.ndarray:
        import time as _time

        if not self.scale_folded:
            # The reconstruction is in raw fp8-value space; without the
            # checkpoint weight_scale folded in, every row is ~1/ws (thousands
            # of) times too large -> silent model corruption (observed as an
            # acceptance rate collapse to ~0.002). Fail loudly instead.
            raise RuntimeError(
                "PLE HashK: gather() before weight_scale fold -- engine would "
                "consume unscaled rows (silent corruption). Load-order bug."
            )
        t0 = _time.perf_counter()
        try:
            return self._gather(ids)
        finally:
            _STATS["gather_ms"] += (_time.perf_counter() - t0) * 1e3
            _STATS["rows"] += int(np.asarray(ids).size)
            _STATS["bytes"] += int(np.asarray(ids).size) * self.row_bytes

    def _gather(self, ids: np.ndarray) -> np.ndarray:
        if self.format == "pq":
            return self._gather_pq(ids)
        ids = np.ascontiguousarray(ids, dtype=np.int64).reshape(-1)
        if ids.size == 0:
            return np.empty((0, self.row_bytes), dtype=np.uint8)
        if int(ids.min()) < 0 or int(ids.max()) >= self.total:
            raise IndexError(
                f"PLE HashK row id out of range: [{ids.min()}, {ids.max()}] "
                f"for {self.total} rows"
            )
        h = np.searchsorted(self.offs, ids, side="right") - 1  # head per row
        local = ids - self.offs[h]
        sA = self.sub_offs[h] + self._slot(local, h, 0)
        sB = self.sub_offs[h] + self._slot(local, h, 1)
        # Fancy-index the mmap-backed fp8 storages (page-cache reads), then
        # dequant to f32 and run the per-head ridge projection.
        hat = torch.cat(
            [self.A[torch.from_numpy(sA)], self.B[torch.from_numpy(sB)]], dim=1
        ).to(torch.float32)  # [U, 160]
        recon = torch.empty((ids.size, self.dim), dtype=torch.float32)
        order = np.argsort(h, kind="stable")
        bounds = np.searchsorted(h[order], np.arange(self.heads + 1))
        for hh in range(self.heads):
            a, b = int(bounds[hh]), int(bounds[hh + 1])
            if a == b:
                continue
            sel = torch.from_numpy(order[a:b])
            recon[sel] = hat[sel] @ self.W[hh]
        recon = recon * self.weight_scale
        # bf16 bits as the uint8 row carrier: [U, 160] bf16 -> [U, 320] uint8.
        out = recon.to(torch.bfloat16).contiguous().view(torch.uint8).numpy()
        return np.ascontiguousarray(out.reshape(ids.size, self.row_bytes))

    def prewarm(self) -> None:
        """Touch every page once so the page cache holds the whole table."""
        if self.format == "pq":
            return self._prewarm_pq()
        for t, name in ((self.A, "A"), (self.B, "B")):
            n = int(t.shape[0])
            step = 1 << 19
            acc = 0.0
            for i in range(0, n, step):
                acc += float(t[i : i + step].to(torch.float32).sum())
            logger.info("PLE HashK: prewarmed sub-table %s (%d rows, chk %.1f)", name, n, acc)


# --------------------------------------------------------------------------- #
# PQ GPU gather (Triton, UVA host route) -- keeps decode cudagraph-safe
# --------------------------------------------------------------------------- #
# Mirrors hashk_gpu.py: the table stays host-resident, is mapped into the device
# address space with cudaHostRegister, and a single vectorized kernel does the
# whole decode (head lookup -> M byte reads -> codebook gather). No .cpu(), no
# .item(), no dynamic Python shape work -> capturable inside a CUDA graph.
try:  # pragma: no cover - CPU-only environments have no triton
    import triton
    import triton.language as tl

    _HAS_TRITON = True
except Exception:  # noqa: BLE001
    triton = None
    tl = None
    _HAS_TRITON = False


if _HAS_TRITON:

    @triton.jit
    def _pq_gather_kernel(
        ids_ptr,          # int32 [n]
        out_ptr,          # f32   [cap, DIM]
        codes_ptr,        # uint8 flat [total_rows * M]  (UVA host mapping)
        cb_ptr,           # f32   flat [HEADS*M*K * SEG]
        offs_ptr,         # int64 [HEADS+1]  head boundaries (+ sentinel)
        n,                # int32 runtime length
        HEADS: tl.constexpr,
        M: tl.constexpr,
        K: tl.constexpr,
        SEG: tl.constexpr,
        DIM: tl.constexpr,
        BLOCK: tl.constexpr,
    ):
        pid = tl.program_id(0)
        t = pid * BLOCK + tl.arange(0, BLOCK)
        tmask = t < n
        id_ = tl.load(ids_ptr + t, mask=tmask, other=0).to(tl.int64)

        # head = #{i in 1..HEADS-1 : id >= offs[i]}  (== searchsorted right - 1)
        h = tl.zeros([BLOCK], dtype=tl.int32)
        for i in tl.static_range(1, HEADS):
            bound = tl.load(offs_ptr + i)
            h += tl.where(id_ >= bound, 1, 0).to(tl.int32)

        # NOTE: the code table is ONE flat [total_rows, M] array addressed by
        # GLOBAL row id -- only the codebooks are per-head. (HashK needs a
        # per-head LOCAL index because its A/B sub-tables really are stored per
        # head; using a local index here silently mis-decodes every row whose
        # head is not 0 -- caught offline by the bit-exact parity check.)
        base = id_ * M
        h64 = h.to(tl.int64)
        s = tl.arange(0, SEG)
        for m in tl.static_range(M):
            c = tl.load(codes_ptr + base + m, mask=tmask, other=0).to(tl.int64)
            cb_row = ((h64 * M + m) * K + c)[:, None]
            v = tl.load(cb_ptr + cb_row * SEG + s[None, :],
                        mask=tmask[:, None], other=0.0)
            tl.store(out_ptr + t[:, None] * DIM + (m * SEG + s)[None, :], v,
                     mask=tmask[:, None])


class _UvaPtr:
    """Host tensor exposed to device kernels via UVA after cudaHostRegister.

    Triton takes anything with .data_ptr(); zero-copy, no device allocation.
    """

    __slots__ = ("t", "p")
    dtype = torch.uint8  # Triton binder reads .dtype for pointer args

    def __init__(self, t):
        self.t = t
        self.p = t.data_ptr()

    def data_ptr(self):
        return self.p


def _register_uva(t):
    """cudaHostRegister one tensor's storage. Returns the libc handle.

    GB10 note: registration maps host pages into the device address space; the
    mapping costs page-table VRAM (~1/16 of the region, measured on HashK).
    Unregistered host pointers are rejected by Triton at launch.
    """
    import ctypes
    libc = ctypes.CDLL("libcudart.so")
    rc = libc.cudaHostRegister(
        ctypes.c_void_p(t.data_ptr()),
        ctypes.c_size_t(t.numel() * t.element_size()),
        ctypes.c_uint(0),
    )
    if rc != 0:
        raise RuntimeError(f"cudaHostRegister rc={rc}")
    return libc


class GpuPqGatherer:
    """Static-shape GPU gather over a PQ artifact (codebook lookup only).

    route="host" (default, GX10 reality): the code table stays host-resident and
    is reached through cudaHostRegister UVA. route="device": copy it to VRAM
    (1.5 GiB at M=5, affordable thanks to the 10 GiB the PQ table saves, but it
    comes straight out of the KV pool).
    """

    def __init__(self, codes_u8, codebooks, offs, weight_scale,
                 heads=16, M=5, K=256, seg=32, device="cuda", route="host",
                 register=True):
        if not _HAS_TRITON:
            raise RuntimeError("triton unavailable")
        self.device = device
        self.heads = int(heads)
        self.M = int(M)
        self.K = int(K)
        self.seg = int(seg)
        self.dim = self.M * self.seg
        self.weight_scale = float(weight_scale)
        if route == "device":
            self.codes = codes_u8.to(device).contiguous()
        else:
            if register:
                self._libc = _register_uva(codes_u8)
            self.codes = _UvaPtr(codes_u8)
        self.cb = codebooks.to(torch.float32).to(device).contiguous().view(
            -1, self.seg)
        self.offs = torch.tensor([int(v) for v in offs], dtype=torch.int64,
                                 device=device)
        self._cap = 0
        self._out = None

    def _buffers(self, n):
        if self._out is None or self._cap < n:
            self._cap = max(n, 8192)
            self._out = torch.empty((self._cap, self.dim),
                                    dtype=torch.float32, device=self.device)

    def gather(self, ids: torch.Tensor) -> torch.Tensor:
        """ids: int32/int64 [N] cuda. Returns bf16 [N, dim]."""
        ids32 = ids.to(torch.int32).contiguous()
        n = int(ids32.numel())
        if n == 0:
            return torch.empty((0, self.dim), dtype=torch.bfloat16,
                               device=self.device)
        self._buffers(n)
        BLOCK = 64
        _pq_gather_kernel[(triton.cdiv(n, BLOCK),)](
            ids32, self._out, self.codes, self.cb, self.offs, n,
            HEADS=self.heads, M=self.M, K=self.K, SEG=self.seg,
            DIM=self.dim, BLOCK=BLOCK,
        )
        return (self._out[:n] * self.weight_scale).to(torch.bfloat16)


class _MmapNgramEmbedding(nn.Module):
    """Duck-types the bits of VocabParallelEmbedding the PLE code reads.

    No ``weight`` attribute on purpose: ``Qwen3_8FlashNextPLELayer`` then falls
    back to ``ple_embedding._offload_weight_scale`` for the FP8 scale.
    """

    def __init__(self, num_embeddings: int, embedding_dim: int) -> None:
        super().__init__()
        self.num_embeddings = int(num_embeddings)
        self.org_vocab_size = int(num_embeddings)
        self.embedding_dim = int(embedding_dim)
        self.table: MmapPleTable | None = None
        self._zeros_dtype = torch.bfloat16

    def _pinned_buf(self, rows: int, row_bytes: int) -> torch.Tensor | None:
        """Persistent pinned staging buffer for async H2D (grown as needed)."""
        buf = getattr(self, "_pinned", None)
        if buf is None or buf.shape[0] < rows or buf.shape[1] != row_bytes:
            try:
                cap = max(rows + rows // 2, 4096)
                buf = torch.empty((cap, row_bytes), dtype=torch.uint8, pin_memory=True)
            except RuntimeError:  # no CUDA (CPU tests) or pinning unavailable
                buf = None
            self._pinned = buf
        return buf

    def forward(self, ids: torch.Tensor) -> torch.Tensor:
        table = self.table
        if table is None:
            # Weights never loaded (e.g. --load-format dummy): keep the plumbing
            # alive with zeros so kernel tests can run without the 44 GiB table.
            return torch.zeros(
                (*ids.shape, self.embedding_dim),
                dtype=self._zeros_dtype,
                device=ids.device,
            )
        # --- GPU-HashK route (VLLM_PLE_GPU=1): no D2H, no numpy, no H2D. ---
        gg = getattr(table, "gpu_gatherer", None)
        if gg is None and hasattr(table, "_ensure_gpu_gatherer"):
            table._ensure_gpu_gatherer()  # once; degrades silently to CPU
            gg = getattr(table, "gpu_gatherer", None)
        if gg is not None and ids.device.type == "cuda":
            ids_c = ids.detach().contiguous().view(-1)
            out = gg.gather(ids_c)  # bf16 [U, dim]
            return out.reshape(*ids.shape, self.embedding_dim)
        if ids.device.type == "cuda" and torch.cuda.is_current_stream_capturing():
            # Nothing on this path may sync with the host inside a captured
            # graph. Reaching here means the GPU gatherer was unavailable
            # (VLLM_PLE_GPU=0, or cudaHostRegister failed), so fail with the fix
            # instead of letting torch raise an opaque copy error later.
            raise RuntimeError(
                "PLE: CPU gather reached inside CUDA graph capture (no GPU "
                "gatherer available). Set VLLM_PLE_GPU=1 and check the "
                "registration warning above; alternatively run with "
                "-cc.cudagraph_mode=PIECEWISE and the lookup listed in "
                "-cc.splitting_ops so the op executes outside the graphs."
            )
        ids_np = ids.detach().to("cpu", non_blocking=False).numpy().reshape(-1)
        # Dedup on CPU, gather only unique rows, expand on the GPU: fewer disk
        # reads AND fewer H2D bytes (repeated n-grams are the common case).
        uniq, inverse = np.unique(ids_np, return_inverse=True)
        rows = table.gather(uniq)  # uint8 [U, row_bytes], fresh & writable
        u = rows.shape[0]
        buf = self._pinned_buf(u, table.row_bytes) if ids.device.type == "cuda" else None
        if buf is not None:
            buf[:u].numpy()[:] = rows
            dev = buf[:u].to(ids.device, non_blocking=True)
        else:
            dev = torch.from_numpy(rows).to(ids.device)
        inv = torch.from_numpy(inverse.reshape(-1)).to(ids.device, non_blocking=True)
        out = dev.view(table.torch_dtype)[inv]
        return out.reshape(*ids.shape, self.embedding_dim)


# --------------------------------------------------------------------------- #
# Patch
# --------------------------------------------------------------------------- #
def _find_shards(
    model_path: str, layer_idx: int
) -> tuple[dict[int, tuple[str, int, int]], str | None, tuple[str, int, int] | None]:
    """Locate ``layers.<idx>.ple.ple_embedding.ngram_embedding.shard_N.weight``.

    Returns (shards, dtype_str, scale_entry) where scale_entry is
    (path, abs_offset, nbytes) of ``ngram_embedding.weight_scale`` or None.
    """
    shard_re = re.compile(
        rf"layers\.{layer_idx}\.ple\.ple_embedding\.ngram_embedding\.shard_(\d+)\.weight$"
    )
    scale_re = re.compile(
        rf"layers\.{layer_idx}\.ple\.ple_embedding\.ngram_embedding\.weight_scale$"
    )
    index_path = os.path.join(model_path, "model.safetensors.index.json")
    if os.path.exists(index_path):
        with open(index_path) as f:
            weight_map = json.load(f)["weight_map"]
        files = sorted(
            {
                os.path.join(model_path, fn)
                for name, fn in weight_map.items()
                if shard_re.search(name) or scale_re.search(name)
            }
        )
    else:
        files = sorted(glob.glob(os.path.join(model_path, "*.safetensors")))

    shards: dict[int, tuple[str, int, int]] = {}
    dtype_str: str | None = None
    scale_entry: tuple[str, int, int] | None = None
    for path in files:
        header, data_start = parse_safetensors_header(path)
        for name, meta in header.items():
            m = shard_re.search(name)
            if m:
                start, end = meta["data_offsets"]
                rows, cols = meta["shape"]
                if dtype_str is None:
                    dtype_str = meta["dtype"]
                elif meta["dtype"] != dtype_str:
                    raise ValueError("PLE shards have mixed dtypes")
                if end - start != rows * cols * _itemsize(dtype_str):
                    raise ValueError(f"PLE shard {name}: size/shape mismatch")
                shards[int(m.group(1))] = (path, data_start + start, rows)
                shard_cols = cols
            elif scale_re.search(name):
                start, end = meta["data_offsets"]
                scale_entry = (path, data_start + start, end - start, meta["dtype"])  # type: ignore[assignment]
    if shards:
        # Return cols through dtype_str consumer; keep it simple: stash on dict.
        shards["__cols__"] = shard_cols  # type: ignore[index]
    return shards, dtype_str, scale_entry


def _itemsize(dtype_str: str) -> int:
    return {
        "F8_E4M3": 1,
        "F8_E5M2": 1,
        "U8": 1,
        "I8": 1,
        "BF16": 2,
        "F16": 2,
        "F32": 4,
    }[dtype_str]


def _read_scale(entry: tuple) -> torch.Tensor:
    path, offset, nbytes, dtype_str = entry
    with open(path, "rb") as f:
        f.seek(offset)
        raw = f.read(nbytes)
    if dtype_str == "F32":
        return torch.tensor(struct.unpack("<f", raw[:4])[0], dtype=torch.float32)
    if dtype_str == "BF16":
        u16 = struct.unpack("<H", raw[:2])[0]
        return torch.tensor(u16 << 16, dtype=torch.int32).view(torch.float32).squeeze()
    if dtype_str == "F16":
        return torch.frombuffer(bytearray(raw[:2]), dtype=torch.float16).clone().squeeze()
    raise ValueError(f"unsupported weight_scale dtype {dtype_str}")


_REGISTRY: dict[str, nn.Module] = {}
_OP_NAME = "ple_mmap_lookup"

# Aggregate gather-overhead stats, logged every VLLM_PLE_MMAP_STATS_SEC seconds
# (0 = off). op_ms covers hashing + gather + H2D; gather_ms just the disk reads.
_STATS = {
    "calls": 0, "op_ms": 0.0, "gather_ms": 0.0, "rows": 0, "bytes": 0,
}
_STATS_LAST = [0.0]
_STATS_SEC = _env_int("VLLM_PLE_MMAP_STATS_SEC", 30)


def _stats_log() -> None:
    import time as _time

    now = _time.monotonic()
    if _STATS_SEC <= 0 or now - _STATS_LAST[0] < _STATS_SEC:
        return
    elapsed = now - _STATS_LAST[0] if _STATS_LAST[0] else float(_STATS_SEC)
    _STATS_LAST[0] = now
    s = _STATS
    if not s["calls"]:
        return
    logger.info(
        "PLE mmap stats (last %.0fs): %d ops, op %.0f ms total (%.2f ms/op), "
        "gather %.0f ms total (%.2f ms/op), %d rows, %.1f MiB read",
        elapsed, s["calls"], s["op_ms"], s["op_ms"] / s["calls"],
        s["gather_ms"], s["gather_ms"] / s["calls"],
        s["rows"], s["bytes"] / 2**20,
    )
    s.update(calls=0, op_ms=0.0, gather_ms=0.0, rows=0, bytes=0)


def _lookup_impl(
    input_ids: torch.Tensor,
    query_start_loc: torch.Tensor,
    ngram_context: torch.Tensor,
    output: torch.Tensor,
    layer_name: str,
) -> None:
    import time as _time

    t0 = _time.perf_counter()
    layer = _REGISTRY[layer_name]
    result = layer._ple_mmap_orig_forward_impl(
        None, input_ids, query_start_loc, ngram_context
    )
    output[: result.shape[0]].copy_(result.to(output.dtype))
    _STATS["calls"] += 1
    _STATS["op_ms"] += (_time.perf_counter() - t0) * 1e3
    _stats_log()


def _lookup_fake(
    input_ids: torch.Tensor,
    query_start_loc: torch.Tensor,
    ngram_context: torch.Tensor,
    output: torch.Tensor,
    layer_name: str,
) -> None:
    return


def _register_op() -> None:
    if hasattr(torch.ops.vllm, _OP_NAME):
        return
    from vllm.utils.torch_utils import direct_register_custom_op

    direct_register_custom_op(
        op_name=_OP_NAME,
        op_func=_lookup_impl,
        mutates_args=["output"],
        fake_impl=_lookup_fake,
    )


def apply(cls: type) -> None:
    """Patch ``Qwen3_8FlashNextNGramEmbedding`` (pass the class) when enabled."""
    if not enabled():
        return
    if getattr(cls, "_ple_mmap_patched", False):
        return
    mod = sys.modules[cls.__module__]
    orig_init = cls.__init__
    orig_load_weights = cls.load_weights

    def __init__(self, config, embedding_dim, ple_dense_layer_id, max_total_tokens,
                 max_num_reqs, prefix, quant_config=None, params_dtype=None):
        # Run the stock constructor (hash buffers, workspaces, ...) with the
        # embedding class swapped for our placeholder so nothing large is
        # allocated. quant_config=None keeps the stock code from selecting an
        # FP8 quant method that would create an FP8 weight parameter.
        real_embedding_cls = mod.VocabParallelEmbedding
        mod.VocabParallelEmbedding = lambda n, d, **_kw: _MmapNgramEmbedding(n, d)
        try:
            orig_init(self, config, embedding_dim, ple_dense_layer_id,
                      max_total_tokens, max_num_reqs, prefix,
                      quant_config=None, params_dtype=params_dtype)
        finally:
            mod.VocabParallelEmbedding = real_embedding_cls
        self._ple_mmap_prefix = prefix
        _REGISTRY[prefix] = self
        self._ple_mmap_model_path = None
        try:
            from vllm.config import get_current_vllm_config
            self._ple_mmap_model_path = get_current_vllm_config().model_config.model
        except Exception as exc:  # pragma: no cover - defensive
            logger.warning("PLE mmap: cannot read model path from vllm config: %s", exc)
        if params_dtype is not None:
            self.ngram_embedding._zeros_dtype = params_dtype
        logger.info(
            "PLE mmap: %s -> placeholder embedding (%d rows x %d), table will be mmapped",
            prefix, self.ngram_embedding.org_vocab_size, self.head_dim,
        )

    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        loaded: set[str] = set()
        rest: list[tuple[str, torch.Tensor]] = []
        for name, w in weights:
            if name.startswith("ngram_embedding.shard_") and name.endswith(".weight"):
                loaded.add(name)  # served from disk, never materialised
                continue
            if name == "ngram_embedding.weight_scale":
                self.register_buffer(
                    "_offload_weight_scale",
                    w.detach().to(device=torch.accelerator.current_accelerator()),
                    persistent=False,
                )
                # Late fold: the HashK table may already exist (created by an
                # earlier load_weights call, before the scale streamed in).
                _hk_tab = getattr(self.ngram_embedding, "table", None)
                if isinstance(_hk_tab, HashKPleTable) and not _hk_tab.scale_folded:
                    _hk_tab.fold_weight_scale(
                        float(w.detach().to("cpu").reshape(-1)[0])
                    )
                loaded.add(name)
                continue
            rest.append((name, w))
        loaded.update(orig_load_weights(self, rest))
        _setup_table(self)
        return loaded

    def _setup_table(self) -> None:
        if self.ngram_embedding.table is not None:
            return
        # HashK mode: compressed 12.8 GB table instead of the ~51 GB shards.
        # Skips shard discovery entirely; W dim must match head_dim.
        hk = _hashk_path()
        if hk:
            if not os.path.isfile(hk):
                raise RuntimeError(f"PLE HashK: artifact not found: {hk!r}")
            table = HashKPleTable(hk)
            if int(table.dim) != int(self.head_dim):
                raise RuntimeError(
                    f"PLE HashK: artifact dim {table.dim} != head_dim {self.head_dim}"
                )
            # Fold in the FP8 weight_scale (SGLang applies it after the hashk
            # gather; vLLM's bf16 dequant is a no-op so we do it here).
            ws = getattr(self, "_offload_weight_scale", None)
            if ws is not None:
                table.fold_weight_scale(
                    float(ws.detach().to("cpu").reshape(-1)[0])
                )
            else:
                # The scale does not reliably stream under this name (the
                # placeholder embedding sits outside vLLM's checkpoint param
                # routing). Read it straight from the checkpoint index -- the
                # same proven trick the stock mmap path uses below.
                model_path = self._ple_mmap_model_path
                m = re.search(r"layers\.(\d+)\.", self._ple_mmap_prefix)
                if not model_path or not os.path.isdir(model_path) or not m:
                    raise RuntimeError(
                        "PLE HashK: weight_scale not streamed and checkpoint "
                        "path unavailable for direct read"
                    )
                _shards, _dt, scale_entry = _find_shards(
                    model_path, int(m.group(1))
                )
                if scale_entry is None:
                    raise RuntimeError(
                        "PLE HashK: ngram_embedding.weight_scale not found in "
                        f"checkpoint index under {model_path!r}"
                    )
                ws_t = _read_scale(scale_entry)
                self.register_buffer(
                    "_offload_weight_scale",
                    ws_t.to(torch.accelerator.current_accelerator()),
                    persistent=False,
                )
                table.fold_weight_scale(float(ws_t.reshape(-1)[0]))
                logger.info(
                    "PLE HashK: weight_scale read from checkpoint index and "
                    "folded (%.6g)", table.weight_scale,
                )
            if _env_int("VLLM_PLE_MMAP_PREWARM", 0) or _env_int("VLLM_PLE_HASHK_PREWARM", 0):
                logger.info("PLE %s: prewarming page cache (%.2f GiB)...",
                            table.format, table.bytes_total / 2**30)
                table.prewarm()
            self.ngram_embedding.table = table
            logger.info(
                "PLE HashK: layer table ready (%s), bf16 rows, dequant no-op", hk
            )
            # Try the GPU gatherer now (weights load: VRAM is most abundant
            # before the KV pool grows); forward retries on any failure.
            table._ensure_gpu_gatherer()
            return
        # VLLM_PLE_MMAP_DIR: serve the table from a different directory than the
        # checkpoint (e.g. an FP8 copy of the table on local NVMe).
        model_path = os.environ.get("VLLM_PLE_MMAP_DIR") or self._ple_mmap_model_path
        if not model_path or not os.path.isdir(model_path):
            raise RuntimeError(
                f"PLE mmap: table path {model_path!r} is not a local directory; "
                "point --model at the downloaded snapshot or set VLLM_PLE_MMAP_DIR"
            )
        m = re.search(r"layers\.(\d+)\.", self._ple_mmap_prefix)
        if not m:
            raise RuntimeError(f"PLE mmap: cannot find layer index in {self._ple_mmap_prefix!r}")
        layer_idx = int(m.group(1))
        shards, dtype_str, scale_entry = _find_shards(model_path, layer_idx)
        if not shards:
            raise RuntimeError(f"PLE mmap: no shard tensors for layer {layer_idx} under {model_path}")
        cols = shards.pop("__cols__")  # type: ignore[arg-type]
        if cols != self.head_dim:
            raise RuntimeError(f"PLE mmap: shard width {cols} != head_dim {self.head_dim}")
        if dtype_str not in _TABLE_DTYPES:
            raise RuntimeError(f"PLE mmap: unsupported shard dtype {dtype_str}")
        if dtype_str in _FP8_DTYPES and not hasattr(self, "_offload_weight_scale"):
            if scale_entry is None:
                raise RuntimeError("PLE mmap: FP8 shards without ngram_embedding.weight_scale")
            self.register_buffer(
                "_offload_weight_scale",
                _read_scale(scale_entry).to(torch.accelerator.current_accelerator()),
                persistent=False,
            )
        parts = int(self.split_ngram_parts)
        vocab = int(self.ngram_embedding.org_vocab_size)
        shard_size = math.ceil(vocab / parts)
        for idx, (_p, _o, rows) in shards.items():
            expected = max(0, min(shard_size, vocab - idx * shard_size))
            if rows != expected:
                raise RuntimeError(
                    f"PLE mmap: shard {idx} has {rows} rows, expected {expected}"
                )
        table = MmapPleTable(
            shards, shard_size, cols * _itemsize(dtype_str), _TABLE_DTYPES[dtype_str],
            workers=_env_int("VLLM_PLE_MMAP_WORKERS", 32),
            chunk=_env_int("VLLM_PLE_MMAP_CHUNK", 2048),
        )
        if _env_int("VLLM_PLE_MMAP_PREWARM", 0):
            logger.info("PLE mmap: prewarming page cache (%.1f GiB)...", table.rows_total * table.row_bytes / 2**30)
            table.prewarm()
        self.ngram_embedding.table = table
        logger.info(
            "PLE mmap: layer %d, %d shards, %d rows x %d B (%.1f GiB on disk), dtype %s, %d workers",
            layer_idx, len(shards), table.rows_total, table.row_bytes,
            table.rows_total * table.row_bytes / 2**30, dtype_str, table.pool._max_workers,
        )

    def forward_impl(self, hidden_states, input_ids, query_start_loc, ngram_context,
                     output_buffer=None):
        del hidden_states, output_buffer
        num_tokens = input_ids.reshape(-1).shape[0]
        table = self.ngram_embedding.table
        dtype = table.torch_dtype if table is not None else self.ngram_embedding._zeros_dtype
        output = torch.empty(
            (num_tokens, self.embedding_dim), dtype=dtype, device=input_ids.device
        )
        getattr(torch.ops.vllm, _OP_NAME)(
            input_ids, query_start_loc, ngram_context, output, self._ple_mmap_prefix
        )
        return output

    _register_op()
    cls._ple_mmap_orig_forward_impl = cls.forward_impl
    cls.forward_impl = forward_impl
    cls.__init__ = __init__
    cls.load_weights = load_weights
    cls._setup_table = _setup_table
    cls._ple_mmap_patched = True
    logger.info("PLE mmap patch applied to %s.%s", cls.__module__, cls.__name__)
