# PLE PQ 压表 —— 生产配置与运维手册

> 固化日期：2026-09-12
> 状态：**已上线，稳定运行**（容器 restarts=0）
> 主角：`qwen38-flash` 容器的 PLE n-gram Embedding 表，从 HashK R4 换成 PQ M5

---

## 一、当前生产配置（唯一权威）

`~/restart-k4.sh` 第 6 行：

```bash
MODE=hybrid IMAGE=qwen38-flash-next-gx10-mtp-hashk:v1.0.1 GPU_MEM=0.90 SEQS=8 \
PREFIX_CACHE=1 PREWARM=1 DRAFT_VOCAB=147456 \
PLE_HASHK=/hf/hashk/ple_pq_M5.pt \
PLE_RUNTIME=${HOME}/ple-pq/rt2/vllm_ple_mmap.py \
CC='-cc.cudagraph_mode=FULL_DECODE_ONLY -cc.splitting_ops=[]' MTP=4 \
bash scripts/serve.sh
```

执行前 cwd 必须是 `~/qwen38-flash-next-gx10-mtp-hashk/`（脚本内用相对路径 `scripts/serve.sh`）。

关键点：
- **`PLE_RUNTIME`** 是单文件 volume 覆盖（`-v .../vllm_ple_mmap.py:/usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py:ro`），
  由 `serve.sh` 里的 `PLE_VOL=()` 段落生效，**免重建镜像**。
- **`PLE_HASHK`** 变量名沿用旧名，现在指向 PQ 产物；运行时会按 `codebooks` 键自动识别格式（PQ vs HashK）。
- `MTP=4` + `FDO` 的组合见「已知问题」。

## 二、产物与文件

| 文件 | 大小 | 说明 |
|---|---|---|
| `~/.cache/huggingface/hashk/ple_pq_M5.pt` | 1.5 GB | **当前在用**。M=5, K=256, seg_dim=32, 16 heads；codes 1.49 GiB + codebooks 2.50 MB；320,001,446 行全保留（零碰撞） |
| `~/.cache/huggingface/hashk/ple_hashk_R4.pt` | 12 GB | 回滚用。HashK R4，320M 行 → 80M 行（4 路碰撞），cos ≈ 0.50 |
| `~/.cache/.../flashnext-one-spark/ple_hashk_R4.pt` | 12 GB | HashK R4 的第二份备份（root 所有） |
| `~/ple-pq/rt2/vllm_ple_mmap.py` | 55,886 B | **当前在用运行时**，md5 `da83837240a9625ac1f076be0b3ec2a4`。以镜像烘焙版（912 行）为基线打入 PQ 支持 + 内联 `GpuPqGatherer` |
| `~/ple-pq/vllm_ple_mmap_baked.py` | 40,693 B | 从镜像 `docker run --entrypoint cat ... :v1.0.1` 取回的烘焙版原样（912 行），一切补丁的**正确基线** |
| `~/ple-pq/DISABLED_v1_vllm_ple_mmap_pq.py` | 42,265 B | v1 失败版（打错基线，丢了 GPU gatherer），留档警示 |
| `~/ple-pq/build_pq_ple.py` | 11,423 B | PQ 构建脚本（GEMM 展开走 BLAS；全量构建 199 s） |
| `~/ple-pq/pq_probe.py` / `pq_probe_result.json` | — | 可行性探针（纯 CPU，可不停服跑） |
| `~/ple-pq/pq_gather_bench.py` | — | gather 访存微基准（**在当前内存占用下无法运行**，见下） |

## 三、回滚步骤（一次重启，约 8 分钟）

1. 编辑 `~/restart-k4.sh`，把 `PLE_HASHK=/hf/hashk/ple_pq_M5.pt` 改回 `/hf/hashk/ple_hashk_R4.pt`，
   并把 `PLE_RUNTIME=...` 整段删掉（HashK 用镜像烘焙版即可，不需要覆盖）。
2. 停容器：`docker stop qwen38-flash`
3. 执行 `~/restart-k4.sh`
4. 校验日志出现 `PLE PQ` 或 HashK 装载行 + `Capturing CUDA graphs (FULL): 100%` + `Application startup complete.`

> 若要把 MTP 也一起改回 3：改 `restart-k4.sh` 里的 `MTP=4` → `MTP=3`，同一次重启生效。

## 四、实测收益（PQ M5 vs HashK R4）

| 指标 | HashK R4 | PQ M5 | 变化 |
|---|---|---|---|
| PLE 表内存 | 11.92 GiB | **1.49 GiB** | −10.4 GiB |
| Available KV | 14.85 GiB | **27.95 GiB** | +88% |
| KV tokens | 500,583 | **942,602** | +88% |
| 262k 上下文并发 | 1.91x | **3.60x** | +88% |

## 五、已知问题（重要，勿遗忘）

### 1. ~~MTP=4 是负优化~~ —— 旧结论已作废（2026-09-14 重启 A/B 定案）
**现行配置（MTP-FP8 草稿头 + FDO + PQ M5）下 k=3 / k=4 打平（±1%），k=4 维持不动。**

同日 serve.sh 全参数复刻、仅改 MTP 值的控制变量 A/B（temp=0，JSON/PROSE ×2，/metrics 计数器差分）：

| 指标 | MTP=3 | MTP=4 | Δ |
|---|---|---|---|
| 单步时延 T_step | **68.4~68.5 ms** | **75.3~75.9 ms** | **+7.4 ms = 第 4 个 draft 步真实成本** |
| 单流 tok/s（JSON） | 48.4 | 48.7 | +0.6% |
| 单流 tok/s（PROSE） | 36.7 | 36.4 | −0.8% |

第 4 步 break-even ≈ 7.8 ms（逐位条件接受率 p₄≈0.80），实测边际 7.4 ms → 基本打平，
无可操作差异（JSON 微向 k=4、PROSE 微向 k=3）。

**旧结论来源（勿再引用）**：原「−9.6% / LongCode 43.7→35.6」的 k=3 基线是 09-09 HashK R4
+ 非 FP8 草稿头时代数据（当时每 draft 步 ~24 ms）；09-13 的 MTP-FP8 把 draft 步压到 ~7.4 ms，
跨时代对照是夹带变量的伪影。

测量注意：同 prompt 跨 boot 接受长度有非确定性（out/step 3.69 vs 3.40），但 T_step 高度可复现；
重启后首个探针有 ~96 ms 冷启动离群值须剔除。快照 `~/qwen38-flash-inspect-20260914-before-k3ab.json`。
剩余 MTP 优化空间只剩**高并发档动态缩 k**（`num_speculative_tokens_per_batch_size`，与 FDO 兼容已核实），
单流场景无收益。

### 2. PLE gather 不是瓶颈（已排除）
每步 gather 规模 = 16 heads × (1+MTP) = 80 ids，共约 400 次主机字节读 ≈ 51 KB
≈ **0.2 μs**，相对 83~90 ms/步占比 < 0.01%。
→ `GpuPqGatherer(route="device")` 收益可忽略，不必再试。

### 3. GX10 上做不了"零停机的 GPU 侧实验"
`gpu_memory_utilization=0.90` 会把统一内存吃满：实测 `cudaHostRegister` 对 **1 MiB 都**返回
`rc=2 (cudaErrorMemoryAllocation)`，device 侧分配 160 MiB 直接 OOM（与 memlock 无关，
容器内 `ulimit -l`=8192KB / 宿主 15.2 GiB，`--ulimit memlock=-1` 也无效）。
**任何需要摸 GPU 的验证都必须开停机窗口。**

### 4. 历史教训：补丁基线必须取自镜像
v1 崩溃（CUDA 图捕获期 D2H → 重启循环）根因是把补丁打在仓库过期源码
（`src/vllm_ple_mmap.py`，09-07，806 行）上，**丢失了镜像烘焙版（912 行）里的 GPU gatherer**。
正确基线永远是：`docker run --entrypoint cat <IMAGE> /usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py`

## 六、环境速查

- 容器端口：宿主 `18300` → 容器 `8000`
- 指标：`curl -s http://127.0.0.1:18300/metrics`
- 逐位接受率：`grep accepted_tokens_per_pos_total`（**别用 accepted/draft_tokens，分母含 MTP**）
- GB10 硬件：`sm_count=48`、`L2_cache_size=24 MiB`、`total_memory=124546 MB`
- 配置快照：`docker inspect qwen38-flash > ~/qwen38-flash-inspect-$(date +%Y%m%d-%H%M).json`
