#!/usr/bin/env python3
"""Verify the PQ runtime path against an artifact, without starting vLLM.

Loads the patched vllm_ple_mmap module directly, instantiates HashKPleTable on
the given artifact, and checks that gather() returns exactly what a manual
codebook reconstruction produces. Also exercises the format dispatch (the
artifact must NOT be detected as HashK) and the weight_scale fold guard.

Env: PQ_RUNTIME (path to vllm_ple_mmap_pq.py), PQ_ART (path to the .pt).
"""
import importlib.util
import os
import sys

import numpy as np
import torch

rt = os.environ.get("PQ_RUNTIME", "/tmp/vllm_ple_mmap_pq.py")
art_path = os.environ["PQ_ART"]

spec = importlib.util.spec_from_file_location("vpm_test", rt)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

t = mod.HashKPleTable(art_path)
print(f"[verify] class      = {type(t).__name__}")
print(f"[verify] format     = {t.format}")
print(f"[verify] M / K / seg= {t.M} / {t.K} / {t.seg_dim}")
print(f"[verify] heads/dim  = {t.heads} / {t.dim}")
print(f"[verify] total rows = {t.total}")
print(f"[verify] row_bytes  = {t.row_bytes}")
print(f"[verify] bytes_total= {t.bytes_total/2**30:.3f} GiB")
print(f"[verify] rows_total = {t.rows_total}")

if t.format != "pq":
    sys.exit("[verify] FAIL: artifact was not dispatched to the PQ layout")
if t.row_bytes != 320 or t.dim != 160:
    sys.exit(f"[verify] FAIL: row_bytes={t.row_bytes} dim={t.dim}, expected 320/160")
if not isinstance(t, mod.HashKPleTable):
    sys.exit("[verify] FAIL: not a HashKPleTable instance -> isinstance guard "
             "in load_weights would skip the weight_scale fold")

# The guard must fire before the fold.
try:
    t.gather(np.array([0], dtype=np.int64))
    sys.exit("[verify] FAIL: gather() ran before fold_weight_scale()")
except RuntimeError as e:
    print(f"[verify] pre-fold guard OK ({str(e)[:48]}...)")

t.fold_weight_scale(1.0)

ids = np.array([0, 1, 7, 999, 12345, 2500011, 2500012, 4999999], dtype=np.int64)
rows = t.gather(ids)
print(f"[verify] gather     = {rows.shape} {rows.dtype}")
if rows.shape != (ids.size, 320) or rows.dtype != np.uint8:
    sys.exit(f"[verify] FAIL: gather returned {rows.shape} {rows.dtype}")

codes = t.codes[torch.from_numpy(ids)].numpy()
h = np.searchsorted(t.offs, ids, side="right") - 1
ok = 0
for k, i in enumerate(ids):
    hk = int(h[k])
    seg = [
        t.cb_flat[hk * t.M * t.K + m * t.K + int(codes[k, m])]
        for m in range(t.M)
    ]
    manual = torch.cat(seg).to(torch.float32)
    got = torch.from_numpy(rows[k].copy()).view(torch.bfloat16).to(torch.float32)
    if torch.allclose(manual, got, atol=1e-2):
        ok += 1
    else:
        print(f"[verify]   MISMATCH row {i}: max|d|={(manual-got).abs().max().item():.4f}")
print(f"[verify] manual reconstruction matches gather for {ok}/{ids.size} rows")
if ok != ids.size:
    sys.exit("[verify] FAIL: gather disagrees with the codebook reconstruction")

# A larger batch, to exercise the multi-head searchsorted path.
big = np.arange(0, 200000, 997, dtype=np.int64)
r2 = t.gather(big)
print(f"[verify] batch gather= {r2.shape}  (distinct heads: "
      f"{len(set(np.searchsorted(t.offs, big, side='right') - 1))})")
if r2.shape != (big.size, 320):
    sys.exit("[verify] FAIL: batch gather shape")

print("[verify] RUNTIME OK")
