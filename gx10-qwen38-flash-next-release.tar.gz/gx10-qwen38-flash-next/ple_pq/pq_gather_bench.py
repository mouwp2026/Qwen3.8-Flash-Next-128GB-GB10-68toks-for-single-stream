"""PQ gather micro-benchmark v2 -- zero-downtime, read-only, no service impact.

v1 could not arm the host/UVA route: cudaHostRegister returned rc=2
(cudaErrorMemoryAllocation) for a 160 MiB region even with memlock unlimited.
That is itself a finding. So v2 does two things:

  (1) probes the registration ceiling (largest region cudaHostRegister accepts
      on this live GX10), scanning large -> small;
  (2) measures the gather kernel's ABSOLUTE latency on the device route, at the
      realistic per-decode-step size band, to decide whether PLE gather can
      possibly account for the observed per-step regression.

The device route is a valid LOWER BOUND for the host route: the kernel body is
identical, only the codes pointer differs (VRAM-resident vs UVA-mapped host).
"""

import ctypes

import numpy as np
import torch
import triton
import triton.language as tl

HEADS, M, K, SEG = 16, 5, 256, 32
DIM = M * SEG
ROWS = 32 * 1024 * 1024
BLOCK = 64
NS = [16, 64, 256, 1024, 4096, 16384]
REPS = 500


@triton.jit
def _pq_gather_kernel(
    ids_ptr, out_ptr, codes_ptr, cb_ptr, offs_ptr, n,
    HEADS: tl.constexpr, M: tl.constexpr, K: tl.constexpr,
    SEG: tl.constexpr, DIM: tl.constexpr, BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    t = pid * BLOCK + tl.arange(0, BLOCK)
    tmask = t < n
    id_ = tl.load(ids_ptr + t, mask=tmask, other=0).to(tl.int64)

    h = tl.zeros([BLOCK], dtype=tl.int32)
    for i in tl.static_range(1, HEADS):
        bound = tl.load(offs_ptr + i)
        h += tl.where(id_ >= bound, 1, 0).to(tl.int32)

    base = id_ * M
    h64 = h.to(tl.int64)
    s = tl.arange(0, SEG)
    for m in tl.static_range(M):
        c = tl.load(codes_ptr + base + m, mask=tmask, other=0).to(tl.int64)
        cb_row = ((h64 * M + m) * K + c)[:, None]
        v = tl.load(cb_ptr + cb_row * SEG + s[None, :],
                    mask=tmask[:, None], other=0.0)
        tl.store(out_ptr + t[:, None] * DIM + (m * SEG + s)[None, :], v,
                 mask=tmask[:, None])


@triton.jit
def _noop_kernel(ids_ptr, out_ptr, n, DIM: tl.constexpr, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    t = pid * BLOCK + tl.arange(0, BLOCK)
    v = tl.load(ids_ptr + t, mask=t < n, other=0).to(tl.float32)
    tl.store(out_ptr + t * DIM, v, mask=t < n)


def time_graph(fn, reps=REPS):
    for _ in range(3):
        fn()
    torch.cuda.synchronize()
    g = torch.cuda.CUDAGraph()
    with torch.cuda.graph(g):
        fn()
    for _ in range(10):
        g.replay()
    torch.cuda.synchronize()
    st, en = torch.cuda.Event(True), torch.cuda.Event(True)
    st.record()
    for _ in range(reps):
        g.replay()
    en.record()
    torch.cuda.synchronize()
    return st.elapsed_time(en) / reps * 1000.0


def probe_ceiling(libc, mibs):
    for mib in mibs:
        buf = torch.empty(mib * 2**20, dtype=torch.uint8)
        rc = libc.cudaHostRegister(
            ctypes.c_void_p(buf.data_ptr()),
            ctypes.c_size_t(buf.numel() * buf.element_size()),
            ctypes.c_uint(0))
        print(f"  {mib:>4} MiB -> rc={rc}")
        if rc == 0:
            libc.cudaHostUnregister(ctypes.c_void_p(buf.data_ptr()))
            del buf
            return mib
        del buf
    return 0


def main():
    torch.manual_seed(0)
    dev = "cuda"
    props = torch.cuda.get_device_properties(0)
    print(f"device: {torch.cuda.get_device_name(0)} "
          f"(sm={props.multi_processor_count}, L2={props.L2_cache_size / 2**20:.0f} MiB)")

    libc = ctypes.CDLL("libcudart.so")
    print("\n[1] cudaHostRegister ceiling probe (large -> small, unregister on success)")
    ceil = probe_ceiling(libc, [160, 128, 96, 64, 32, 16, 8, 4, 2, 1])
    print(f"  => ceiling = {ceil} MiB")
    if ceil < 24:
        print("  (below the 24 MiB L2 -- the host route cannot be timed "
              "meaningfully on this box right now; proceeding with device route)")

    rng = np.random.default_rng(7)
    codes_cpu = torch.from_numpy(rng.integers(0, 256, size=ROWS * M, dtype=np.uint8))
    codes_dev = codes_cpu.to(dev).contiguous()
    print(f"\n[2] synthetic code table: {codes_dev.numel() * codes_dev.element_size() / 2**20:.0f} MiB "
          f"({ROWS} rows x {M} B, AoS) -> device route")

    cbs = torch.randn(HEADS * M * K, SEG, dtype=torch.float32, device=dev)
    per_head = ROWS // HEADS
    offs = torch.tensor([i * per_head for i in range(HEADS)] + [ROWS],
                        dtype=torch.int64, device=dev)

    hdr = (f"{'n ids':>7} | {'noop':>9} | {'device gather':>14} | "
           f"{'gather-noop':>12} | {'per-id':>9}")
    print("\n[3] absolute latency (CUDA-graph replay, " + str(REPS) + " reps)")
    print(hdr)
    print("-" * len(hdr))

    for n in NS:
        ids = torch.randint(0, ROWS, (n,), dtype=torch.int32, device=dev)
        out = torch.empty((n, DIM), dtype=torch.float32, device=dev)
        grid = (triton.cdiv(n, BLOCK),)

        t_noop = time_graph(lambda: _noop_kernel[grid](
            ids, out, n, DIM=DIM, BLOCK=BLOCK))
        t_dev = time_graph(lambda: _pq_gather_kernel[grid](
            ids, out, codes_dev, cbs, offs, n,
            HEADS=HEADS, M=M, K=K, SEG=SEG, DIM=DIM, BLOCK=BLOCK))

        print(f"{n:>7} | {t_noop:>7.2f}us | {t_dev:>12.2f}us | "
              f"{t_dev - t_noop:>10.2f}us | {(t_dev - t_noop) / n * 1000:>7.2f}ns")

    print("\n[4] verdict helper")
    print("  Observed production regression: ~83-90 ms per decode step "
          "(194.26 s / 2336 steps, LongCode 35.6 tok/s @ 3.21 tok/step).")
    print("  Realistic per-step gather size: 16 heads x (1+MTP) tokens "
          "= 80 ids at MTP=4.")


if __name__ == "__main__":
    main()
