# GPU-HashK: CUDA-graph-safe PLE gather for Qwen3.8-Flash-Next on DGX Spark

GPU-resident gather path for the HashK-based **P**ositional **L**ogit **E**mbedding (PLE) layer
of **Qwen3.8-Flash-Next**, served by vLLM on NVIDIA GB10 (DGX Spark, 128 GB unified memory).

It replaces the engine's CPU-side `np.unique` + pinned-memory H2D lookup with a single
vectorized **Triton kernel** that reads the 12.8 GB fp8 HashK table in place via
**CUDA Unified Virtual Addressing** (`cudaHostRegister` on the existing mmap) — then, with that
unlocked, switches the engine to **`FULL_DECODE_ONLY` CUDA graphs**, which is what actually
delivers the throughput win.

> **TL;DR**: +5.6% single-stream decode throughput (+18% on long decode),
> MTP draft decode moves from *no graph* to a *full CUDA graph*, numerics bit-identical
> (0-bit mismatch on a 21-million-element bitwise parity test).

---

## Why: the PIECEWISE tax

The stock PLE lookup path of [blazux/qwen38-flash-next-gx10-mtp-hashk](https://github.com/blazux/qwen38-flash-next-gx10-mtp-hashk)
is CPU-bound by design:

```
D2H ids (blocking) -> np.unique -> splitmix64 (numpy) -> fp8 fancy-index -> f32 ridge projection -> H2D
```

None of this is capturable by a CUDA graph (blocking D2H sync + numpy control flow).
The engine therefore has to keep `vllm::ple_mmap_lookup` inside `splitting_ops` and run
**PIECEWISE** graphs — every decode step is split into ~12 graph segments with
CPU relaunches in between, and the MTP speculator's draft decode runs with **no graph at all**
(see `AutoRegressiveSpeculator.init_cudagraph_manager`: draft graphs require the engine's
decode mode to be `FULL`).

## What: GPU gatherer + FULL_DECODE_ONLY

```
before (PIECEWISE, splitting_ops=[... 12 ops ...])
  decode step = [graph]-[CPU launch]-[graph]-[CPU launch]- ... -[graph]   (11 splits)
  MTP draft decode: NONE (eager)

after (FULL_DECODE_ONLY, splitting_ops=[])
  decode step = [============ one full CUDA graph ============]
  MTP draft decode: FULL graph
  PLE lookup    = Triton kernel inside the graph, reading the host mmap via UVA
```

Key properties:

- **Zero-copy, zero-registration-cost**: the kernel dereferences the *same* mmap pages the CPU
  path uses, pinned into the GPU address space with `cudaHostRegister`. No second copy of the
  12.8 GB table.
- **Bit-identical numerics**: fp8→f32 dequant goes through a 256-entry LUT built from torch's own
  cast; splitmix64 runs on uint64 lanes. Parity vs. the CPU reference: **0 mismatched bits**
  over 20,979,200 elements on the real artifact.
- **Graceful degradation**: if UVA registration or the self-check fails (e.g. another process
  owns the VRAM budget), the table silently stays on the original CPU path.
- **Kill switch**: `VLLM_PLE_GPU=0` disables the entire feature at runtime.

## Benchmarks

Measured on a DGX Spark (GB10, 128 GB UMA) running `qwen3.8-flash-next` (NVFP4 fp8hybrid,
262K ctx, MTP k=3) with `--gpu-memory-utilization 0.90`. Methodology: [azampatti sgbench](https://github.com/azampatti/GB10-3.8-Flash-Next)
(prompt pool / token tiers / Run-2 reporting unchanged). Raw logs in [`docs/bench-logs/`](docs/bench-logs/).

**Single-stream decode (tok/s, Run 2):**

| workload | PIECEWISE | **FULL_DECODE_ONLY** | Δ |
|----------|----------:|---------------------:|---|
| Q&A      | 33.9      | **37.6**             | +10.9% |
| Code     | 40.2      | 40.1                 | ±0 |
| JSON     | 49.6      | **49.8**             | +0.4% |
| Math     | 43.8      | **44.7**             | +2.1% |
| LongCode | 36.7      | **43.4**             | **+18.3%** |
| **mean** | 40.8      | **43.1**             | **+5.6%** |

**6-way concurrent decode (aggregate tok/s, Run 2):** mean 102.5 → 102.5 (flat;
Math +3.6%, Code −6.6% — see [Known limitations](#known-limitations)).

## Requirements

- NVIDIA GB10 (DGX Spark) or any CUDA host with enough address space for UVA;
  ~17 GiB of *unallocated* unified memory for the 12.8 GiB table registration + driver page tables
- vLLM with the `vllm_ple_mmap` HashK PLE patch from the upstream deployment above
  (this repo's patch is anchored to that file)
- PyTorch + Triton (whatever the vLLM image ships), CUDA runtime visible via `ctypes`
- A HashK PLE artifact (`ple_hashk_R4.pt`, R=4, 16 heads, dim=160) wired up as upstream documents

## Install

1. Copy the gatherer into the vLLM site-packages of the serving image:

   ```bash
   docker cp scripts/hashk_gpu.py <container>:/usr/local/lib/python3.12/dist-packages/hashk_gpu.py
   ```

2. Apply the patch to `vllm_ple_mmap.py` in the same directory — either hunk-wise:

   ```bash
   cd /usr/local/lib/python3.12/dist-packages
   patch -p1 < ple-gpu-gatherer.patch          # 3 hunks: attrs + _ensure_gpu_gatherer + forward branch
   ```

   ...or drop in [`patch/vllm_ple_mmap.py.patched-full`](patch/vllm_ple_mmap.py.patched-full)
   as the whole file (the exact file this repo's benchmarks were run with).

3. **Bake it into the image** (`docker commit` or rebuild). `docker rm` discards container-layer
   edits; only `docker restart` preserves them — a fresh `docker run` will silently fall back
   to the unpatched image.

## Launch

The two flags that matter, added to the upstream launch line:

```bash
'-cc.cudagraph_mode=FULL_DECODE_ONLY' \
'-cc.splitting_ops=[]' \
--gpu-memory-utilization 0.90 \
...
```

- `splitting_ops=[]` is safe **only with the GPU gatherer installed** — with the CPU gatherer it
  will fail at graph capture.
- `--gpu-memory-utilization` budget must cover the UVA registration. On a 128 GB Spark:

  | util | budget | KV cache | outcome |
  |-----:|-------:|---------:|---------|
  | 0.80 |  97 GiB | 2.5–3.5 GiB | ❌ below the 7.57 GiB floor for 262K ctx (restart loop) |
  | 0.90 | 109 GiB | 14.9–15.1 GiB | ✅ recommended steady state |
  | 0.94 | 114 GiB | 20.1 GiB | ✅ maximum KV headroom |

  Roughly every 0.01 of utilization ≈ 1.2 GiB of KV cache.

## Verify

```bash
# 1. Engine log — the gatherer reports itself once at startup:
#    "PLE HashK: GPU gatherer ACTIVE (UVA host route, self-check 0 bits / ulp<=0)"
docker logs <container> 2>&1 | grep 'GPU gatherer'

# 2. Graph capture — decode must show FULL captures for BOTH target and drafter:
#    Capturing CUDA graphs (FULL) ... / Capturing decode CUDA graphs (FULL) ...

# 3. Bitwise parity vs. the CPU reference (no engine needed, run in the container):
python3 scripts/test_real_artifact.py

# 4. End-to-end preflight (loads the artifact, patches nothing):
python3 scripts/preflight_integration.py

# 5. Throughput:
PORT=18300 ./bench/sgbench.sh 1     # single stream
PORT=18300 ./bench/sgbench.sh 6     # 6-way concurrent
```

If the gatherer cannot initialize (VRAM budget held by another process, self-check failure,
registration error), every failure mode logs a warning and keeps serving on the CPU path —
the engine never crashes because of this patch.

## Rollback

| level | action | effect |
|-------|--------|--------|
| runtime | `VLLM_PLE_GPU=0` (env) | gatherer never built; CPU path |
| mode | `-cc.cudagraph_mode=PIECEWISE -cc.splitting_ops='[...]'` | original engine behavior |
| files | restore `vllm_ple_mmap.py.bak*` | unpatched |

## Scripts

| path | what |
|------|------|
| `scripts/hashk_gpu.py` | `GpuHashKGatherer` — Triton kernel + UVA registration (drop-in module) |
| `patch/ple-gpu-gatherer.patch` | unified diff against upstream `vllm_ple_mmap.py` |
| `patch/vllm_ple_mmap.py.patched-full` | full patched file (reference) |
| `scripts/test_real_artifact.py` | bitwise parity: GPU kernel vs. CPU reference on the real 12.8 GB artifact |
| `scripts/preflight_integration.py` | standalone rehearsal of `_ensure_gpu_gatherer` + forward parity |
| `scripts/bench_decode.py` | micro-benchmark: per-step gather latency, eager vs. graph |
| `scripts/probe_uva.py` | UVA registration cost probe (page-table overhead, address space) |
| `bench/sgbench.sh` | port of azampatti's sgbench to any OpenAI-compatible endpoint |

## Known limitations

- **`Code` @ N=6 concurrent: −6.6%** (≈99 vs ≈106 tok/s), reproduced across 3 runs at the
  Run-2 measurement point while Run-1 numbers sit at baseline (~105). Hypothesis: the full-graph
  capture set misses some dynamic-batch shapes the MTP drafter produces mid-run, falling back to
  eager. Not blocking; PRs with a graph-shape analysis welcome.
- **Memory floor**: UVA registration deducts ~13 GiB from the profiler-visible memory, and the
  driver page tables are *non-linear* — the first registration costs 3–4 GiB of page tables.
  Do not run this next to another VRAM-hungry process.
- **GB10 quirks**: the unified-memory accounting bug (needs `drop_caches`), LPDDR5X without ECC,
  and memory exhaustion that freezes the machine instead of triggering OOM — all inherited from
  the platform, see upstream repo.

## Acknowledgements

- [blazux/qwen38-flash-next-gx10-mtp-hashk](https://github.com/blazux/qwen38-flash-next-gx10-mtp-hashk) — the deployment line and the CPU HashK PLE implementation this patch extends
- [azampatti/GB10-3.8-Flash-Next](https://github.com/azampatti/GB10-3.8-Flash-Next) — sgbench methodology
- vLLM V1 cudagraph machinery (`CUDAGraphMode.FULL_DECODE_ONLY`)

## License

MIT
