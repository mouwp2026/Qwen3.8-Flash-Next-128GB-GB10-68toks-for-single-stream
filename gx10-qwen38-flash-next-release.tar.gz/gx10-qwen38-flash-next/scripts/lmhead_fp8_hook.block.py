

# ---------------------------------------------------------------------------
# 10. lm_head: runtime fp8 head + bf16 top-K rerank   (VLLM_LMHEAD_FP8=1) ----
#
# The lm_head is the largest *dense* read of a decode step (bf16 [248320,2560]
# = 1.271 GB) and ModelOpt's `ignore` list excludes it from quantization, so it
# has been read at bf16 on every step while everything around it went fp8/nvfp4.
#
# This block deliberately does NOT touch checkpoint loading or the quantization
# pipeline. That is not a style choice: the MTP draft head loads the *same*
# `lm_head.weight` tensor name at bf16 into its own unquantized ParallelLMHead
# (see mtp.py `_remap_mtp_weight_name` -> "lm_head.", and the ParallelLMHead()
# call there which passes no quant_config). Re-quantizing the checkpoint, or
# making the target head fp8 at load time, would hand the draft head fp8
# magnitudes reinterpreted as bf16 -- plausibly without any error, silently
# destroying draft acceptance. Instead we leave loading 100% identical and
# build a per-tensor fp8 copy of the *target* head once, after loading.
#
# The fp8 copy only does the *search*; the top-K candidate rows are then
# re-scored exactly from the bf16 weight, so greedy output stays bit-exact.
# Same idea as the MTP draft-head patch, applied to the full 248320-row head.
#
# Measured on the real weight (64 random hidden probes at 4 scales):
#   * per-tensor fp8 == blockwise-128 quality here (global |w|max is only 0.412,
#     so a single scale barely loses anything): relL2 2.65% vs 2.64%
#   * bare fp8 flips 3-4 of 64 top-1 picks -> the rerank is required, not optional
#   * the true top-1 lands inside the fp8 top-8 in 64/64 probes -> K=32 keeps 4x
#     margin; reranked greedy is 64/64 identical to bf16 at K>=16
#   * read per decode step: 1.271 GB -> 0.636 GB + K*H*2 B (K=32: 160 KB)
#       = 635 MB/step @273 GB/s = 2.33 ms  -> 3.1% of a 75 ms k=4 step
#
# Env: VLLM_LMHEAD_FP8=1 (default off)
#      VLLM_LMHEAD_FP8_K=32        rerank width
#      VLLM_LMHEAD_FP8_TCHUNK=64   rows per _scaled_mm call
#      VLLM_LMHEAD_FP8_VCHUNK=8192 rows per quantize chunk (peak temp)
# ---------------------------------------------------------------------------
_LH_ON = os.environ.get("VLLM_LMHEAD_FP8", "0").strip().lower() in (
    "1", "true", "yes", "on")
_LH_K = int(os.environ.get("VLLM_LMHEAD_FP8_K", "32") or "32")
_LH_TCHUNK = int(os.environ.get("VLLM_LMHEAD_FP8_TCHUNK", "64") or "64")
_LH_VCHUNK = int(os.environ.get("VLLM_LMHEAD_FP8_VCHUNK", "8192") or "8192")
_LH_FP8_MAX = 448.0
_LH_MARK = "_lmhead_fp8_marked"


def _lh_is_target_lm_head(layer, prefix) -> bool:
    """True only for the target model's lm_head (the draft head never gets here)."""
    from vllm.model_executor.layers.vocab_parallel_embedding import ParallelLMHead

    return isinstance(layer, ParallelLMHead) and prefix.rsplit(".", 1)[-1] == "lm_head"


def _lh_build(layer) -> bool:
    """Quantize the target head to per-tensor fp8 once, in bounded chunks."""
    import torch

    st = layer.__dict__
    w = layer.weight
    if w.dim() != 2 or w.dtype not in (torch.bfloat16, torch.float16):
        logger.warning(
            "[lmhead-fp8] head unusable (dtype=%s shape=%s); disabled",
            w.dtype, tuple(w.shape))
        st["_lh_disabled"] = True
        return False
    amax = w.abs().amax().clamp_min(1e-8)
    sb = (amax / _LH_FP8_MAX).to(torch.float32)
    rows, cols = w.shape
    w8 = torch.empty((cols, rows), dtype=torch.float8_e4m3fn, device=w.device)
    for off in range(0, rows, _LH_VCHUNK):
        blk = w[off:off + _LH_VCHUNK].float()
        w8[:, off:off + blk.shape[0]] = (blk / sb).clamp(
            -_LH_FP8_MAX, _LH_FP8_MAX).to(torch.float8_e4m3fn).t()
        del blk
    st["_lh_wbf"] = w          # bf16 kept for the exact re-score
    st["_lh_w8"] = w8          # [H, V] fp8, search only
    st["_lh_sb"] = sb.reshape(1)
    st["_lh_calls"] = 0
    torch.cuda.empty_cache()
    logger.info(
        "[lmhead-fp8] ON: rows=%d K=%d | read %.0f MiB bf16 -> %.0f MiB fp8 "
        "(+%.0f KB rerank) | head amax=%.5f",
        rows, _LH_K, w.numel() * 2 / 1048576, w8.numel() / 1048576,
        _LH_K * cols * 2 / 1024, float(sb) * _LH_FP8_MAX)
    return True


def _lh_forward(lm_head, hidden_states, embedding_bias):
    """fp8 search over the full vocab + exact bf16 re-score of the top-K rows."""
    import torch

    st = lm_head.__dict__
    if st.get("_lh_disabled"):
        return None
    if st.get("_lh_w8") is None:
        if torch.cuda.is_current_stream_capturing():
            return None            # never build a 0.6 GB copy inside a graph
        try:
            if not _lh_build(lm_head):
                return None
        except Exception as exc:   # pragma: no cover - defensive
            logger.warning("[lmhead-fp8] build failed: %r; disabled", exc)
            st["_lh_disabled"] = True
            return None

    w8 = st["_lh_w8"]
    wbf = st["_lh_wbf"]
    sb = st["_lh_sb"]
    h = hidden_states
    if h.dtype != torch.bfloat16:
        h = h.to(torch.bfloat16)
    rows = h.shape[0]
    vocab = w8.shape[1]
    k = min(_LH_K, vocab)
    out = torch.empty((rows, vocab), dtype=torch.bfloat16, device=h.device)
    for i in range(0, rows, _LH_TCHUNK):
        x = h[i:i + _LH_TCHUNK]
        m = x.shape[0]
        pad = (-m) % 4
        xp = torch.cat([x, x[-1:].expand(pad, -1)], 0) if pad else x
        sa = (xp.abs().amax().clamp_min(1e-8) / _LH_FP8_MAX).to(
            torch.float32).reshape(1)
        x8 = (xp / sa).to(torch.float8_e4m3fn)
        lg = torch._scaled_mm(x8, w8, sa, sb, out_dtype=torch.bfloat16)
        lg = lg[:m].contiguous()
        idx = torch.topk(lg, k, dim=-1).indices
        sel = wbf[idx.reshape(-1)].view(m, k, wbf.shape[1])
        exact = (x.float().unsqueeze(1) * sel.float()).sum(-1)
        lg.scatter_(1, idx, exact.to(lg.dtype))
        out[i:i + m] = lg
        del x, xp, x8, lg, idx, sel, exact
    if embedding_bias is not None:
        out = out + embedding_bias.to(out.dtype)
    n = st.get("_lh_calls", 0) + 1
    st["_lh_calls"] = n
    if n in (1, 200, 5000):
        logger.info("[lmhead-fp8] %d calls, T=%d", n, rows)
    return out


def install_lm_head_hook() -> None:
    """Opt-in runtime fp8 lm_head for the target model only (no load-path change)."""
    if not _LH_ON:
        return
    from vllm.model_executor.layers.quantization import modelopt as _mo

    if getattr(_mo.ModelOptNvFp4Config, "_lmhead_fp8_patched", False):
        return
    _cur_gqm = _mo.ModelOptNvFp4Config.get_quant_method

    def get_quant_method(self, layer, prefix):
        method = _cur_gqm(self, layer, prefix)
        try:
            if _lh_is_target_lm_head(layer, prefix):
                layer.__dict__[_LH_MARK] = True
                logger.info("[lmhead-fp8] marked target head (prefix=%s)", prefix)
        except Exception:
            pass
        return method

    _mo.ModelOptNvFp4Config.get_quant_method = get_quant_method

    from vllm.model_executor.layers.logits_processor import LogitsProcessor

    _orig_apply_head = LogitsProcessor._apply_head

    def _apply_head(self, lm_head, hidden_states, embedding_bias=None):
        if (
            getattr(lm_head, _LH_MARK, False)
            and (self.head_dtype is None
                 or self.head_dtype == hidden_states.dtype)
        ):
            res = _lh_forward(lm_head, hidden_states, embedding_bias)
            if res is not None:
                return res
        return _orig_apply_head(self, lm_head, hidden_states, embedding_bias)

    LogitsProcessor._apply_head = _apply_head
    _mo.ModelOptNvFp4Config._lmhead_fp8_patched = True
    logger.info("[lmhead-fp8] hook installed (K=%d, tchunk=%d, vchunk=%d)",
                _LH_K, _LH_TCHUNK, _LH_VCHUNK)
