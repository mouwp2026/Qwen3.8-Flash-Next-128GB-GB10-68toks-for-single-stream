#!/usr/bin/env bash
# Build the release image and sanity-check that the PLE/HashK backend landed in it.
#
#   ./scripts/build.sh                     # -> qwen38-flash-next-gx10-mtp-hashk:v1.0.0
#   TAG=my-registry/repo:tag ./scripts/build.sh
set -euo pipefail

TAG="${TAG:-qwen38-flash-next-gx10-mtp-hashk:v1.0.0}"
cd "$(dirname "$0")/.."

docker build -t "$TAG" .

# The Dockerfile COPYs src/vllm_ple_mmap.py next to vllm; verify the module in
# the built image is the one from this checkout (guards against a stale context).
MARKER="$(grep -c 'read from checkpoint index' src/vllm_ple_mmap.py)"
INSIDE="$(docker run --rm --entrypoint bash "$TAG" -c \
  "grep -c 'read from checkpoint index' /usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py")"
if [ "$MARKER" != "$INSIDE" ]; then
  echo "!! image content mismatch ($MARKER vs $INSIDE) — build context stale?"
  exit 1
fi
echo "IMAGE-OK  $TAG"
