#!/usr/bin/env python3
"""Flag the MTP draft head so the fp8-hybrid shim never fp8-ises it.

Why this is needed
------------------
The shim's first attempt marked the target lm_head inside ModelOpt's
get_quant_method.  That never fired: lm_head is on the checkpoint's quantization
ignore list, so it is built with quant_config=None and get_quant_method is not
called for it at all.  The shim therefore now falls back to `isinstance(layer,
ParallelLMHead)`, which is fine for the target model but cannot tell the two
heads apart by itself -- mtp.py remaps the checkpoint's `lm_head.weight` tensor
straight into the draft model, so both heads are ParallelLMHead instances over
the very same bf16 tensor.

An explicit flag on the draft head's object is the reliable discriminator.  It
is set right after load_weights, i.e. before the profile run and before any
graph capture, which is early enough for every later _apply_head call.

Idempotent.  Usage: python3 patch_lh_skip.py [mtp.py path]
"""
import io
import os
import shutil
import sys
import time

DEFAULT = "${HOME}/ple-pq/rt2/mtp.py"
MARK = "_lmhead_fp8_skip"

STMT = (
    "        # Flag this lm_head as the *draft* head: the fp8-hybrid shim must\n"
    "        # never fp8-ise it.  Both heads are ParallelLMHead over the same\n"
    "        # remapped bf16 checkpoint tensor, so type alone cannot tell them\n"
    "        # apart (lm_head is on the quant ignore list, so ModelOpt's\n"
    "        # get_quant_method never runs for it either).\n"
    "        try:\n"
    "            self.lm_head.__dict__[\"_lmhead_fp8_skip\"] = True\n"
    "        except Exception:\n"
    "            pass\n"
)

TARGETS = [
    (
        "    def _mh_load_weights(self, weights):\n"
        "        out = _mh_prev_load_weights(self, weights)\n"
        "        _mh_build(self)\n",
        "    def _mh_load_weights(self, weights):\n"
        "        out = _mh_prev_load_weights(self, weights)\n"
        + STMT
        + "        _mh_build(self)\n",
    ),
    (
        "    def _mh4_load_weights(self, weights):\n"
        "        out = _mh4_prev_load_weights(self, weights)\n"
        "        _mh4_build(self)\n",
        "    def _mh4_load_weights(self, weights):\n"
        "        out = _mh4_prev_load_weights(self, weights)\n"
        + STMT
        + "        _mh4_build(self)\n",
    ),
]


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT
    src = io.open(path, encoding="utf-8").read()
    if MARK in src:
        print("already patched (found _lmhead_fp8_skip); nothing to do")
        return 0

    out = src
    done = []
    for old, new in TARGETS:
        if old not in out:
            print(f"!! anchor not found for: {old.splitlines()[0]}")
            return 1
        out = out.replace(old, new, 1)
        done.append(old.split("(")[0].strip())

    backup = path + ".bak-" + time.strftime("%Y%m%d-%H%M%S") + "-before-lhskip"
    shutil.copy2(path, backup)
    print(f"backup -> {backup}")

    io.open(path, "w", encoding="utf-8", newline="\n").write(out)
    print(f"written {path} ({os.path.getsize(path)} bytes, was {len(src)})")

    import ast
    ast.parse(out, path)
    print("AST PARSE OK")
    print("patched:", ", ".join(done))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
