#!/usr/bin/env bash
# Serve qwen38-flash with *both* head optimisations, pinned to the exact
# configuration the box runs: FULL_DECODE_ONLY cudagraphs with an empty
# splitting list, MTP k=4, the PLE PQ M5 table, draft vocab 147456,
# max-num-seqs 8, gpu-memory-utilization 0.88, prefix caching on.
#
# Re-rank width is K=64 for every stage.  The target head's bare low-precision
# top-1 agreement on real hidden states is 0%, so token exactness rests entirely
# on the true argmax surviving inside the candidate set; K=64 doubles that margin
# for 160 KB of extra read per step.  The head build + microbench are moved ahead
# of vLLM's memory-profile window (see the shim's _install_eager_build_hook), so
# they no longer cost the KV pool.
#
#   scripts/serve-heads.sh                   # DRY: print resolved config, START NOTHING
#   REAL=1 scripts/serve-heads.sh             # draft head nvfp4, target head nvfp4
#   MTP_HEAD_4BIT=probe REAL=1 scripts/serve-heads.sh   # measure the draft stage only
#   LMHEAD_FP8=0 REAL=1 scripts/serve-heads.sh          # draft head only
#   MTP_HEAD_4BIT=0 REAL=1 scripts/serve-heads.sh       # target head only
#   LMHEAD_4BIT=0 REAL=1 scripts/serve-heads.sh         # target head fp8 instead of fp4
#
# NOTE: this script is dry-run by default ON PURPOSE.  It was run once without
# DRY=1 back when the default was "just start", which silently `docker rm -f`'d a
# live production container.  Restarting costs ~13 min of weight load, so the
# destructive path now has to be asked for explicitly.
#
# Every stage self-verifies at build time (numerics + a kernel microbench at the
# live shape) and falls back to the previous behaviour on failure, so this is
# safe to leave on.  Watch for:
#   docker logs qwen38-flash 2>&1 | grep -E 'mtp-head-(fp8|4bit)|lmhead-(fp8|4bit)'
set -euo pipefail
R="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export IMAGE="${IMAGE:-qwen38-flash-next-gx10-mtp-hashk:v1.0.1}"
export MODE="${MODE:-hybrid}"
export PREFIX_CACHE="${PREFIX_CACHE:-1}"
export DET_TOPK="${DET_TOPK:-1}"
export EXACT_TOPK="${EXACT_TOPK:-0}"
export PAD_M4="${PAD_M4:-0}"
export PORT="${PORT:-18300}"
export CTX="${CTX:-262144}"
export SEQS="${SEQS:-8}"
export GPU_MEM="${GPU_MEM:-0.88}"
export MTP="${MTP:-4}"
export KV_DTYPE="${KV_DTYPE:-auto}"
export PREWARM="${PREWARM:-1}"
export DRAFT_VOCAB="${DRAFT_VOCAB:-147456}"
export PLE_HASHK="${PLE_HASHK:-/hf/hashk/ple_pq_M5.pt}"
export PLE_PQ_ROUTE="${PLE_PQ_ROUTE:-device}"
export WORKERS="${WORKERS:-32}"
# v1.0.1 ships the GPU-side PLE gatherer, which is what unlocked FULL_DECODE_ONLY
# with no splitting ops.  serve.sh's own default is PIECEWISE + a splitting list,
# so this must be set explicitly or two of the existing wins are lost.
export CC="${CC:--cc.cudagraph_mode=FULL_DECODE_ONLY -cc.splitting_ops=[]}"

export PLE_RUNTIME="${PLE_RUNTIME:-${HOME}/ple-pq/rt2/vllm_ple_mmap.py}"
export MTP_RUNTIME="${MTP_RUNTIME:-${HOME}/ple-pq/rt2/mtp.py}"
export SHIM_RUNTIME="${SHIM_RUNTIME:-$R/src/vllm_fp8_hybrid_modelopt.py}"

export MTP_HEAD_FP8="${MTP_HEAD_FP8:-1}"
export MTP_HEAD_FP8_K="${MTP_HEAD_FP8_K:-64}"
export MTP_HEAD_4BIT="${MTP_HEAD_4BIT:-1}"
export MTP_HEAD_4BIT_K="${MTP_HEAD_4BIT_K:-64}"
export MTP_HEAD_4BIT_MB="${MTP_HEAD_4BIT_MB:-1}"
export LMHEAD_FP8="${LMHEAD_FP8:-1}"
export LMHEAD_FP8_K="${LMHEAD_FP8_K:-64}"
export LMHEAD_4BIT="${LMHEAD_4BIT:-1}"
export LMHEAD_4BIT_K="${LMHEAD_4BIT_K:-64}"
export LMHEAD_4BIT_MB="${LMHEAD_4BIT_MB:-1}"

echo "mode=$MODE  image=$IMAGE  ctx=$CTX  seqs=$SEQS  gpu_mem=$GPU_MEM  mtp=$MTP"
echo "cc=$CC"
echo "mtp_head_fp8=$MTP_HEAD_FP8/$MTP_HEAD_FP8_K   mtp_head_4bit=$MTP_HEAD_4BIT/$MTP_HEAD_4BIT_K"
echo "lmhead_fp8=$LMHEAD_FP8/$LMHEAD_FP8_K   lmhead_4bit=$LMHEAD_4BIT/$LMHEAD_4BIT_K (MB=$LMHEAD_4BIT_MB)"
echo "ple_runtime=$PLE_RUNTIME"
echo "mtp_runtime=$MTP_RUNTIME"
echo "shim=$SHIM_RUNTIME"
echo "ple_hashk=$PLE_HASHK   route=$PLE_PQ_ROUTE"

if [ "${REAL:-0}" != 1 ]; then
  echo
  echo ">> DRY RUN -- nothing was started and no container was touched."
  echo ">> This script is dry by default because it does: docker rm -f \$NAME"
  echo ">> then an ~8-13 min reload.  To actually restart, re-run with:  REAL=1 $0"
  exit 0
fi

echo ">> REAL=1: replacing container '${NAME:-qwen38-flash}' (watch: docker logs -f ${NAME:-qwen38-flash})"
exec "$R/scripts/serve.sh"
