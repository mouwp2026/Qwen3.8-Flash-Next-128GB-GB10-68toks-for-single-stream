#!/usr/bin/env python3
"""Append the NVFP4 draft-head stage to ple-pq/rt2/mtp.py.

Idempotent, backs up the previous file, and syntax-checks the result.  The block
is appended at the end of the module on purpose: mtp.py's existing fp8 stage is
module-level code that has already patched get_top_tokens by then, so appending
lets the 4-bit stage wrap *that* version and fall back to it cleanly.

Usage: python3 apply_mtp_4bit.py [repo_root] [block_file]
       python3 apply_mtp_4bit.py --revert [repo_root]
"""
import io
import os
import py_compile
import shutil
import sys
import time

REPO = "${HOME}/ple-pq/rt2"
TARGET_REL = "mtp.py"
BLOCK_DEFAULT = "/tmp/mtp_head_4bit.block.py"
MARK = "VLLM_MTP_HEAD_4BIT"


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    revert = "--revert" in sys.argv
    repo = args[0] if args else REPO
    block_path = args[1] if len(args) > 1 else BLOCK_DEFAULT
    target = os.path.join(repo, TARGET_REL)

    if not os.path.isfile(target):
        print(f"!! not found: {target}")
        return 1

    stamp = time.strftime("%Y%m%d-%H%M%S")
    if revert:
        cands = sorted(
            f for f in os.listdir(repo)
            if f.startswith("mtp.py.bak-") and "4bit" in f)
        if not cands:
            print("!! no mtp.py.bak-*4bit backup to revert to")
            return 1
        backup = os.path.join(repo, cands[-1])
        shutil.copy2(backup, target)
        print(f"reverted {target} <- {backup}")
        return 0

    src = io.open(target, encoding="utf-8").read()
    if MARK in src:
        print("already patched (found VLLM_MTP_HEAD_4BIT); nothing to do")
        return 0

    block = io.open(block_path, encoding="utf-8").read()
    if MARK not in block:
        print("!! block file does not contain the expected marker")
        return 1

    backup = os.path.join(repo, f"mtp.py.bak-{stamp}-before-4bit")
    shutil.copy2(target, backup)
    print(f"backup -> {backup} ({os.path.getsize(backup)} bytes)")

    out = src if src.endswith("\n") else src + "\n"
    out = out + block
    io.open(target, "w", encoding="utf-8", newline="\n").write(out)
    print(f"written {target} ({os.path.getsize(target)} bytes, was {len(src)})")

    try:
        py_compile.compile(target, doraise=True)
        print("py_compile OK")
    except py_compile.PyCompileError as exc:
        print(f"!! py_compile FAILED: {exc}")
        shutil.copy2(backup, target)
        print("rolled back")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
