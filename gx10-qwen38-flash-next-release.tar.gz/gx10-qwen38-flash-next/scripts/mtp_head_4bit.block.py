

# --- MTP draft head: NVFP4 search stage (env VLLM_MTP_HEAD_4BIT=1) ----------------
# Halves the draft head's search read one more time on top of the fp8 path above.
# The sliced head is [147456, 2560]: 755 MiB bf16 -> 377 MiB fp8 -> 212 MiB nvfp4
# (0.5 byte/param + an e4m3 block scale per 16).  At MTP=4 that is
# 3.02 -> 1.51 -> 0.85 GB *per decode step*, and the draft head is the single
# largest read of a decode step -- bigger than the target lm_head (1.271 GB).
#
# Same contract as the fp8 path: fp4 only *proposes*, then the top-K candidate
# rows are re-scored exactly in bf16, so greedy output is unchanged as long as
# the true top-1 survives inside the candidate set.  Measured on the real weight
# slice (tools/mtp_head_nvfp4_probe.py, 64 hidden probes across 4 scales):
#     fp8   per-tensor : bare top1  3/64,  recall@K 64/64 already at K=8
#     nvfp4 e2m1 blk16 : bare top1 13/64,  recall@K 64/64 already at K=8
# fp4 is visibly lossier in the raw search (20% vs 5% top-1 flips) yet its errors
# still land outside the top-K, so the rerank restores the bf16 argmax exactly
# (64/64 at K>=16).  K=32 therefore keeps a 4x margin.
#
# Two things are deliberately verified at *runtime* before this is trusted,
# because neither can be checked offline on this box -- the running vLLM has the
# whole 128 GB unified pool, so a second CUDA context cannot even be created:
#   1. a numerical selfcheck against the bf16 head right after the build
#   2. a microbenchmark of fp8 vs fp4 GEMV at the *live* shape (M = draft batch,
#      N = 147456).  fp4 wins on bytes by construction, but a cutlass fp4 kernel
#      at M=1 on sm_121 could still lose to fp8; that is measured, not assumed.
# If either check fails the search stays on fp8 and behaviour is unchanged.
#
# Env: VLLM_MTP_HEAD_4BIT=1       enable (requires VLLM_MTP_HEAD_FP8=1)
#      VLLM_MTP_HEAD_4BIT=probe   build + selfcheck + microbench, log only, keep
#                                 the fp8 search (zero-risk measurement run)
#      VLLM_MTP_HEAD_4BIT_K=32    rerank width, independent of the fp8 K
#      VLLM_MTP_HEAD_4BIT_MB=1    1 = run the fp8-vs-fp4 microbench at build time
_MH4_MODE = __import__("os").environ.get("VLLM_MTP_HEAD_4BIT", "0").strip().lower()
_MH4_ON = _MH4_MODE in ("1", "true", "yes", "on", "probe")
_MH4_PROBE_ONLY = _MH4_MODE == "probe"
_MH4_K = int(__import__("os").environ.get("VLLM_MTP_HEAD_4BIT_K", "32") or "32")
_MH4_MB = __import__("os").environ.get(
    "VLLM_MTP_HEAD_4BIT_MB", "1").strip().lower() in ("1", "true", "yes", "on")

if _MH4_ON and not _MH_ON:
    __import__("vllm.logger", fromlist=["init_logger"]).init_logger(__name__).warning(
        "VLLM_MTP_HEAD_4BIT needs VLLM_MTP_HEAD_FP8=1 (the fp8 path builds the "
        "bf16 slice and the rerank machinery); not enabled")
    _MH4_ON = False

if _MH4_ON:
    import torch as _mh4_torch

    _mh4_log = _mh_init_logger("vllm.mtp_head_nvfp4")
    _MH4_ST = {"built": False, "fails": 0, "use": False}
    # e2m1 is sign + 3-bit magnitude {0,.5,1,1.5,2,3,4,6}; the two-level NVFP4
    # scale keeps every block scale inside e4m3 range (see modelopt: alpha =
    # input_global_scale * weight_global_scale, global_scale = 6*448/amax).
    _MH4_E2M1_MAX = 6.0
    _MH4_E4M3_MAX = 448.0

    def _mh4_mm(h2, self):
        """fp4 logits over the draft vocab slice: [T, H] -> [T, N] bf16."""
        from vllm._custom_ops import cutlass_scaled_fp4_mm, scaled_fp4_quant

        h = h2.reshape(-1, h2.shape[-1])
        if h.dtype != _mh4_torch.bfloat16:
            h = h.to(_mh4_torch.bfloat16)
        amax = h.abs().amax().clamp_min(1e-8).to(_mh4_torch.float32)
        gs_x = (_MH4_E2M1_MAX * _MH4_E4M3_MAX) / amax
        hq, hs = scaled_fp4_quant(
            h, gs_x.reshape(1), is_sf_swizzled_layout=True, backend="cutlass")
        alpha = (1.0 / (gs_x * self._mh4_gsw)).reshape(1).to(_mh4_torch.float32)
        return cutlass_scaled_fp4_mm(
            hq, self._mh4_wq, hs, self._mh4_ws, alpha, _mh4_torch.bfloat16)

    def _mh4_rerank(lg4, h2, self):
        k = min(_MH4_K, lg4.shape[-1])
        idx = _mh4_torch.topk(lg4, k, dim=-1).indices                     # [T, k]
        wbf = self._mh_wbf
        sel = wbf[idx.reshape(-1)].view(idx.shape[0], k, wbf.shape[1])    # bf16 gather
        exact = _mh4_torch.einsum(
            "tkh,tkh->tk",
            h2.float().unsqueeze(1).expand(-1, k, -1),
            sel.float())
        return idx.gather(1, exact.argmax(-1, keepdim=True)).squeeze(1)

    def _mh4_build(self):
        """Quantise the draft head slice to NVFP4. Idempotent; never during capture."""
        if _MH4_ST["built"] or _MH4_ST["fails"] >= 3:
            return
        if _mh4_torch.cuda.is_current_stream_capturing():
            return
        wbf = getattr(self, "_mh_wbf", None)
        if wbf is None or wbf.dim() != 2:
            _mh4_log.warning(
                "[mtp-head-4bit] no bf16 head slice yet (_mh_wbf missing); fp8 kept")
            _MH4_ST["built"] = True
            return
        try:
            from vllm._custom_ops import scaled_fp4_quant
            from vllm.model_executor.layers.quantization.utils.nvfp4_utils import (
                swizzle_blockscale)

            wbf = wbf.contiguous()
            rows, cols = wbf.shape
            amax = wbf.abs().amax().clamp_min(1e-8).to(_mh4_torch.float32)
            gs_w = (_MH4_E2M1_MAX * _MH4_E4M3_MAX) / amax
            wq, wbs = scaled_fp4_quant(
                wbf, gs_w.reshape(1), is_sf_swizzled_layout=False)
            self._mh4_wq = wq
            self._mh4_ws = swizzle_blockscale(wbs)
            self._mh4_gsw = gs_w
            _mh4_log.info(
                "[mtp-head-4bit] built: rows=%d K=%d | packed fp4 %.0f MiB + swizzled "
                "scale %.0f MiB (fp8 %.0f MiB, bf16 %.0f MiB) | amax=%.5f gs=%.4e",
                rows, cols, wq.numel() / 1048576, self._mh4_ws.numel() / 1048576,
                rows * cols / 1048576, wbf.numel() * 2 / 1048576,
                float(amax), float(gs_w))

            ok = _mh4_selfcheck(self)
            fast = _mh4_microbench(self) if _MH4_MB else True
            _MH4_ST["use"] = bool(ok and fast)
            _MH4_ST["built"] = True
            _mh4_log.info(
                "[mtp-head-4bit] selfcheck=%s microbench=%s -> search back-end = %s"
                "%s", ok, fast, "nvfp4" if _MH4_ST["use"] else "fp8",
                " (probe-only, behaviour unchanged)" if _MH4_PROBE_ONLY else "")
            _mh4_torch.cuda.empty_cache()
        except Exception as exc:  # pragma: no cover - defensive
            _MH4_ST["fails"] += 1
            _mh4_log.warning(
                "[mtp-head-4bit] build failed %d/3: %r; fp8 kept",
                _MH4_ST["fails"], exc)

    def _mh4_selfcheck(self):
        try:
            with _mh4_torch.no_grad():
                hd = self._mh_wbf.shape[1]
                hs = _mh4_torch.randn(64, hd, dtype=_mh4_torch.bfloat16,
                                      device=self._mh_wbf.device)
                ref = (hs @ self._mh_wbf.t()).argmax(-1)
                lg4 = _mh4_mm(hs, self)
                raw = lg4.argmax(-1)
                two = _mh4_rerank(lg4, hs, self)
                r = (raw == ref).float().mean().item() * 100
                t = (two == ref).float().mean().item() * 100
                _mh4_log.info(
                    "[mtp-head-4bit] selfcheck (64 synthetic hidden): raw-fp4 top1="
                    "%.1f%%, two-stage top1=%.1f%%", r, t)
                del hs, ref, lg4, raw, two
                return t >= 98.0
        except Exception as exc:  # pragma: no cover - defensive
            _mh4_log.warning("[mtp-head-4bit] selfcheck failed: %r", exc)
            return False

    def _mh4_microbench(self):
        """fp8 vs fp4 GEMV at the live shape; fp4 must actually be faster."""
        try:
            hd = self._mh_wbf.shape[1]
            hs = _mh4_torch.randn(1, hd, dtype=_mh4_torch.bfloat16,
                                  device=self._mh_wbf.device)

            def _t(fn, iters=50, warm=10):
                for _ in range(warm):
                    fn()
                _mh4_torch.cuda.synchronize()
                a = _mh4_torch.cuda.Event(True)
                b = _mh4_torch.cuda.Event(True)
                a.record()
                for _ in range(iters):
                    fn()
                b.record()
                _mh4_torch.cuda.synchronize()
                return a.elapsed_time(b) / iters * 1000.0          # microseconds

            n_el = self._mh_wbf.numel()
            t8 = _t(lambda: _mh_mm(hs, self))
            t4 = _t(lambda: _mh4_mm(hs, self))
            _mh4_log.info(
                "[mtp-head-4bit] microbench M=1 N=%d: fp8 %.1f us (%.0f GB/s eff) | "
                "fp4 %.1f us (%.0f GB/s eff) | speedup %.2fx",
                self._mh_wbf.shape[0], t8, (n_el / 1e9) / (t8 / 1e6),
                t4, (n_el * 0.5625 / 1e9) / (t4 / 1e6), t8 / t4)
            del hs
            # require a real win, not noise: the extra 0.6 GB of build-time
            # residency and the fp4 quantisation of the activation both have to
            # pay for themselves
            return t4 <= t8 * 0.98
        except Exception as exc:  # pragma: no cover - defensive
            _mh4_log.warning("[mtp-head-4bit] microbench failed: %r", exc)
            return False

    _mh4_prev_get_top_tokens = Qwen3_8FlashNextMTP.get_top_tokens

    def _mh4_get_top_tokens(self, hidden_states):
        if not _MH4_ST["built"] and _MH4_ST["fails"] < 3:
            _mh4_build(self)
        if _MH4_ST["use"] and not _MH4_PROBE_ONLY:
            try:
                h2 = hidden_states.reshape(-1, hidden_states.shape[-1])
                lg4 = _mh4_mm(h2, self)
                out = _mh4_rerank(lg4, h2, self)
                if not getattr(self, "_mh4_checked", False):
                    self._mh4_checked = True
                    try:
                        ref = (h2 @ self._mh_wbf.t()).argmax(-1)     # true bf16
                        _mh4_log.info(
                            "[mtp-head-4bit] PROD check (first real draft step, "
                            "T=%d): raw-fp4 top1=%.1f%%, two-stage top1=%.1f%% "
                            "(bf16 truth)", h2.shape[0],
                            (lg4.argmax(-1) == ref).float().mean().item() * 100,
                            (out == ref).float().mean().item() * 100)
                        del ref
                    except Exception as exc:
                        _mh4_log.warning("[mtp-head-4bit] PROD check skipped: %r", exc)
                    _mh4_torch.cuda.empty_cache()
                return out
            except Exception as exc:
                _MH4_ST["use"] = False
                _mh4_log.warning(
                    "[mtp-head-4bit] runtime error: %r; falling back to fp8", exc)
        return _mh4_prev_get_top_tokens(self, hidden_states)

    _mh4_prev_load_weights = Qwen3_8FlashNextMTP.load_weights

    def _mh4_load_weights(self, weights):
        out = _mh4_prev_load_weights(self, weights)
        # Flag this lm_head as the *draft* head: the fp8-hybrid shim must never
        # fp8-ise it.  Both heads are ParallelLMHead over the same remapped bf16
        # checkpoint tensor, so type alone cannot tell them apart (lm_head is on
        # the quant ignore list, so ModelOpt's get_quant_method never runs for it
        # either).  Set before the profile run / any graph capture.
        try:
            self.lm_head.__dict__["_lmhead_fp8_skip"] = True
        except Exception:
            pass
        _mh4_build(self)
        return out

    Qwen3_8FlashNextMTP.get_top_tokens = _mh4_get_top_tokens
    Qwen3_8FlashNextMTP.load_weights = _mh4_load_weights
    _mh4_log.info(
        "[mtp-head-4bit] patched get_top_tokens (N=%d, K=%d, mode=%s, microbench=%s)",
        _DV_N, _MH4_K, _MH4_MODE, _MH4_MB)
# --- end MTP draft head NVFP4 search stage ---------------------------------------
