#!/usr/bin/env python3
"""Surgically add the optional runtime fp8 lm_head hook to the fp8-hybrid shim.

Usage:  python3 apply_patch.py <repo_dir> [block_file]
        python3 apply_patch.py <repo_dir> --revert     # restore the .bak file
Idempotent: refuses to run twice unless --force.
"""
import io
import os
import shutil
import sys

REPO = sys.argv[1] if len(sys.argv) > 1 else "."
TARGET = os.path.join(REPO, "src", "vllm_fp8_hybrid_modelopt.py")
BAK = TARGET + ".bak-20260915-before-lmhead"
BLOCK = sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--") else "/tmp/lh_block.py"

if "--revert" in sys.argv:
    if not os.path.exists(BAK):
        sys.exit("no backup found: %s" % BAK)
    shutil.copyfile(BAK, TARGET)
    print("reverted %s from %s" % (TARGET, BAK))
    sys.exit(0)

INJECT = (
    "    # --- 10. optional runtime fp8 lm_head (VLLM_LMHEAD_FP8=1) ---\n"
    "    if _LH_ON:\n"
    "        try:\n"
    "            install_lm_head_hook()\n"
    "        except Exception as exc:  # pragma: no cover\n"
    '            logger.warning("lmhead-fp8: hook install failed: %r", exc)\n'
)

src = io.open(TARGET, encoding="utf-8").read()
block = io.open(BLOCK, encoding="utf-8").read()

if "VLLM_LMHEAD_FP8" in src and "--force" not in sys.argv:
    print("already patched; nothing to do (use --force to re-apply)")
    sys.exit(0)

anchor = "def apply() -> None:\n"
if src.count(anchor) != 1:
    sys.exit("anchor not unique (%d) -- aborting" % src.count(anchor))

if "--force" in sys.argv and "VLLM_LMHEAD_FP8" in src:
    src = io.open(BAK, encoding="utf-8").read()

if not os.path.exists(BAK):
    shutil.copyfile(TARGET, BAK)
    print("backup -> %s" % BAK)

src = src.replace(anchor, anchor + INJECT, 1)
src = src.rstrip("\n") + "\n" + block
io.open(TARGET, "w", encoding="utf-8", newline="\n").write(src)
print("patched %s (%d bytes)" % (TARGET, len(src)))
