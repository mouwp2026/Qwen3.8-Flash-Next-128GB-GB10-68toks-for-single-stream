#!/usr/bin/env bash
set -euo pipefail

MODEL="${MODEL:-RadixArk/Qwen3.8-Flash-Next-NVFP4}"
IMAGE="${IMAGE:-qwen38-flash-next-gx10-mtp-hashk:v1.0.0}"
HF_CACHE="${HF_CACHE:-$HOME/.cache/huggingface}"
mkdir -p "$HF_CACHE"

TOKEN_ARGS=()
if [ -n "${HF_TOKEN:-}" ]; then
  TOKEN_ARGS+=(-e HF_TOKEN)
elif [ -n "${HUGGING_FACE_HUB_TOKEN:-}" ]; then
  TOKEN_ARGS+=(-e HUGGING_FACE_HUB_TOKEN -e HF_TOKEN="$HUGGING_FACE_HUB_TOKEN")
else
  echo ">> no HF_TOKEN in the environment; Hub will rate-limit unauthenticated downloads"
fi

echo ">> downloading $MODEL into $HF_CACHE (resumable)"
docker run --rm --name qwen38-dl \
  -e HF_HOME=/hf \
  -e HF_HUB_DISABLE_XET=1 \
  -e HF_HUB_DOWNLOAD_TIMEOUT=300 \
  -e HF_HUB_ETAG_TIMEOUT=900 \
  -e HF_HUB_DISABLE_XET_HINTS=1 \
  -e HF_HUB_ENABLE_HF_TRANSFER=0 \
  -e HF_ENDPOINT=https://hf-mirror.com \
  "${TOKEN_ARGS[@]}" \
  -v "$HF_CACHE:/hf" --entrypoint bash "$IMAGE" \
  -c "hf download '$MODEL' --max-workers 4"

echo ">> done. Verify with:  scripts/serve.sh"