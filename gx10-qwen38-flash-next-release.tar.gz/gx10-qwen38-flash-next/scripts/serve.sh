#!/usr/bin/env bash
# Serve Qwen3.8-Flash-Next on a single DGX Spark / GB10 with the PLE table mmapped
# from disk. OpenAI-compatible API on $PORT.
#
#   scripts/serve.sh                          # NVFP4 checkpoint as published, 262k ctx
#   MODE=hybrid scripts/serve.sh              # NVFP4 experts + fp8 side layers (scripts/prepare-hybrid.sh first)
#   YARN=1 CTX=500000 scripts/serve.sh        # 500k context via YaRN (validated)
#   docker logs -f qwen38-flash               # wait for "Application startup complete"
#
# Tunables (env):
#   MODE=nvfp4        nvfp4 = the checkpoint as published (side layers bf16)
#                     hybrid = side layers in blockwise fp8: +20% decode, +15-20% KV, same
#                     tournament score. Needs the one-time scripts/prepare-hybrid.sh
#   PREFIX_CACHE=1    1 = --enable-prefix-caching (correct with this image's block_size fix;
#                     repeated prefixes — system prompts, multi-turn, tool loops — skip the prefill)
#   DET_TOPK=1        1 = deterministic QSA top-k KERNEL (@jschmied, vllm#55122): identical output at
#                     temperature 0 at no prefill cost. The default.
#   EXACT_TOPK=0      1 = exact torch.topk fallback (also deterministic, but -20-40% long prefill); wins over DET_TOPK
#   PAD_M4=0          1 = pad M%4 in the blockwise-fp8 GEMM (@jschmied). Hybrid mode only; a no-op with
#                     PREFIX_CACHE=1 (chunks are 1600-aligned), about -40% TTFT at 8k with PREFIX_CACHE=0
#   PORT=18300        host port for the API
#   CTX=262144        max context length (native). With YARN=1 up to ~500000 (see README)
#   YARN=0            1 = YaRN rope scaling (factor 4) for CTX > 262144
#   SEQS=8            max concurrent sequences. Do NOT leave this at 1-2 when measuring
#                     throughput: requests queue silently and aggregate tok/s flatlines
#   GPU_MEM=0.80      fraction of the 128 GB pool for weights+KV. 0.85 buys ~2 GiB of KV but the
#                     box drifted into swap after a day at it; 0.875 got OOM-killed on a 300k prefill
#   MTP=2             speculative tokens from the model's MTP head (0 = off)
#   KV_DTYPE=auto     auto (=bf16) recommended; fp8_e4m3 = x1.9 KV / 1M ctx at a speed+quality cost (README)
#   PREWARM=0         1 = stream the PLE table once at boot to warm the page cache
#                     (with PLE_HASHK set this warms the 12.8 GB compressed table,
#                     otherwise the full on-disk table)
#   DRAFT_VOCAB=0     reduced-vocabulary MTP draft (0 = off; 147456 = zh-safe,
#                     idea from tonyd2wild/Qwen3.8-Flash-Next-NVFP4-DGX-Spark,
#                     vocab re-calibrated for 100% Chinese coverage; see src/patch_draft_vocab.py)
#   PLE_HASHK=        path to the HashK compressed PLE table (12.8 GB, e.g.
#                     /hf/hashk/ple_hashk_R4.pt). Empty = stock on-disk table.
#                     Lossy by design; see docs/HASHK_TABLE.md.
#   WORKERS=32        threads for the mmap gather
#   MTP_RUNTIME=      bind-mount a patched mtp.py over the image copy (no rebuild)
#   MTP_HEAD_FP8=0    1 = two-stage draft head: fp8 search + exact bf16 top-K rerank
#   MTP_HEAD_4BIT=0   1 = nvfp4 search instead of fp8 (halves the head read again,
#                     147456x2560: 377 MiB -> 212 MiB); probe = measure only.
#                     Self-verified at build; falls back to fp8 automatically.
#   SHIM_RUNTIME=     bind-mount a patched vllm_fp8_hybrid_modelopt.py
#   LMHEAD_FP8=0      1 = runtime fp8 *target* lm_head + exact bf16 top-K rerank
#                     (248320x2560 bf16 = 1.271 GB/step -> 0.636 GB)
#   EXTRA=            extra vllm flags passed verbatim
#   IMAGE=qwen38-flash-next-gx10-mtp-hashk   MODEL=RadixArk/Qwen3.8-Flash-Next-NVFP4
set -euo pipefail

NAME="${NAME:-qwen38-flash}"
IMAGE="${IMAGE:-qwen38-flash-next-gx10-mtp-hashk:v1.0.0}"
MODEL="${MODEL:-RadixArk/Qwen3.8-Flash-Next-NVFP4}"
HF_CACHE="${HF_CACHE:-$HOME/.cache/huggingface}"
MODE="${MODE:-nvfp4}"
PREFIX_CACHE="${PREFIX_CACHE:-1}"
DET_TOPK="${DET_TOPK:-1}"
EXACT_TOPK="${EXACT_TOPK:-0}"
PAD_M4="${PAD_M4:-0}"
PORT="${PORT:-18300}"
CTX="${CTX:-262144}"
YARN="${YARN:-0}"
SEQS="${SEQS:-8}"
GPU_MEM="${GPU_MEM:-0.80}"
MTP="${MTP:-3}"
KV_DTYPE="${KV_DTYPE:-auto}"
PREWARM="${PREWARM:-0}"
# Reduced-vocabulary MTP draft (0 = off). Suggested: 147456 (zh-safe),
# 65536 (en/code-heavy). See src/patch_draft_vocab.py.
DRAFT_VOCAB="${DRAFT_VOCAB:-0}"
# HashK compressed PLE table (12.8 GB, page-cache resident).
# Empty = stock on-disk shard mmap; a path = lossy compressed row source
# (bf16 rows, dequant no-op). See docs/HASHK_TABLE.md.
PLE_HASHK="${PLE_HASHK:-}"
EXTRA="${EXTRA:-}"
AUTOTUNE_ARG="${AUTOTUNE_ARG:---no-enable-flashinfer-autotune}"

# Resolve the local snapshot directory and map it to the in-container mount.
REPO_DIR="$HF_CACHE/hub/models--${MODEL//\//--}"
SNAP_HOST="$(ls -d "$REPO_DIR"/snapshots/*/ 2>/dev/null | grep -v -- '-fp8hybrid' | head -1 || true)"
if [ -z "$SNAP_HOST" ]; then
  echo "!! checkpoint not found under $REPO_DIR"
  echo "   run scripts/download-weights.sh first."
  exit 1
fi
SNAP_NAME="$(basename "$SNAP_HOST")"
HYBRID_ENV=()
case "$MODE" in
  nvfp4) ;;
  hybrid)
    if [ ! -f "$REPO_DIR/snapshots/${SNAP_NAME}-fp8hybrid/.prepared" ]; then
      echo "!! hybrid checkpoint not prepared: run scripts/prepare-hybrid.sh first (one-time, ~10 min)"
      exit 1
    fi
    SNAP_NAME="${SNAP_NAME}-fp8hybrid"
    HYBRID_ENV=(-e VLLM_FP8_HYBRID=1 -e VLLM_USE_DEEP_GEMM=0)
    ;;
  *) echo "!! MODE must be nvfp4 or hybrid"; exit 1 ;;
esac
SNAP_IN="/hf/hub/models--${MODEL//\//--}/snapshots/$SNAP_NAME"

# The PLE gather is a CPU op + a pageable host->device copy: it MUST run outside
# CUDA graphs. We declare it a splitting op and use PIECEWISE capture (never FULL*).
SPLIT='["vllm::unified_attention_with_output","vllm::unified_mla_attention_with_output","vllm::mamba_mixer2","vllm::mamba_mixer","vllm::short_conv","vllm::qwen3_8_flash_next_ple_short_conv","vllm::qwen3_8_flash_next_qsa_with_output","vllm::linear_attention","vllm::qwen_gdn_attention_core","vllm::qwen_gdn_attention_core_fused_norm_packed","vllm::sparse_attn_indexer","vllm::ple_mmap_lookup"]'
CC="${CC:--cc.cudagraph_mode=PIECEWISE -cc.splitting_ops=$SPLIT}"

# YaRN (Qwen's published recipe) to go past the native 262144.
OVR_ARGS=()
YARN_OVR='{"text_config": {"rope_parameters": {"mrope_interleaved": true, "mrope_section": [11, 11, 10], "rope_type": "yarn", "rope_theta": 10000000, "partial_rotary_factor": 0.25, "factor": 4.0, "original_max_position_embeddings": 262144}}}'
ALLOW_LONG=0
if [ "$YARN" != 0 ]; then OVR_ARGS=(--hf-overrides "$YARN_OVR"); ALLOW_LONG=1; fi

# MTP + YaRN: dict hf_overrides are not propagated to the draft model, whose
# max_model_len then stays 262144 and vLLM aborts with
# "--mamba-block-size can only be set with --enable-prefix-caching". Forcing the
# draft's max_model_len through the speculative config fixes it.
if [ "${DRAFT_VOCAB}" != "0" ]; then
  SPEC_EXTRA=',"use_local_argmax_reduction":true'
else
  SPEC_EXTRA=""
fi
SPEC=()
if [ "$MTP" != 0 ]; then
  if [ "$YARN" != 0 ]; then
    SPEC=(--speculative-config "{\"method\":\"mtp\",\"num_speculative_tokens\":${MTP}${SPEC_EXTRA},\"max_model_len\":${CTX}}")
  else
    SPEC=(--speculative-config "{\"method\":\"mtp\",\"num_speculative_tokens\":${MTP}${SPEC_EXTRA}}")
  fi
fi

# Optional PLE runtime override. Mounting a patched vllm_ple_mmap.py over the
# copy baked into the image lets a rebuilt PLE artifact be served without a full
# image rebuild (the image's copy is otherwise authoritative). Empty = image copy.
# Written as an if-block on purpose: under `set -e`, `[ -n "$X" ] && ...` returns
# 1 for an empty X and would kill the script.
PLE_RUNTIME="${PLE_RUNTIME:-}"
# N1: PLE PQ gather route. host = cudaHostRegister UVA (legacy default),
# device = codes copied into VRAM (~1.5 GiB, comes out of the KV pool).
PLE_PQ_ROUTE="${PLE_PQ_ROUTE:-host}"
PLE_VOL=()
if [ -n "$PLE_RUNTIME" ]; then
  PLE_VOL=(-v "$PLE_RUNTIME:/usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py:ro")
fi

# MH: MTP draft head override (same trick as PLE_RUNTIME) -- a patched mtp.py
# can be bind-mounted without rebuilding the image. Empty = image copy.
MTP_RUNTIME="${MTP_RUNTIME:-}"
# FP8 two-stage draft head: fp8 search + exact bf16 rerank of the top-K rows.
MTP_HEAD_FP8="${MTP_HEAD_FP8:-0}"
# K=64 (not 32): exactness rests entirely on recall@K, so the extra 160 KB of
# re-rank read per step is the cheapest margin available.
MTP_HEAD_FP8_K="${MTP_HEAD_FP8_K:-64}"
MTP_VOL=()
if [ -n "$MTP_RUNTIME" ]; then
  MTP_VOL=(-v "$MTP_RUNTIME:/usr/local/lib/python3.12/dist-packages/vllm/models/qwen3_8_flash_next/nvidia/mtp.py:ro")
fi

# NVFP4 draft-head search on top of MTP_HEAD_FP8 (env VLLM_MTP_HEAD_4BIT).
# 1 = enable, probe = measure only (selfcheck + fp8-vs-fp4 microbench, keep fp8).
# The stage self-verifies at build time and silently falls back to fp8 if the
# fp4 kernel is not actually faster at the live M=1 shape, or if the numerical
# selfcheck fails, so this is safe to leave on.
MTP_HEAD_4BIT="${MTP_HEAD_4BIT:-0}"
MTP_HEAD_4BIT_K="${MTP_HEAD_4BIT_K:-64}"
MTP_HEAD_4BIT_MB="${MTP_HEAD_4BIT_MB:-1}"

# SH: fp8-hybrid shim override (same bind-mount trick as MTP_RUNTIME). The
# image's copy is 7893 B and has no lm_head hook; pointing this at the patched
# src/vllm_fp8_hybrid_modelopt.py enables the runtime fp8 target head. Empty =
# image copy.
SHIM_RUNTIME="${SHIM_RUNTIME:-}"
SHIM_VOL=()
if [ -n "$SHIM_RUNTIME" ]; then
  SHIM_VOL=(-v "$SHIM_RUNTIME:/usr/local/lib/python3.12/dist-packages/vllm_fp8_hybrid_modelopt.py:ro")
fi

# Runtime fp8 lm_head on the *target* model: fp8 search over the full vocab plus
# an exact bf16 re-score of the top-K rows. Needs SHIM_RUNTIME above.
LMHEAD_FP8="${LMHEAD_FP8:-0}"
LMHEAD_FP8_K="${LMHEAD_FP8_K:-64}"

# NVFP4 search stage for the *target* head, layered on LMHEAD_FP8 (env
# VLLM_LMHEAD_4BIT). 1 = enable, probe = measure only (build + selfcheck +
# fp8-vs-fp4 microbench, keep fp8).  Halves the head's search read again
# (606 -> 341 MiB) and, when it verifies, the fp8 copy is not built at all.
LMHEAD_4BIT="${LMHEAD_4BIT:-0}"
LMHEAD_4BIT_K="${LMHEAD_4BIT_K:-64}"
LMHEAD_4BIT_MB="${LMHEAD_4BIT_MB:-1}"

DETENV=(); [ "$DET_TOPK" = 1 ] && DETENV=(-e VLLM_QSA_DET_TOPK=1 -e VLLM_QSA_DET_LIB=/opt/llm/kernel-det/_C_det.so)
PC_ARG=--no-enable-prefix-caching
[ "$PREFIX_CACHE" = 1 ] && PC_ARG=--enable-prefix-caching

docker rm -f "$NAME" >/dev/null 2>&1 || true
# shellcheck disable=SC2086
docker run -d --name "$NAME" --restart unless-stopped \
  --gpus all --ipc=host --shm-size 16g -p "${PORT}:8000" \
  -v "$HF_CACHE:/hf" -e HF_HOME=/hf -e HF_HUB_OFFLINE=1 \
  "${PLE_VOL[@]}" "${MTP_VOL[@]}" "${SHIM_VOL[@]}" \
  -e VLLM_PLE_MMAP=1 -e VLLM_PLE_MMAP_WORKERS="${WORKERS:-32}" -e VLLM_PLE_MMAP_PREWARM="$PREWARM" -e VLLM_PLE_HASHK="$PLE_HASHK" \
  -e VLLM_PLE_PQ_ROUTE="$PLE_PQ_ROUTE" \
  -e VLLM_MTP_HEAD_FP8="$MTP_HEAD_FP8" -e VLLM_MTP_HEAD_FP8_K="$MTP_HEAD_FP8_K" \
  -e VLLM_MTP_HEAD_4BIT="$MTP_HEAD_4BIT" -e VLLM_MTP_HEAD_4BIT_K="$MTP_HEAD_4BIT_K" -e VLLM_MTP_HEAD_4BIT_MB="$MTP_HEAD_4BIT_MB" \
  -e VLLM_LMHEAD_FP8="$LMHEAD_FP8" -e VLLM_LMHEAD_FP8_K="$LMHEAD_FP8_K" \
  -e VLLM_LMHEAD_4BIT="$LMHEAD_4BIT" -e VLLM_LMHEAD_4BIT_K="$LMHEAD_4BIT_K" -e VLLM_LMHEAD_4BIT_MB="$LMHEAD_4BIT_MB" \
  -e VLLM_QSA_EXACT_TOPK="$EXACT_TOPK" "${DETENV[@]}" -e VLLM_FP8_PAD_M4="$PAD_M4" \
  -e VLLM_QWEN_DRAFT_VOCAB="$DRAFT_VOCAB" -e VLLM_USE_FLASHINFER_SAMPLER=1 -e VLLM_ALLOW_LONG_MAX_MODEL_LEN="$ALLOW_LONG" \
  "${HYBRID_ENV[@]}" \
  "$IMAGE" \
  "$SNAP_IN" --served-model-name qwen3.8-flash-next \
    --host 0.0.0.0 --port 8000 --load-format safetensors \
    --max-model-len "$CTX" --max-num-seqs "$SEQS" --gpu-memory-utilization "$GPU_MEM" \
    $PC_ARG --enable-chunked-prefill --max-num-batched-tokens 8192 \
    $CC \
    $AUTOTUNE_ARG \
    --kv-cache-dtype "$KV_DTYPE" \
    "${OVR_ARGS[@]}" $EXTRA \
    --enable-auto-tool-choice --tool-call-parser qwen3_coder --reasoning-parser qwen3 \
    "${SPEC[@]}"

echo ">> $NAME starting on :$PORT (model 'qwen3.8-flash-next', mode=$MODE, ctx $CTX, yarn=$YARN, mtp=$MTP, seqs=$SEQS, prefix_cache=$PREFIX_CACHE, det_topk=$DET_TOPK, draft_vocab=$DRAFT_VOCAB, exact_topk=$EXACT_TOPK, pad_m4=$PAD_M4, ple_hashk=$PLE_HASHK)"
echo ">> heads: mtp_head_fp8=$MTP_HEAD_FP8(K=$MTP_HEAD_FP8_K) mtp_head_4bit=$MTP_HEAD_4BIT(K=$MTP_HEAD_4BIT_K) lmhead_fp8=$LMHEAD_FP8(K=$LMHEAD_FP8_K) lmhead_4bit=$LMHEAD_4BIT(K=$LMHEAD_4BIT_K) shim=${SHIM_RUNTIME:-<image>}"
echo ">> watch the head stages:  docker logs $NAME 2>&1 | grep -E 'mtp-head-(fp8|4bit)|lmhead-(fp8|4bit)'"
echo ">> first boot loads ~76 GiB of weights (~8-13 min). Follow:  docker logs -f $NAME"
echo ">> ready when the log says 'Application startup complete'. Then: scripts/smoke-test.sh"
