#!/usr/bin/env python3
"""NVFP4 quality probe for the MTP *draft* head slice (N=147456).

Why this exists
---------------
mtp.py's draft head already runs a two-stage proposal: a low-precision *search*
over the sliced head, then an exact bf16 re-score of the top-K candidate rows.
The search is currently fp8 (VLLM_MTP_HEAD_FP8=1) and that is the single largest
per-step read of a decode step: 4 draft steps x [147456, 2560] fp8 = 1.51 GB/step,
more than the target lm_head (1.271 GB/step).

Dropping the search to NVFP4 (e2m1 + fp8 block scale, 4 bits) would halve it
again -> ~0.755 GB/step.  The only question that matters is whether the true
bf16 argmax still lands inside the fp4 top-K, i.e. whether the rerank can still
recover the bf16 result exactly.  That is a property of the *weight*, so it is
measured here on CPU; no GPU context is needed (and none is available: the
running vLLM container has the whole 128 GB unified pool, so a second CUDA
context cannot even be created).

NVFP4 numerical semantics modelled here (what the hardware actually does):
    * 16 consecutive weights share one block scale
    * that block scale is itself stored as float8_e4m3, so it is quantised
    * a single per-tensor global scale maps block scales into e4m3 range
    * the weight itself is e2m1: {0, .5, 1, 1.5, 2, 3, 4, 6}

Usage: python3 mtp_head_nvfp4_probe.py [--rows N] [--scales 0.25,0.5,1,2]
"""
import argparse
import json
import os
import time

import torch

torch.set_num_threads(2)
from safetensors import safe_open

DEFAULT_SNAP = (
    "/hf/hub/models--RadixArk--Qwen3.8-Flash-Next-NVFP4/snapshots/"
    "7b719225242aacd3dbd3f9407468c2ee9a9d2594-fp8hybrid"
)

BLOCK = 16          # NVFP4 block size
E2M1_MAX = 6.0      # largest representable magnitude in e2m1
FP8_MAX = 448.0     # largest representable magnitude in e4m3
E2M1_GRID = torch.tensor([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0])


def nvfp4_quant(w: torch.Tensor, chunk: int = 1024):
    """Return (dequantised float32 weights, stats).  w: [n, H] float32."""
    n, H = w.shape
    nb = H // BLOCK
    assert H % BLOCK == 0
    # pass 1: global scale from the maximum block scale (mimics the two-level
    # NVFP4 scale: a tensor-wide scale keeps block scales inside e4m3 range)
    amax_blocks = []
    for off in range(0, n, chunk):
        blk = w[off:off + chunk].reshape(-1, nb, BLOCK)
        amax_blocks.append(blk.abs().amax(dim=(1, 2)))
    amax_blocks = torch.cat(amax_blocks)
    global_scale = (amax_blocks.max().clamp_min(1e-12) / FP8_MAX).item()
    # pass 2: quantise
    out = torch.empty_like(w)
    err_max = 0.0
    rel_acc = []
    for off in range(0, n, chunk):
        blk = w[off:off + chunk].reshape(-1, nb, BLOCK)
        bs = (blk.abs().amax(dim=2).clamp_min(1e-12) / E2M1_MAX) / global_scale
        bs = bs.clamp(1e-8, FP8_MAX)
        # block scale is stored as e4m3 -> round it
        bs_q = bs.to(torch.float8_e4m3fn).to(torch.float32)
        eff = bs_q * global_scale                                  # [c, nb]
        q = blk / eff.unsqueeze(-1)
        # nearest e2m1 on the *symmetric* grid (e2m1 = sign bit + 3-bit
        # magnitude {0,.5,1,1.5,2,3,4,6}); matching the raw signed value against
        # a non-negative grid would collapse every negative to zero
        qi = (q.abs().unsqueeze(-1) - E2M1_GRID).abs().argmin(dim=-1)
        deq = torch.sign(q) * E2M1_GRID[qi]
        dq = (deq * eff.unsqueeze(-1)).reshape(-1, H)
        out[off:off + chunk] = dq
        e = (dq - w[off:off + chunk]).abs()
        err_max = max(err_max, e.max().item())
        a = w[off:off + chunk].abs().amax().item()
        if a > 0:
            rel_acc.append(e.max().item() / a)
    rel_acc.sort()
    stats = dict(
        global_scale=global_scale,
        weight_amax=amax_blocks.max().item(),
        err_max=err_max,
        rel_p50=rel_acc[len(rel_acc) // 2],
        rel_p99=rel_acc[int(len(rel_acc) * 0.99)],
        rel_worst=rel_acc[-1],
    )
    return out, stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snap", default=os.environ.get("SNAP", DEFAULT_SNAP))
    ap.add_argument("--rows", type=int, default=147456,
                    help="draft head slice = VLLM_QWEN_DRAFT_VOCAB")
    ap.add_argument("--scales", default="0.25,0.5,1.0,2.0")
    ap.add_argument("--per-scale", type=int, default=16)
    ap.add_argument("--chunk", type=int, default=1024)
    args = ap.parse_args()

    N = args.rows
    H = 2560
    scales = [float(x) for x in args.scales.split(",")]

    idx = json.load(open(os.path.join(args.snap, "model.safetensors.index.json")))
    shard = idx["weight_map"]["lm_head.weight"]
    sl = safe_open(os.path.join(args.snap, shard), framework="pt",
                   device="cpu").get_slice("lm_head.weight")
    V, Hh = sl.get_shape()
    assert Hh == H, f"hidden size mismatch {Hh} != {H}"

    torch.manual_seed(1234)
    HID = torch.cat(
        [(torch.randn(args.per_scale, H, dtype=torch.float32) * s).to(torch.bfloat16)
         for s in scales], 0)
    NT = HID.shape[0]
    print(f"probe : N={N} H={H} shard={shard}")
    print(f"hidden: {NT} vectors across scales {scales}")

    ref = torch.zeros(NT, N, dtype=torch.float32)
    fp8 = torch.zeros(NT, N, dtype=torch.float32)
    f4 = torch.zeros(NT, N, dtype=torch.float32)

    t0 = time.time()
    st4 = None
    for off in range(0, N, args.chunk):
        n = min(args.chunk, N - off)
        w = sl[off:off + n].to(torch.float32)
        hf = HID.float()
        ref[:, off:off + n] = hf @ w.t()

        # fp8 per-tensor (current production search path)
        s8 = w.abs().amax().clamp_min(1e-12) / FP8_MAX
        d8 = ((w / s8).clamp(-FP8_MAX, FP8_MAX).to(torch.float8_e4m3fn).to(torch.float32)
              * s8)
        fp8[:, off:off + n] = hf @ d8.t()

        # NVFP4
        d4, st4 = nvfp4_quant(w, chunk=n)
        f4[:, off:off + n] = hf @ d4.t()
        del w, d8, d4, hf
    print(f"matmul wall time {time.time() - t0:.1f}s\n")

    print("=== NVFP4(e2m1 blk16) 量化质量 ===")
    print(f"  weight |w|max          : {st4['weight_amax']:.5f}")
    print(f"  global scale           : {st4['global_scale']:.6e}")
    print(f"  max|deq-w|             : {st4['err_max']:.6f}")
    print(f"  block-rel err p50/p99/w: {st4['rel_p50']:.5f} / {st4['rel_p99']:.5f} / "
          f"{st4['rel_worst']:.5f}   (fp8 side layers 0.0354)")

    tb = ref.argmax(1)
    for tag, LG in (("fp8 per-tensor", fp8), ("nvfp4 blk16", f4)):
        rel = ((LG - ref).norm(dim=1) / ref.norm(dim=1)).mean().item() * 100
        fl = (LG.argmax(1) != tb).sum().item()
        print(f"\n[{tag}] relL2 {rel:.2f}%   裸 top-1 翻转 {fl}/{NT} ({fl/NT*100:.1f}%)")
        row = []
        for K in (8, 16, 32, 64, 128, 256):
            tk = torch.topk(LG, K, 1).indices
            ok = sum(1 for i in range(NT) if tb[i].item() in set(tk[i].tolist()))
            row.append((K, ok))
        print("  真 top-1 命中 fp8/fp4 top-K : "
              + "  ".join(f"K{k}={ok}/{NT}" for k, ok in row))
        for K in (16, 32, 64, 128):
            tk = torch.topk(LG, K, 1).indices
            fixed = 0
            for i in range(NT):
                idxs = tk[i]
                ex = HID[i].float() @ sl[idxs].float().t()
                if idxs[ex.argmax().item()].item() == tb[i].item():
                    fixed += 1
            print(f"  rerank@{K:<4d} 与 bf16 greedy 一致: {fixed}/{NT} "
                  f"({fixed/NT*100:.1f}%)")

    gb = N * H
    print("\n=== 带宽账 (draft head slice each draft step) ===")
    print(f"  bf16 : {gb*2/1e9:.3f} GB    fp8: {gb*1/1e9:.3f} GB    "
          f"nvfp4: {gb*0.5625/1e9:.3f} GB (0.5 byte/param + e4m3 scale/16)")
    print(f"  MTP k=4 -> per decode step: bf16 {4*gb*2/1e9:.2f} GB, "
          f"fp8 {4*gb/1e9:.2f} GB, nvfp4 {4*gb*0.5625/1e9:.2f} GB")
    for step in (60.0, 75.0):
        d8 = 4 * (gb * 1 - gb * 0.5625) / 1e9
        print(f"  fp8->nvfp4 saves {d8:.3f} GB/step = {d8/273*1000:.2f} ms/step "
              f"= {d8/273*1000/step*100:.1f}% of a {step:.0f} ms step")


if __name__ == "__main__":
    main()
