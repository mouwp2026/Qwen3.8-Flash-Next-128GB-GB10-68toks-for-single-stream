#!/usr/bin/env python3
"""Import the *patched* mtp.py through its real package path and report state.

The container bind-mounts ${HOME}/ple-pq/rt2/mtp.py over the package path
vllm/models/qwen3_8_flash_next/nvidia/mtp.py, so importing the package module is
also a check that the mount picks up the edited file.  Nothing here touches the
GPU or the running server: mtp.py only defines functions and patches class
attributes at import time.
"""
import importlib
import os

for k, v in (("VLLM_MTP_HEAD_FP8", "1"), ("VLLM_MTP_HEAD_4BIT", "1"),
             ("VLLM_QWEN_DRAFT_VOCAB", "147456")):
    os.environ.setdefault(k, v)

m = importlib.import_module("vllm.models.qwen3_8_flash_next.nvidia.mtp")
print("IMPORT OK")
print("  module file   :", m.__file__)
print("  size          :", os.path.getsize(m.__file__), "bytes")
print("  has 4bit blk  :", "VLLM_MTP_HEAD_4BIT" in open(m.__file__).read())

for name in ("_DV_N", "_MH_ON", "_MH_K", "_MH4_ON", "_MH4_K", "_MH4_MODE",
             "_MH4_PROBE_ONLY", "_MH4_MB"):
    print(f"  {name:14s}: {getattr(m, name, '<missing>')}")

cls = m.Qwen3_8FlashNextMTP
print("  get_top_tokens:", cls.get_top_tokens.__name__)
print("  load_weights  :", cls.load_weights.__name__)
print("  has _mh_mm    :", hasattr(m, "_mh_mm"))
print("  has _mh4_mm   :", hasattr(m, "_mh4_mm"))
print("  has _mh4_build:", hasattr(m, "_mh4_build"))
print("  MH4 state     :", m._MH4_ST)

import vllm._custom_ops as ops
from vllm.model_executor.layers.quantization.utils.nvfp4_utils import (
    cutlass_fp4_supported,
    pad_nvfp4_weight_for_cutlass,
    swizzle_blockscale,
)

print("  cutlass_fp4_supported():", cutlass_fp4_supported())
print("  scaled_fp4_quant       :", hasattr(ops, "scaled_fp4_quant"))
print("  cutlass_scaled_fp4_mm  :", hasattr(ops, "cutlass_scaled_fp4_mm"))
print("  swizzle_blockscale     :", callable(swizzle_blockscale))
print("  pad_nvfp4_weight       :", callable(pad_nvfp4_weight_for_cutlass))

# dimension alignment for the draft slice (no padding should be needed)
N, H = 147456, 2560
print(f"  N%32={N % 32} K%32={H % 32}  (0 = cutlass aligned, no padding)")
