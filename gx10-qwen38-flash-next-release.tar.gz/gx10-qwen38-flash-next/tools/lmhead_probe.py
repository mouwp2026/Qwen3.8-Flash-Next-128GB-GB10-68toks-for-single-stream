#!/usr/bin/env python3
"""Offline evidence probe for the lm_head fp8 question (CPU only, needs no GPU).

Answers, on the *real* lm_head weight of the `-fp8hybrid` snapshot:
  1. what precision it is actually stored in, and how big the per-step read is
  2. fp8 round-trip error, per-tensor vs blockwise-128 (same metric as
     tools/fp8_convert.py uses for the side layers)
  3. how much the logits move, and how often the full-vocab top-1 flips
  4. whether the true (bf16) top-1 lands inside the fp8 top-K -- i.e. whether a
     "fp8 search + exact bf16 re-score of the top-K rows" head can be bit-exact

Run inside the container (it needs torch + safetensors + the /hf mount):
    docker cp tools/lmhead_probe.py qwen38-flash:/tmp/ && \
    docker exec qwen38-flash python3 /tmp/lmhead_probe.py

Memory: streams the head in 8-row-block chunks, so it peaks well under 1 GB and
is safe to run next to the serving container. Read-only.
"""
import json
import os
import time

import torch
from safetensors import safe_open

torch.set_num_threads(2)

SNAP = os.environ.get(
    "SNAP",
    "/hf/hub/models--RadixArk--Qwen3.8-Flash-Next-NVFP4/snapshots/"
    "7b719225242aacd3dbd3f9407468c2ee9a9d2594-fp8hybrid",
)
BLOCK = 128
FP8_MAX = 448.0
BANDWIDTH_GBS = 273.0          # GB10 unified memory, practical decode figure
SCALES = (0.25, 0.5, 1.0, 2.0)  # hidden-state magnitudes to probe
PER_SCALE = 16


def main() -> int:
    idx = json.load(open(os.path.join(SNAP, "model.safetensors.index.json")))
    shard = idx["weight_map"]["lm_head.weight"]
    f = safe_open(os.path.join(SNAP, shard), framework="pt", device="cpu")
    sl = f.get_slice("lm_head.weight")
    rows, cols = sl.get_shape()
    try:
        dtype = sl.get_dtype()
    except Exception:
        dtype = "?"
    print("snapshot : %s" % SNAP)
    print("shard    : %s" % shard)
    print("lm_head  : %d x %d  dtype=%s" % (rows, cols, dtype))
    print("per-step read if bf16: %.3f GB   if fp8: %.3f GB"
          % (rows * cols * 2 / 1e9, rows * cols / 1e9))

    torch.manual_seed(1234)
    hid = torch.cat([
        (torch.randn(PER_SCALE, cols, dtype=torch.float32) * s).to(torch.bfloat16)
        for s in SCALES
    ], 0)
    nt = hid.shape[0]
    hf = hid.float()

    lg_bf = torch.zeros(nt, rows)
    lg_pt = torch.zeros(nt, rows)
    lg_bk = torch.zeros(nt, rows)
    g_amax = 0.0
    g_err = 0.0

    chunk = BLOCK * 8
    t0 = time.time()
    for off in range(0, rows, chunk):
        n = min(chunk, rows - off)
        w = sl[off:off + n].to(torch.float32)
        g_amax = max(g_amax, w.abs().amax().item())
        w4 = w.reshape(n // BLOCK, BLOCK, cols // BLOCK, BLOCK)
        sc = w4.abs().amax(dim=(1, 3), keepdim=True).clamp_min(1e-12) / FP8_MAX
        qb = (w4 / sc).clamp(-FP8_MAX, FP8_MAX).to(torch.float8_e4m3fn)
        d_bk = (qb.to(torch.float32) * sc).reshape(n, cols)
        g_err = max(g_err, (d_bk - w).abs().amax().item())
        lg_bf[:, off:off + n] = hf @ w.t()
        lg_bk[:, off:off + n] = hf @ d_bk.t()
        del w, w4, qb, d_bk

    sb = torch.tensor(g_amax / FP8_MAX, dtype=torch.float32)
    for off in range(0, rows, chunk):
        n = min(chunk, rows - off)
        w = sl[off:off + n].to(torch.float32)
        d_pt = (w / sb).clamp(-FP8_MAX, FP8_MAX).to(
            torch.float8_e4m3fn).to(torch.float32) * sb
        lg_pt[:, off:off + n] = hf @ d_pt.t()
        del w, d_pt
    print("\nlogits/quantize pass: %.1fs" % (time.time() - t0))

    print("\n=== fp8 round-trip (same metric as tools/fp8_convert.py) ===")
    print("  global |w|max            : %.5f" % g_amax)
    print("  blockwise-128 rel err    : %.5f   (side layers: 0.0354)"
          % (g_err / g_amax))
    print("  per-tensor scale         : %.6e" % float(sb))

    tb = lg_bf.argmax(1)
    print("\n=== logits perturbation, %d probes x %d scales ===" % (PER_SCALE, len(SCALES)))
    for tag, lg in (("per-tensor", lg_pt), ("blockwise128", lg_bk)):
        rel = ((lg - lg_bf).norm(dim=1) / lg_bf.norm(dim=1)).mean().item() * 100
        flip = (lg.argmax(1) != tb).sum().item()
        rec = []
        for k in (8, 16, 32, 64, 128, 256):
            tk = torch.topk(lg, k, 1).indices
            hit = sum(1 for i in range(nt) if tb[i].item() in set(tk[i].tolist()))
            rec.append("K%d=%d/%d" % (k, hit, nt))
        print("  [%s]" % tag)
        print("      relL2 %.2f%%   bare top-1 flip %d/%d (%.1f%%)"
              % (rel, flip, nt, flip / nt * 100))
        print("      true top-1 inside fp8 top-K: %s" % "  ".join(rec))

    save_gb = rows * cols * (2 - 1) / 1e9
    print("\n=== bandwidth ===")
    print("  saved per step: %.3f GB = %.2f ms @%.0f GB/s"
          % (save_gb, save_gb / BANDWIDTH_GBS * 1000, BANDWIDTH_GBS))
    for step in (60.0, 75.0):
        print("  = %.1f%% of a %.0f ms decode step (k=4)"
              % (save_gb / BANDWIDTH_GBS * 1000 / step * 100, step))
    print("\nNote: probes use random hidden vectors, which give far smaller top-1")
    print("margins than real last-layer states -> the flip rate above is a")
    print("pessimistic upper bound; the recall@K numbers are the ones that matter.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
