#!/usr/bin/env python3
"""acceptance_report.py -- greedy fingerprint + speculative-decoding acceptance.

Runs N greedy (temperature=0) prompts against a running endpoint, records the
sha256 of each output (a "fingerprint" for regression comparison between two
configurations) and reads the vLLM /metrics spec-decode counters before/after,
so one JSON captures both output equivalence and MTP acceptance rate.

Usage: python3 acceptance_report.py <port> <label> [model]
Writes: $OUT_DIR/acceptance-<label>.json   (OUT_DIR defaults to ./bench-reports)
"""
import hashlib
import json
import os
import sys
import time
import urllib.request

PORT = sys.argv[1]
LABEL = sys.argv[2]
MODEL = sys.argv[3] if len(sys.argv) > 3 else "qwen3.8-flash-next"
BASE = "http://localhost:%s" % PORT

PROMPTS = {
    "en_prose": "Write a paragraph about why memory bandwidth dominates single-stream LLM decoding on unified-memory SoCs.",
    "code": "Write a Python function that streams SSE from an OpenAI-compatible endpoint and counts completion tokens authoritatively.",
    "math": "Solve step by step: what is the sum of all integers k in [1,1000] such that k^2 mod 7 == 2?",
    "json": "Output a JSON array of 5 objects with keys name, year, genre about landmark databases. No prose.",
    "zh_prose": "用一段话解释为什么统一内存芯片上单流解码通常受内存带宽限制，并说明推测解码为何能缓解它。",
    "zh_tech": "帮我起草一份企业内部AI部署方案评审纪要要点，包含显存预算、看门狗策略和回滚方案三部分，中文输出。",
    "zh_mixed": "比较 vLLM 与 SGLang 在 hybrid GDN 模型上 prefix caching 的实现差异，重点讲 mamba 状态快照，中文回答。",
}


def ask(prompt, max_tokens=128):
    body = {"model": MODEL, "prompt": prompt, "max_tokens": max_tokens,
            "temperature": 0.0, "stream": True,
            "stream_options": {"include_usage": True}}
    req = urllib.request.Request(
        BASE + "/v1/completions", data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"})
    text, usage, t0 = [], None, time.perf_counter()
    with urllib.request.urlopen(req, timeout=600) as r:
        for raw in r:
            line = raw.decode("utf-8", "ignore").strip()
            if not line.startswith("data:") or line == "data: [DONE]":
                continue
            obj = json.loads(line[5:])
            if obj.get("usage"):
                usage = obj["usage"]
            ch = obj.get("choices")
            if ch and ch[0].get("text"):
                text.append(ch[0]["text"])
    return "".join(text), usage, time.perf_counter() - t0


def spec_accept():
    """Accepted/drafted token counters from the vLLM /metrics endpoint."""
    try:
        with urllib.request.urlopen(BASE + "/metrics", timeout=10) as r:
            txt = r.read().decode("utf-8", "ignore")
        acc = draft = None
        for l in txt.splitlines():
            if l.startswith("#"):
                continue
            if "spec_decode_num_accepted_tokens_total" in l and "per_pos" not in l:
                try:
                    acc = float(l.split()[-1])
                except ValueError:
                    pass
            if "spec_decode_num_draft_tokens_total" in l:
                try:
                    draft = float(l.split()[-1])
                except ValueError:
                    pass
        if acc is None or draft is None:
            return {"error": "spec counters not found in /metrics"}
        return {"accepted": acc, "draft": draft,
                "acceptance_rate": round(acc / draft, 4) if draft else None}
    except Exception as e:
        return {"error": str(e)}


out = {"label": LABEL, "port": PORT, "started": time.strftime("%F %T"),
       "accept_before": spec_accept(), "prompts": {}}
for tag, p in PROMPTS.items():
    txt, usage, dt = ask(p)
    out["prompts"][tag] = {
        "sha256": hashlib.sha256(txt.encode()).hexdigest(),
        "chars": len(txt), "e2e_s": round(dt, 2),
        "usage": usage,
        "preview": txt[:80],
        "text": txt,
    }
    print(f"{tag}: {dt:.1f}s {usage['completion_tokens']}tok "
          f"sha={out['prompts'][tag]['sha256'][:12]} {txt[:40]!r}", flush=True)
out["accept_after"] = spec_accept()

out_dir = os.environ.get("OUT_DIR", "bench-reports")
os.makedirs(out_dir, exist_ok=True)
path = os.path.join(out_dir, f"acceptance-{LABEL}.json")
json.dump(out, open(path, "w"), ensure_ascii=False, indent=2)
print("saved", path)
