#!/usr/bin/env python3
"""HashK table verification: bit-exact hashing, quality vs full table, perf.

Runs inside a throwaway container (needs torch + the artifact + the model
snapshot). Read-only w.r.t. the running engine.

Usage (from the image, artifact + snapshot mounted):
  python3 test_hashk.py --module /usr/local/lib/python3.12/dist-packages/vllm_ple_mmap.py \
                        --artifact /hf/hashk/ple_hashk_R4.pt \
                        --model-path /hf/hub/models--RadixArk--Qwen3.8-Flash-Next-NVFP4/snapshots/<snap>
"""
import argparse
import importlib.util
import sys
import time

import numpy as np
import torch


def load_module(path):
    spec = importlib.util.spec_from_file_location("vllm_ple_mmap", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["vllm_ple_mmap"] = mod
    spec.loader.exec_module(mod)
    return mod


# ---- Reference implementation, ported verbatim from the SGLang runtime ---- #
def _lsr(x, k):
    return (x >> k) & ((1 << (64 - k)) - 1)


def _splitmix(x):
    x = x + (-7046029254386353131)
    x = (x ^ _lsr(x, 30)) * (-4658895280553007687)
    x = (x ^ _lsr(x, 27)) * (-7723592293110705685)
    return x ^ _lsr(x, 31)


def ref_slots(ids, offs, sub_sizes, sub_offs, salts, hsalt, mulc):
    """ids: int64 [N] global. Returns (sA, sB, head, local) as int64 numpy."""
    t = torch.as_tensor(ids, dtype=torch.int64)
    offs_t = torch.tensor(offs, dtype=torch.int64)
    h = torch.bucketize(t, offs_t[1:], right=False)  # matches searchsorted right-1
    local = t - offs_t[h]
    hterm = torch.arange(len(offs), dtype=torch.int64) * hsalt
    base = (local + 1) * mulc
    soff = torch.tensor(sub_offs, dtype=torch.int64)
    ssz = torch.tensor(sub_sizes, dtype=torch.int64)
    sA = soff[h] + torch.remainder(_splitmix(base + salts[0] + hterm[h]), ssz[h])
    sB = soff[h] + torch.remainder(_splitmix(base + salts[1] + hterm[h]), ssz[h])
    return sA.numpy(), sB.numpy(), h.numpy(), local.numpy()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--module", required=True, help="path to vllm_ple_mmap.py")
    ap.add_argument("--artifact", required=True)
    ap.add_argument("--model-path", required=True)
    ap.add_argument("--layer-idx", type=int, default=-1, help="PLE layer index (auto if -1)")
    args = ap.parse_args()

    mod = load_module(args.module)
    print("== [1] artifact load ==")
    t0 = time.time()
    table = mod.HashKPleTable(args.artifact)
    print(f"loaded in {time.time()-t0:.1f}s; total vocab {table.total:,}")

    print("== [1b] fail-fast guard ==")
    try:
        table.gather(np.array([0], dtype=np.int64))
        print("FAIL: gather() ran with scale_folded=False (silent corruption guard broken)")
        return 1
    except RuntimeError as e:
        assert "weight_scale" in str(e)
        print("OK: gather() refuses to run before weight_scale fold")
    # [1c] late-fold semantics (mirrors the engine's multi-call load_weights)
    table.fold_weight_scale(1.0)  # test compares UNSCALED spaces on both sides
    assert table.scale_folded

    rng = np.random.default_rng(42)
    N = 200_000
    ids = rng.integers(0, table.total, size=N, dtype=np.int64)

    print("== [2] bit-exact slot check (numpy uint64 vs torch int64 reference) ==")
    # Drop ids that land exactly on a head boundary: the builder's bucketize
    # (left rule) and our searchsorted-right rule disagree there, and the
    # probability of hitting one is ~0 for real engine traffic anyway.
    keep = ~np.isin(ids, table.offs)
    ids = ids[keep]
    rA, rB, rh, rl = ref_slots(
        ids, [int(v) for v in table.offs[:-1]], table.sub_sizes.tolist(),
        table.sub_offs.tolist(), table.salts, table.hsalt, table.mulc,
    )
    h_np = np.searchsorted(table.offs, ids, side="right") - 1
    local_np = ids - table.offs[h_np]
    sA_np = table.sub_offs[h_np] + table._slot(local_np, h_np, 0)
    sB_np = table.sub_offs[h_np] + table._slot(local_np, h_np, 1)
    assert np.array_equal(h_np, rh), "head mismatch"
    assert np.array_equal(local_np, rl), "local mismatch"
    assert np.array_equal(sA_np, rA), f"sA mismatch ({np.count_nonzero(sA_np != rA)} differ)"
    assert np.array_equal(sB_np, rB), f"sB mismatch ({np.count_nonzero(sB_np != rB)} differ)"
    print(f"OK: {N:,} ids, heads/locals/slots bit-identical")

    print("== [3] quality vs full table ==")
    # locate PLE layer + shards
    import json, os, glob
    mp = args.model_path
    idx_path = os.path.join(mp, "model.safetensors.index.json")
    layer_idx = args.layer_idx
    if layer_idx < 0:
        import re as _re
        with open(idx_path) as f:
            for name in json.load(f)["weight_map"]:
                m = _re.search(
                    r"layers\.(\d+)\.ple\.ple_embedding\.ngram_embedding\.shard_0\.weight",
                    name,
                )
                if m:
                    layer_idx = int(m.group(1))
                    break
    assert layer_idx >= 0, "PLE layer not found"
    shards, dtype_str, scale_entry = mod._find_shards(mp, layer_idx)
    cols = shards.pop("__cols__")
    shard_size = -(-table.total // len(shards))
    full = mod.MmapPleTable(
        shards, shard_size, cols * mod._itemsize(dtype_str), mod._TABLE_DTYPES[dtype_str],
        workers=16, chunk=4096,
    )
    print(f"full table: layer {layer_idx}, {len(shards)} shards, dtype {dtype_str}, "
          f"{full.rows_total:,} rows x {full.row_bytes} B")

    # stratified per-head sample
    K = 800
    samp = np.concatenate(
        [rng.integers(int(table.offs[h]), int(table.offs[h + 1]), size=K, dtype=np.int64)
         for h in range(table.heads)]
    )
    full_rows = full.gather(np.sort(samp))  # fp8 bytes [M,160]
    hk_rows = table.gather(np.sort(samp))   # bf16 bits (scale folded) [M,320]
    # both sides scaled by weight_scale for absolute-value parity
    if scale_entry is not None:
        scale = float(mod._read_scale(scale_entry))
    else:
        scale = 1.0
    full_f = torch.from_numpy(full_rows.copy()).view(mod._TABLE_DTYPES[dtype_str]).to(torch.float32) * scale
    hk_f = torch.from_numpy(hk_rows.copy()).view(torch.bfloat16).to(torch.float32) * scale
    hs = np.searchsorted(table.offs, np.sort(samp), side="right") - 1
    print(f"weight_scale = {scale:.6g}")
    print(f"{'head':>4} {'cos':>8} {'rel_l2':>8} {'mean|d|':>9}")
    cos_all = []
    for h in range(table.heads):
        m = hs == h
        a, b = full_f[m], hk_f[m]
        cos = torch.nn.functional.cosine_similarity(a, b, dim=1).mean().item()
        rel = ((a - b).norm() / a.norm()).item()
        mad = (a - b).abs().mean().item()
        cos_all.append(cos)
        print(f"{h:>4} {cos:>8.4f} {rel:>8.4f} {mad:>9.4f}")
    mc = float(np.mean(cos_all))
    # R=4 bucket-mean + shared ridge projection: expected per-row fidelity is
    # ~1/sqrt(R) = 0.5 for near-isotropic rows (SGLang ships this same table).
    print(f"mean cos = {mc:.4f}  (R=4 by-design fidelity ~0.5 = 1/sqrt(4))")
    if mc < 0.35 or mc > 0.80:
        print("FAIL: fidelity outside the expected R=4 band -- mis-wired or wrong artifact")
        return 1
    print("fidelity within expected R=4 band (quality gate happens end-to-end)")

    print("== [4] perf ==")
    # decode-sized: ~380 uniq rows (6-way), 300 iters
    dec = rng.integers(0, table.total, size=380, dtype=np.int64)
    table.gather(dec)  # warm
    t0 = time.time()
    for _ in range(300):
        table.gather(dec)
    dt = (time.time() - t0) / 300 * 1e3
    print(f"decode-size (380 rows): {dt:.2f} ms/op")
    # prefill-sized: ~346k rows, 3 iters
    pre = rng.integers(0, table.total, size=346_000, dtype=np.int64)
    table.gather(pre)
    t0 = time.time()
    for _ in range(3):
        table.gather(pre)
    dt2 = (time.time() - t0) / 3
    print(f"prefill-size (346k rows): {dt2*1e3:.0f} ms/op")

    print("HASHK-TEST-OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
